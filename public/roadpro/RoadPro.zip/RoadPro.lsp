;;;============================================================================
;;;  RoadPro.lsp  -  Professional Road Builder for AutoCAD
;;;  Version : 3.4                                   Date : 23-Oct-2026
;;;  Developed by https://www.exceltokml.com/
;;;  Chainage inputs accept plain metres (100) or chainage format (0+100).
;;;  RDW / RDT with Both sides : left and right can use different chainages
;;;  and a different fillet radius. Every fillet / taper radius is marked on plan.
;;;----------------------------------------------------------------------------
;;;  COMMANDS
;;;    ROADPRO    (or RDP) ..... build a complete road from a centre line
;;;    ROADREPORT (or RDR) ..... full report of any road built by RoadPro
;;;    ROADRADIUS (or RDRAD) ... add radius / TC / CT labels to a RoadPro road
;;;    ROADSECTIONS (or RDSEC) . add straight-section labels to a RoadPro road
;;;    ROADXSEC (or RDX) ....... CROSS SECTION drawings : typical, at one
;;;                              chainage, or at every chainage interval
;;;    ROADWIDEN (or RDW) ...... LANE WIDENING : extra lane from a start to
;;;                              an end chainage, with taper in / out,
;;;                              straight or curve (reverse-curve) taper,
;;;                              fillet at match points or direct link
;;;    ROADJUNCTION (or RDJ) ... ROAD JUNCTION / TIE-IN : join a new road to an
;;;                              existing RoadPro road, with kerb-return radii,
;;;                              opened edge, corner surface, barricades and
;;;                              turning-area road markings (stop / give way
;;;                              line, STOP word or triangle, turn arrow,
;;;                              broken edge line across the mouth)
;;;    ROADMARK (or RDM) ....... ROAD MARKINGS : yellow edge lines, white double
;;;                              continuous centre line (no median barrier),
;;;                              SLOW before bends, gaps at junctions, broken
;;;                              lane line beside auxiliary lanes, quantities
;;;  v3.1 : turning radius "match existing" or manual; paved shoulder; edge =
;;;         barricades / traffic cones / kerb stone (also in cross section);
;;;         centre = double white line / barricades / cones; junction with
;;;         auxiliary lane (long approach taper, short departure taper) and
;;;         optional splitter island (kerbed or painted).
;;;  v3.2 : signs and markings set out from the Oman Highway Design Standards
;;;         2017, Section 19 (GCC Manual based) : sign plate sizes and warning
;;;         distances by speed limit, yellow warning triangles, yellow/black
;;;         chevrons (black/yellow for road works), red cones with white band,
;;;         L1 / L2 / L2A centre lines by speed, L4 yellow edge lines, L5 broken
;;;         lines, L7 stop line + STOP, L8 give-way lines + triangle, lane
;;;         arrows 5.0 / 7.5 m, delineator posts on curves (spacing by radius),
;;;         sign lower edge 1.5 m. Check against QTCM for projects in Qatar.
;;;    ROADLINE (or RDL) ....... SINGLE LINE : barricades, traffic cones or kerb
;;;                              stone along ANY line / polyline / arc / spline,
;;;                              on the line, offset left / right or both sides
;;;  v3.3 : junction corners use barricades, cones or kerb stone (same as
;;;         the main road or chosen); cones and kerb stone now also follow
;;;         lane widening and road tapers; kerb stone drawn in units.
;;;  v3.4 : CORRIDOR - lanes (from road width / manual / automatic), single
;;;         or dual carriageway, median (flush / raised), sidewalks left and
;;;         right, walkways, drainage provision (open channel / U-channel /
;;;         pipe), utility corridor provision, interlocking paver hatch
;;;         (RP_PAVER, I-shape) - in plan, cross section and report.
;;;         Curve radius editable after the design (RDER) with rebuild;
;;;         rebuild after editing the CL by hand (RDB); targeted corridor
;;;         update (RDC / RDU); alignment checks (short segments, sharp
;;;         bends, self-intersection); keep the original line (build on a
;;;         copy); Civil 3D alignment selection; LandXML 1.2 alignment
;;;         export (RDLX) and import (RDLXI). Lane widening now updates the
;;;         edge markings. Drains / utilities are GEOMETRIC PROVISIONS ONLY.
;;;    ROADCORRIDOR (RDC) ...... lanes / median / sidewalks / drains / utilities
;;;    ROADUPDATE (RDU) ........ regenerate corridor + markings of a road
;;;    ROADEDITRADIUS (RDER) ... change a curve radius after the design
;;;    ROADREBUILD (RDB) ....... rebuild a road from its edited centre line
;;;    ROADLANDXML (RDLX) ...... export the centre line as LandXML 1.2
;;;    ROADLANDXMLIN (RDLXI) ... import LandXML alignments as polylines
;;;    ROADTAPER (or RDT) ...... ROAD TAPER : widen or narrow the road edge
;;;                              from any start to any end chainage; the
;;;                              new width continues to the road end. Add
;;;                              as many tapers as needed, anywhere.
;;;    ROADPRORESET ............ restore all settings to factory defaults
;;;
;;;  WHAT IT BUILDS
;;;    - Centre line (ROAD-CL) with a custom "-- CL --" linetype
;;;    - Left and right road edges at +/- half the road width (ROAD-EDGE)
;;;    - Automatic turning radius at every bend (default 10 m, asked first),
;;;      measured at the CENTRE LINE (default) or at the inner edge
;;;    - Road surface hatch (ROAD-SURFACE)
;;;    - Red / white barricades Left / Right / Centre, black outline
;;;    - Chainage ticks and labels, e.g. CH 0+020 (ROAD-CHAINAGE)
;;;    - RADIUS ON PLAN: radius line with arrow + R value at every bend,
;;;      centre mark, TC / CT ticks with chainage, curve data label
;;;      (R inner, R CL, arc length, deflection, area) (ROAD-CURVE)
;;;    - STRAIGHT SECTIONS ON PLAN: S1, S2 ... extent bar with end ticks,
;;;      length, area, bearing, from / to chainage (ROAD-SECTION)
;;;    - Report includes a ROAD SECTIONS table: every straight and curve
;;;      with chainage, length, edge lengths, area, bearing / radius
;;;    - SIGNAGE (traffic keeps right), each sign with post, plate facing
;;;      traffic, leader, symbol and ID tag SG-01, SG-02 ... :
;;;        Road works ahead (+ plate), speed limit, bend ahead left/right,
;;;        STOP or GIVE WAY at tie-ins, NO ENTRY (one-way), KEEP RIGHT at
;;;        the median, chevron boards on bends, ROAD CLOSED boards,
;;;        lane direction arrows on the carriageway (ROAD-MARKING)
;;;    - CROSS SECTIONS: crossfall / camber, pavement layers with
;;;      thickness, shoulders, subgrade, barricade profiles WITH HEIGHT
;;;      (water-filled or New Jersey), sign post with clearance height
;;;      and footing, centre line, crossfall arrows, full dimensions
;;;    - SIGN SCHEDULE (ID, sign, chainage, side, facing, E, N) and a
;;;      SIGN LEGEND with symbols in the report
;;;    - ROAD ENDS: tie-in line with existing road + coordinates, or
;;;      road-closed barricade + ROAD CLOSED sign (ROAD-TIEIN)
;;;    - REPORT: tables in the drawing + Excel (CSV) file next to the DWG
;;;        * General, geometry, barricades, signs, road ends, chainage
;;;        * Curve data   : TC / CT chainage, radius, arc, deflection, E/N
;;;        * Setting-out  : E/N of centre line, left & right edge at every
;;;                         chainage, TC, CT, start and end
;;;    - Whole road = ONE undo step. Settings are remembered.
;;;
;;;  INSTALL : APPLOAD -> select RoadPro.lsp -> Load
;;;            (add it to "Startup Suite" to load automatically)
;;;  NEEDS   : Full AutoCAD / Civil 3D / Map 3D 2013 or newer (not LT)
;;;  INPUT   : All sizes are typed in METERS. For mm drawings choose
;;;            "Millimeters" in the dialog - RoadPro scales everything.
;;;============================================================================
(vl-load-com)

(setq *rp:ver* "3.4")

(setq *rp:defaults*
  '(("rname"  . "ROAD-01") ("width"  . "7.30")  ("radius" . "10.0")  ("rref"   . "0")
    ("units"  . "0")       ("mode"   . "0")
    ("bl"     . "1")       ("br"     . "1")     ("bc"     . "0")
    ("blen"   . "2.00")    ("bwid"   . "0.50")  ("bgap"   . "0.50")
    ("sspeed" . "1")       ("speed"  . "30")    ("swarn"  . "1")     ("warnd"  . "30")
    ("schev"  . "1")       ("twoway" . "1")     ("signsz" . "2.0")
    ("hatch"  . "1")       ("hpat"   . "SOLID") ("hscl"   . "1.0")   ("cltext" . "1")
    ("ch"     . "1")       ("chint"  . "20")    ("chst"   . "0")     ("txth"   . "1.0")
    ("endst"  . "0")       ("endfn"  . "0")     ("report" . "1")
    ("rlab"   . "1")       ("slab"   . "1")
    ("srw"    . "1")       ("skr"    . "1")     ("sarr"   . "1")     ("jctl"   . "0")
    ("ssp"    . "15")      ("xsec"   . "1")     ("mark"   . "1")
    ("rmode"  . "0")       ("etype"  . "0")     ("ctype"  . "0")     ("slow"   . "0")
    ("cmark"  . "0")       ("sauto"  . "1")     ("sset"   . "1")     ("deli"   . "1")))

(setq *rp:keys* (vl-remove "bc" (mapcar 'car *rp:defaults*)))   ; "bc" comes from the Centre popup

;; Cross-section settings (own dialog)
(setq *rp:xdefaults*
  '(("xmode"  . "0")    ("xch"    . "0")     ("xint"   . "20")
    ("xcf"    . "2.5")  ("xcamb"  . "0")     ("xverge" . "1.0")
    ("xl1n"   . "ASPHALT WEARING COURSE")    ("xl1t"   . "0.05")
    ("xl2n"   . "AGGREGATE BASE COURSE")     ("xl2t"   . "0.20")
    ("xl3n"   . "GRANULAR SUB-BASE")         ("xl3t"   . "0.15")
    ("xbtype" . "0")    ("xbh"    . "1.00")
    ("xsign"  . "1")    ("xsclr"  . "1.50")  ("xsplate" . "0.90")))
(setq *rp:xkeys*    (mapcar 'car *rp:xdefaults*)
      *rp:defaults* (append *rp:defaults* *rp:xdefaults*))

;; Lane widening settings (own dialog)
(setq *rp:wdefaults*
  '(("wside"  . "1")    ("wwid"   . "3.65")  ("wst"    . "100")   ("wen"   . "200")
    ("wtin"   . "30")   ("wtout"  . "30")    ("wtype"  . "0")     ("wmatch" . "0")
    ("wrad"   . "30")   ("wbar"   . "1")     ("warr"   . "1")     ("wlab"   . "1")
    ("wdiff"  . "0")    ("wwid2"  . "3.65")  ("wst2"   . "100")   ("wen2"  . "200")
    ("wtin2"  . "30")   ("wtout2" . "30")    ("wrad2"  . "30")))
(setq *rp:wkeys*    (mapcar 'car *rp:wdefaults*)
      *rp:defaults* (append *rp:defaults* *rp:wdefaults*))

;; Road taper settings (own dialog)
(setq *rp:tdefaults*
  '(("tside"  . "2")    ("tst"    . "100")   ("ten"    . "130")   ("tshift" . "1.00")
    ("ttype"  . "0")    ("tmatch" . "0")     ("trad"   . "30")    ("tbar"   . "1")
    ("tlab"   . "1")    ("tdiff"  . "0")     ("tst2"   . "100")   ("ten2"   . "130")
    ("tshift2" . "1.00") ("trad2"  . "30")))
(setq *rp:tkeys*    (mapcar 'car *rp:tdefaults*)
      *rp:defaults* (append *rp:defaults* *rp:tdefaults*))

;; Road junction settings (own dialog)
(setq *rp:jdefaults*
  '(("jname" . "ROAD-02") ("jwid" . "7.30") ("jmode" . "0") ("jrad" . "10.0") ("jbar" . "1")
    ("jmark" . "1") ("jcorner" . "0")
    ("jaux" . "1") ("jauxw" . "3.65") ("jlong" . "60") ("jshort" . "30") ("jstore" . "30")
    ("jisl" . "0") ("jislw" . "1.5") ("jisll" . "15")))
(setq *rp:jkeys*    (append (mapcar 'car *rp:jdefaults*) '("jctl"))
      *rp:defaults* (append *rp:defaults* *rp:jdefaults*))

;;----------------------------------------------------------------------------
;;  Dialog definition (written to a temp file at run time - single file plugin)
;;----------------------------------------------------------------------------
(setq *rp:dcl*
 (list
  "roadpro : dialog {"
  "  label = \"ROAD PRO  -  Road Builder for AutoCAD  v3.4\";"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Road Geometry\";"
  "      : edit_box   { key = \"rname\";  label = \"Road name / ID:\";      edit_width = 14; }"
  "      : edit_box   { key = \"width\";  label = \"Road width (m):\";      edit_width = 14; }"
  "      : popup_list { key = \"rmode\";  label = \"Turning radius:\";      edit_width = 24; }"
  "      : edit_box   { key = \"radius\"; label = \"Manual radius (m):\";   edit_width = 14; }"
  "      : popup_list { key = \"rref\";   label = \"Radius measured at:\";  edit_width = 24; }"
  "      : popup_list { key = \"units\";  label = \"Drawing units:\";       edit_width = 24; }"
  "      : popup_list { key = \"mode\";   label = \"Centre line input:\";   edit_width = 24; }"
  "      : toggle     { key = \"keep\";   label = \"Keep the original line (build on a copy)\"; }"
  "      : toggle     { key = \"rlab\";   label = \"Show radius, TC / CT and curve data on plan\"; }"
  "      : toggle     { key = \"slab\";   label = \"Show straight sections (S1, S2...) on plan\"; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Road Edge and Centre\";"
  "      : row {"
  "        : toggle { key = \"bl\"; label = \"Left edge\"; }"
  "        : toggle { key = \"br\"; label = \"Right edge\"; }"
  "      }"
  "      : popup_list { key = \"etype\"; label = \"Edge:\";   edit_width = 24; }"
  "      : popup_list { key = \"ctype\"; label = \"Centre:\"; edit_width = 24; }"
  "      : edit_box { key = \"blen\"; label = \"Unit length / cone spacing (m):\"; edit_width = 6; }"
  "      : edit_box { key = \"bwid\"; label = \"Unit / cone / kerb width (m):\";   edit_width = 6; }"
  "      : edit_box { key = \"bgap\"; label = \"Paved shoulder (m):\";             edit_width = 6; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Signs and Markings\";"
  "      : row { : toggle { key = \"sspeed\"; label = \"Speed limit\"; }"
  "              : edit_box { key = \"speed\"; label = \"km/h:\"; edit_width = 5; } }"
  "      : row { : toggle { key = \"swarn\"; label = \"Bend ahead\"; }"
  "              : edit_box { key = \"warnd\"; label = \"before (m):\"; edit_width = 5; } }"
  "      : toggle     { key = \"srw\";    label = \"Road works ahead (with plate)\"; }"
  "      : toggle     { key = \"schev\";  label = \"Chevron boards on bends\"; }"
  "      : toggle     { key = \"skr\";    label = \"Keep right at median\"; }"
  "      : toggle     { key = \"sarr\";   label = \"Lane direction arrows\"; }"
  "      : popup_list { key = \"jctl\";   label = \"At tie-in:\"; edit_width = 16; }"
  "      : toggle     { key = \"twoway\"; label = \"Two-way traffic (signs both ways)\"; }"
  "      : toggle     { key = \"sauto\";  label = \"Sizes and distances by speed (HDS)\"; }"
  "      : popup_list { key = \"sset\";   label = \"Sign set:\"; edit_width = 18; }"
  "      : row { : edit_box { key = \"signsz\"; label = \"Symbol (m):\"; edit_width = 5; }"
  "              : edit_box { key = \"ssp\"; label = \"Spacing (m):\"; edit_width = 5; } }"
  "    }"
  "  }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Surface and Centre Line\";"
  "      : toggle   { key = \"hatch\";  label = \"Hatch road surface\"; }"
  "      : edit_box { key = \"hpat\";   label = \"Hatch pattern:\";             edit_width = 10; }"
  "      : edit_box { key = \"hscl\";   label = \"Pattern scale (not SOLID):\"; edit_width = 10; }"
  "      : toggle   { key = \"cltext\"; label = \"Show CL text in centre line\"; }"
  "      : toggle   { key = \"mark\";   label = \"Road markings (centre + edge lines)\"; }"
  "      : popup_list { key = \"cmark\";  label = \"Centre marking:\"; edit_width = 22; }"
  "      : toggle   { key = \"slow\";   label = \"SLOW markings before bends\"; }"
  "      : toggle   { key = \"deli\";   label = \"Delineator posts on curves\"; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Chainage\";"
  "      : toggle   { key = \"ch\";    label = \"Add chainage ticks and labels\"; }"
  "      : edit_box { key = \"chint\"; label = \"Interval (m):\";        edit_width = 8; }"
  "      : edit_box { key = \"chst\";  label = \"Start chainage (m):\";  edit_width = 8; }"
  "      : edit_box { key = \"txth\";  label = \"Text height (m):\";     edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Road Ends and Report\";"
  "      : popup_list { key = \"endst\"; label = \"Start end:\";  edit_width = 26; }"
  "      : popup_list { key = \"endfn\"; label = \"Finish end:\"; edit_width = 26; }"
  "      : toggle     { key = \"report\"; label = \"Report tables + Excel (CSV) file\"; }"
  "      : toggle     { key = \"xsec\";   label = \"Typical cross section drawing\"; }"
  "    }"
  "  }"
  "  : row {"
  "    : button { key = \"corr\"; label = \"Lanes, median, sidewalks, drains, utilities...\"; width = 44; fixed_width = true; }"
  "    : text   { key = \"csum\"; width = 80; }"
  "  }"
  "  : text { label = \"Developed by https://www.exceltokml.com/\"; alignment = right; }"
  "  ok_cancel;"
  "  errtile;"
  "}"))

;;----------------------------------------------------------------------------
;;  Settings (remembered between sessions)
;;----------------------------------------------------------------------------
(defun rp:val (k / v)
  (setq v (getenv (strcat "RoadPro_" k)))
  (if (and v (/= v "")) v (cdr (assoc k *rp:defaults*))))

(defun rp:set (k v) (setenv (strcat "RoadPro_" k) v))

;; Number from text : plain metres "100" or chainage format "0+100" / "1+250.5"
(defun rp:dist (s / p a b)
  (if s (setq s (vl-string-trim " " s)))
  (if (and s (= (substr s 1 1) "+")) (setq s (substr s 2)))
  (if (and s (setq p (vl-string-search "+" s)) (> p 0))
    (if (and (setq a (distof (vl-string-trim " " (substr s 1 p)) 2))
             (setq b (distof (vl-string-trim " " (substr s (+ p 2))) 2)))
      (+ (* a 1000.0) b))
    (if s (distof (vl-string-trim " " s) 2))))

(defun rp:num (k / v)
  (if (setq v (rp:dist (rp:val k))) v (rp:dist (cdr (assoc k *rp:defaults*)))))

(defun rp:on (k) (= (rp:val k) "1"))

;;----------------------------------------------------------------------------
;;  Start / finish / error handling
;;----------------------------------------------------------------------------
(defun rp:start ()
  (setq *rp:doc*    (vla-get-ActiveDocument (vlax-get-acad-object))
        *rp:olderr* *error*
        *error*     rp:error
        *rp:ucs*    nil
        *rp:sv*     (mapcar '(lambda (v) (cons v (getvar v)))
                            '("CMDECHO" "PLINETYPE" "PLINEWID" "FILLETRAD" "PEDITACCEPT" "OSMODE")))
  (vla-StartUndoMark *rp:doc*)
  (setq *rp:mk0* (entlast) *rp:cset* nil *rp:cov* nil *rp:xc* nil *rp:lanes* nil *rp:cinx* nil)
  (setvar "CMDECHO" 0))

(defun rp:finish ()
  (if *rp:ucs*
    (progn
      (setq *rp:ucs* nil)
      (if command-s (command-s "_.UCS" "_P") (vl-cmdf "_.UCS" "_P"))))
  (foreach p *rp:sv* (vl-catch-all-apply 'setvar (list (car p) (cdr p))))
  (setq *rp:sv* nil)
  (if *rp:doc* (vl-catch-all-apply 'vla-EndUndoMark (list *rp:doc*)))
  (setq *error* *rp:olderr*)
  (princ))

(defun rp:error (msg)
  (if (and msg (not (wcmatch (strcase msg T) "*break*,*cancel*,*exit*,*quit*")))
    (princ (strcat "\n** RoadPro error: " msg " **  (type U to undo)")))
  (rp:finish))

(defun rp:space ()
  (setq *rp:spc* (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1))
                   (vla-get-PaperSpace *rp:doc*)
                   (vla-get-ModelSpace *rp:doc*))))

(defun rp:world ()
  (if (= (getvar "WORLDUCS") 0) (progn (command "_.UCS" "_W") (setq *rp:ucs* T))))

;;----------------------------------------------------------------------------
;;  Dialog
;;----------------------------------------------------------------------------
(defun rp:fill (k lst) (start_list k) (mapcar 'add_list lst) (end_list))

(defun rp:dlg-modes (/ b)
  (setq b (if (or (= (get_tile "bl") "1") (= (get_tile "br") "1") (/= (get_tile "ctype") "0")) 0 1))
  (foreach k '("blen" "bwid") (mode_tile k b))
  (mode_tile "etype" (if (or (= (get_tile "bl") "1") (= (get_tile "br") "1")) 0 1))
  (foreach k '("radius" "rref") (mode_tile k (if (= (get_tile "rmode") "1") 0 1)))
  (foreach k '("hpat" "hscl") (mode_tile k (if (= (get_tile "hatch") "1") 0 1)))
  (foreach k '("chint" "chst" "txth") (mode_tile k (if (= (get_tile "ch") "1") 0 1)))
  (mode_tile "width" (if (= (rp:val "clmode") "1") 1 0))
  (mode_tile "keep" (if (= (get_tile "mode") "1") 0 1))
  (mode_tile "speed" (if (= (get_tile "sspeed") "1") 0 1))
  (mode_tile "warnd" (if (and (= (get_tile "swarn") "1") (/= (get_tile "sauto") "1")) 0 1)))

(defun rp:dlg-accept (/ bad v)
  ;; (key  name  0=must be > 0 / 1=may be zero)
  (foreach k '(("width"  "Road width"        0) ("radius" "Turning radius"    1)
               ("blen"   "Unit length"       0) ("bwid"   "Unit width"        0)
               ("bgap"   "Paved shoulder"    1) ("speed"  "Speed limit"       0)
               ("warnd"  "Warning distance"  1) ("signsz" "Sign symbol size"  0)
               ("ssp"    "Sign spacing"      0)
               ("hscl"   "Pattern scale"     0) ("chint"  "Chainage interval" 0)
               ("chst"   "Start chainage"    1) ("txth"   "Text height"       0))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (if (= (caddr k) 1) (< v 0.0) (<= v 0.0)))
          (setq bad k)))))
  (if bad
    (progn
      (set_tile "error" (strcat (cadr bad)
                                (if (= (caddr bad) 1)
                                  " must be zero or a positive number."
                                  " must be a number greater than zero.")))
      (mode_tile (car bad) 2))
    (progn
      (if (= (vl-string-trim " " (get_tile "hpat")) "") (set_tile "hpat" "SOLID"))
      (if (= (vl-string-trim " " (get_tile "rname")) "") (set_tile "rname" "ROAD-01"))
      (foreach k *rp:keys* (if (get_tile k) (rp:set k (get_tile k))))
      (rp:set "bc" (if (= (get_tile "ctype") "0") "0" "1"))
      (done_dialog 1))))

(defun rp:dialog (/ fn f id res)
  (setq fn (vl-filename-mktemp "roadpro.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:dcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadpro" id))
        (progn
          (rp:fill "rref"   '("Centre line (CL)" "Inner edge (kerb line)"))
          (rp:fill "rmode"  '("Match existing (keep CL as drawn)" "Manual radius at every bend"))
          (rp:fill "etype"  '("Barricades (red / white)" "Traffic cones" "Kerb stone"))
          (rp:fill "ctype"  '("Centre line markings (no barrier)" "Barricades (red / white)" "Traffic cones"))
          (rp:fill "sset"   '("Permanent" "Temporary (road works)"))
          (rp:fill "cmark"  '("Standard L1 / L2 / L2A by speed" "Double continuous white" "Single continuous L2A"))
          (rp:fill "units"  '("Meters  (1 unit = 1 m)" "Millimeters  (1 unit = 1 mm)"))
          (rp:fill "mode"   '("Pick points (draw new)" "Select existing Line/Pline/Arc"))
          (rp:fill "endst"  '("Tie-in line (existing road)" "Road closed (barricade+sign)" "None"))
          (rp:fill "endfn"  '("Tie-in line (existing road)" "Road closed (barricade+sign)" "None"))
          (rp:fill "jctl"   '("STOP sign" "GIVE WAY sign" "No sign"))
          (foreach k *rp:keys* (set_tile k (rp:val k)))
          (rp:dlg-modes)
          (rp:main-corr-tiles)
          (foreach k '("bl" "br" "ctype" "rmode" "hatch" "ch" "sspeed" "swarn" "sauto" "mode")
            (action_tile k "(rp:dlg-modes)"))
          (action_tile "corr" "(rp:main-corr)")
          (action_tile "accept" "(rp:dlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; Command-line fallback (only if the dialog cannot be shown)
(defun rp:cmdline (/ v)
  (initget 6)
  (if (setq v (getdist (strcat "\nRoad width in meters <" (rp:val "width") ">: ")))
    (rp:set "width" (rtos v 2 3)))
  (initget 4)
  (if (setq v (getdist (strcat "\nTurning radius in meters, 0 = none <" (rp:val "radius") ">: ")))
    (rp:set "radius" (rtos v 2 3))))

;;----------------------------------------------------------------------------
;;  Layers and linetypes
;;----------------------------------------------------------------------------
(defun rp:mklayer (name col lt lw / lay clr new)
  (setq new (not (tblsearch "LAYER" name))
        lay (vla-Add (vla-get-Layers *rp:doc*) name))
  (if new
    (progn
      (setq clr (vla-get-TrueColor lay))
      (if (listp col)
        (vla-SetRGB clr (car col) (cadr col) (caddr col))
        (vla-put-ColorIndex clr col))
      (vla-put-TrueColor lay clr)
      (if (and lt (tblsearch "LTYPE" lt)) (vla-put-Linetype lay lt))
      (if lw (vla-put-Lineweight lay lw))))
  (vl-catch-all-apply 'vla-put-Lock    (list lay :vlax-false))
  (vl-catch-all-apply 'vla-put-LayerOn (list lay :vlax-true))
  (vl-catch-all-apply 'vla-put-Freeze  (list lay :vlax-false))
  lay)

(defun rp:layers ()
  (rp:mklayer "ROAD-CL"              '(255 0 0)     "ROAD_CL2" 18)
  (rp:mklayer "ROAD-EDGE"            7              nil        35)
  (rp:mklayer "ROAD-SURFACE"         8              nil        0)
  (rp:mklayer "ROAD-BARRIER-RED"     '(255 0 0)     nil        0)
  (rp:mklayer "ROAD-BARRIER-WHITE"   '(255 255 255) nil        0)
  (rp:mklayer "ROAD-BARRIER-OUTLINE" '(0 0 0)       nil        25)
  (rp:mklayer "ROAD-CHAINAGE"        3              nil        18)
  (rp:mklayer "ROAD-SIGN"            '(0 0 0)       nil        25)
  (rp:mklayer "ROAD-SIGN-RED"        '(255 0 0)     nil        0)
  (rp:mklayer "ROAD-SIGN-WHITE"      '(255 255 255) nil        0)
  (rp:mklayer "ROAD-TIEIN"           6              "ROAD_TIE" 35)
  (rp:mklayer "ROAD-REPORT"          7              nil        18)
  (rp:mklayer "ROAD-CURVE"           5              nil        18)
  (rp:mklayer "ROAD-SECTION"         30             nil        18)
  (rp:mklayer "ROAD-SIGN-BLUE"       '(0 82 164)    nil        0)
  (rp:mklayer "ROAD-MARKING"         8              nil        0)
  (rp:mklayer "ROAD-MARKING-FILL"    '(255 255 255) nil        0)
  (rp:mklayer "ROAD-XSEC"            7              nil        35)
  (rp:mklayer "ROAD-XSEC-THIN"       8              nil        13)
  (rp:mklayer "ROAD-XSEC-DIM"        3              nil        13)
  (rp:mklayer "ROAD-XSEC-TEXT"       7              nil        18)
  (rp:mklayer "ROAD-XSEC-L1"         '(64 64 64)    nil        0)
  (rp:mklayer "ROAD-XSEC-L2"         '(181 140 90)  nil        0)
  (rp:mklayer "ROAD-XSEC-L3"         '(214 196 150) nil        0)
  (rp:mklayer "ROAD-XSEC-SHLD"       '(228 218 196) nil        0)
  (rp:mklayer "ROAD-XSEC-CONC"       '(170 170 170) nil        0)
  (rp:mklayer "ROAD-WIDENING"        40             nil        18)
  (rp:mklayer "ROAD-JUNCTION"        4              nil        18)
  (rp:mklayer "ROAD-SHOULDER"        '(110 116 122) nil        0)
  (rp:mklayer "ROAD-CONE"            '(225 25 25)   nil        0)
  (rp:mklayer "ROAD-CONE-BAND"       '(255 255 255) nil        0)
  (rp:mklayer "ROAD-SIGN-YELLOW"     '(255 210 0)   nil        0)
  (rp:mklayer "ROAD-DELINEATOR"      '(255 255 255) nil        13)
  (rp:mklayer "ROAD-KERB"            '(190 190 190) nil        0)
  (rp:mklayer "ROAD-MARKING-YELLOW"  '(255 204 0)   nil        0)
  (rp:mklayer "ROAD-ISLAND"          '(160 160 160) nil        25)
  (rp:mklayer "ROAD-MEDIAN"          '(118 150 92)  nil        0)
  (rp:mklayer "ROAD-MEDIAN-KERB"     '(190 190 190) nil        25)
  (rp:mklayer "ROAD-SIDEWALK"        '(201 162 122) nil        18)
  (rp:mklayer "ROAD-WALKWAY"         '(216 180 142) nil        18)
  (rp:mklayer "ROAD-DRAIN"           '(47 127 208)  nil        25)
  (rp:mklayer "ROAD-UTILITY"         '(138 79 192)  "ROAD_TIE" 18))

;; Custom linetypes, defined in meters (scaled automatically for mm drawings)
(defun rp:linetypes (/ lts fn f)
  (setq lts (vla-get-Linetypes *rp:doc*))
  (if (not (and (tblsearch "LTYPE" "ROAD_CL") (tblsearch "LTYPE" "ROAD_CL2")
                (tblsearch "LTYPE" "ROAD_TIE")))
    (progn
      (setq fn (strcat (getvar "TEMPPREFIX") "roadpro.lin"))
      (if (setq f (open fn "w"))
        (progn
          (foreach l '("*ROAD_CL,Road centre line ---- CL ---- CL ----"
                       "A,10,-1.2,[\"CL\",STANDARD,S=0.8,U=0.0,X=-0.7,Y=-0.4],-1.0"
                       "*ROAD_CL2,Road centre line ____ . ____ . ____"
                       "A,6,-1,1,-1"
                       "*ROAD_TIE,Tie-in line __ __ __ __"
                       "A,1.5,-0.75")
            (write-line l f))
          (close f)
          (foreach n '("ROAD_CL" "ROAD_CL2" "ROAD_TIE")
            (if (not (tblsearch "LTYPE" n))
              (vl-catch-all-apply 'vla-Load (list lts n fn)))))))))

(defun rp:cl-ltype (/ n fn)
  (setq n (if (rp:on "cltext") "ROAD_CL" "ROAD_CL2"))
  (cond
    ((tblsearch "LTYPE" n) n)
    ((tblsearch "LTYPE" "ROAD_CL2") "ROAD_CL2")
    (T
     (if (and (not (tblsearch "LTYPE" "CENTER")) (setq fn (findfile "acadiso.lin")))
       (vl-catch-all-apply 'vla-Load (list (vla-get-Linetypes *rp:doc*) "CENTER" fn)))
     (if (tblsearch "LTYPE" "CENTER") "CENTER" "Continuous"))))

;;----------------------------------------------------------------------------
;;  Geometry helpers
;;----------------------------------------------------------------------------
;; Point at distance d along the curve, shifted sideways by off (+ = left)
(defun rp:offpt (cl d off / par p dv l)
  (setq d   (max 0.0 (min d *rp:len*))
        par (vlax-curve-getParamAtDist cl d))
  (if (null par)
    (setq par (if (< d (* 0.5 *rp:len*))
                (vlax-curve-getStartParam cl)
                (vlax-curve-getEndParam cl))))
  (setq p  (vlax-curve-getPointAtParam cl par)
        dv (vlax-curve-getFirstDeriv cl par)
        l  (distance '(0.0 0.0) (list (car dv) (cadr dv))))
  (if (< l 1e-12) (setq l 1.0))
  (list (- (car p)  (* off (/ (cadr dv) l)))
        (+ (cadr p) (* off (/ (car dv) l)))))

;; Local frame at distance d : (point  left-normal  tangent)
(defun rp:frame (cl d / p q n)
  (setq p (rp:offpt cl d 0.0)
        q (rp:offpt cl d 1.0)
        n (list (- (car q) (car p)) (- (cadr q) (cadr p))))
  (list p n (list (cadr n) (- (car n)))))

;; Point in a frame: s along the left normal, u along the tangent
(defun rp:loc (f s u)
  (list (+ (car (car f))  (* s (car (cadr f)))  (* u (car (caddr f))))
        (+ (cadr (car f)) (* s (cadr (cadr f))) (* u (cadr (caddr f))))))

;; Scale, rotate and move a list of 2D points
(defun rp:xf (pts c a s)
  (mapcar '(lambda (p)
             (list (+ (car c)  (* s (- (* (car p) (cos a)) (* (cadr p) (sin a)))))
                   (+ (cadr c) (* s (+ (* (car p) (sin a)) (* (cadr p) (cos a)))))))
          pts))

(defun rp:xf1 (p c s) (car (rp:xf (list p) c 0.0 s)))

(defun rp:p3 (p z) (vlax-3d-point (list (car p) (cadr p) z)))

(defun rp:objarr (lst)
  (vlax-make-variant
    (vlax-safearray-fill
      (vlax-make-safearray vlax-vbObject (cons 0 (1- (length lst))))
      lst)))

;; vl = list of (point bulge)
(defun rp:mkpl (vl lay elev closed / e)
  (setq e (entmakex
            (append
              (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 lay)
                    '(100 . "AcDbPolyline") (cons 90 (length vl))
                    (cons 70 (if closed 1 0)) (cons 38 elev))
              (apply 'append
                     (mapcar '(lambda (v) (list (cons 10 (car v)) (cons 42 (cadr v)))) vl)))))
  (if e (vlax-ename->vla-object e)))

(defun rp:poly (pts lay elev) (rp:mkpl (mapcar '(lambda (p) (list p 0.0)) pts) lay elev T))

;; Open polyline with widths : vl = list of (point start-width end-width)
(defun rp:mkwpl (vl lay elev)
  (entmakex
    (append
      (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 lay)
            '(100 . "AcDbPolyline") (cons 90 (length vl)) '(70 . 0) (cons 38 elev))
      (apply 'append
             (mapcar '(lambda (v) (list (cons 10 (car v)) (cons 40 (cadr v))
                                        (cons 41 (caddr v)) '(42 . 0.0)))
                     vl)))))

(defun rp:pldata (o / co pts bl i)
  (setq co (vlax-safearray->list (vlax-variant-value (vla-get-Coordinates o))) i 0)
  (while co (setq pts (cons (list (car co) (cadr co)) pts) co (cddr co)))
  (setq pts (reverse pts))
  (repeat (length pts) (setq bl (cons (vla-GetBulge o i) bl) i (1+ i)))
  (list pts (reverse bl)))

;; Closed boundary = edge 1 forward + edge 2 backward (arcs kept exact)
(defun rp:bnd-verts (o1 o2 / d1 d2)
  (setq d1 (rp:pldata o1) d2 (rp:pldata o2))
  (mapcar 'list
          (append (car d1) (reverse (car d2)))
          (append (reverse (cons 0.0 (cdr (reverse (cadr d1)))))
                  (mapcar '- (cdr (reverse (cadr d2))))
                  '(0.0))))

(defun rp:offset (o d / r)
  (setq r (vl-catch-all-apply 'vla-Offset (list o d)))
  (if (vl-catch-all-error-p r) nil (vlax-safearray->list (vlax-variant-value r))))

(defun rp:props (o lay lt lts / c)
  (vla-put-Layer o lay)
  (setq c (vla-get-TrueColor o))
  (vla-put-ColorMethod c acColorMethodByLayer)
  (vla-put-TrueColor o c)
  (vla-put-Linetype o lt)
  (vla-put-LinetypeScale o lts)
  (vla-put-Lineweight o acLnWtByLayer)
  (vl-catch-all-apply 'vla-put-ConstantWidth (list o 0.0)))

(defun rp:newhatch (pat asc elev / a h)
  (setq a (if asc :vlax-true :vlax-false)
        h (vl-catch-all-apply 'vla-AddHatch
            (list *rp:spc* acHatchPatternTypePreDefined pat a)))
  (if (vl-catch-all-error-p h)
    (progn
      (princ (strcat "\nHatch pattern \"" pat "\" not found - using SOLID."))
      (setq h (vla-AddHatch *rp:spc* acHatchPatternTypePreDefined "SOLID" a))))
  (vla-put-Elevation h elev)
  h)

;; Solid fill inside outer object (optionally minus inner object)
(defun rp:solidfill (outer inner lay elev / h)
  (setq h (rp:newhatch "SOLID" T elev))
  (vla-put-Layer h lay)
  (vla-AppendOuterLoop h (rp:objarr (list outer)))
  (if inner (vla-AppendInnerLoop h (rp:objarr (list inner))))
  (vla-Evaluate h)
  (setq *rp:hatches* (cons h *rp:hatches*))
  h)

(defun rp:text (str pt h lay elev / tx)
  (setq tx (vla-AddText *rp:spc* str (rp:p3 pt elev) h))
  (vla-put-Alignment tx acAlignmentMiddleCenter)
  (vla-put-TextAlignmentPoint tx (rp:p3 pt elev))
  (vla-put-Layer tx lay)
  tx)

(defun rp:toback (objs / ss)
  (setq ss (ssadd))
  (foreach o objs (ssadd (vlax-vla-object->ename o) ss))
  (if (> (sslength ss) 0) (command "_.DRAWORDER" ss "" "_B")))

;; Curves (arc segments) of a polyline : list of
;; (dist-start dist-end radius deflection direction(+1 left/-1 right) TC-point CT-point)
(defun rp:curves (o / n i b p1 p2 a ch rr lst)
  (setq n (fix (+ 0.5 (vlax-curve-getEndParam o))) i 0)
  (repeat n
    (setq b (vla-GetBulge o i))
    (if (> (abs b) 1e-9)
      (progn
        (setq p1 (vlax-curve-getPointAtParam o i)
              p2 (vlax-curve-getPointAtParam o (1+ i))
              a  (* 4.0 (atan (abs b)))
              ch (distance p1 p2)
              rr (/ ch (* 2.0 (sin (/ a 2.0)))))
        (setq lst (cons (list (vlax-curve-getDistAtParam o i)
                              (vlax-curve-getDistAtParam o (1+ i))
                              rr a (if (> b 0) 1 -1) p1 p2)
                        lst))))
    (setq i (1+ i)))
  (reverse lst))

;;----------------------------------------------------------------------------
;;  Centre line input
;;----------------------------------------------------------------------------
(defun rp:get-centreline (/ prev e sel typ)
  (cond
    (*rp:presetcl* (setq e *rp:presetcl*))
    ((= (rp:val "mode") "0")
     (setvar "PLINETYPE" 2)
     (setvar "PLINEWID" 0.0)
     (setq prev (entlast))
     (princ "\nDraw the road centre line (Arc option allowed, Enter to finish):")
     (setvar "CMDECHO" 1)
     (command "_.PLINE")
     (while (> (getvar "CMDACTIVE") 0) (command pause))
     (setvar "CMDECHO" 0)
     (setq e (entlast))
     (if (equal e prev) (setq e nil)))
    (T
     (while
       (and (setq sel (entsel "\nSelect road centre line (Line / 2D Polyline / Arc / Civil 3D alignment): "))
            (not (wcmatch (cdr (assoc 0 (entget (car sel)))) "LINE,ARC,LWPOLYLINE,AECC_ALIGNMENT")))
       (princ "\n  Not supported - pick a Line, Arc, 2D (LW) Polyline or Civil 3D alignment."))
     (if sel
       (progn
         (setq e (car sel) typ (cdr (assoc 0 (entget e))))
         (cond
           ((= typ "AECC_ALIGNMENT")
            (setq e (rp:c3d-align e) typ "LWPOLYLINE")
            (if (and e *rp:c3dsta*)
              (progn
                (rp:set "chst" (rtos *rp:c3dsta* 2 3))
                (princ (strcat "\n  Start chainage set from the alignment: " (rtos *rp:c3dsta* 2 3))))))
           ((rp:on "keep")
            (setq e (vlax-vla-object->ename (vla-Copy (vlax-ename->vla-object e))))
            (princ "\n  The original line is kept - the road is built on a copy.")))
         (if (and e (/= typ "LWPOLYLINE"))
           (progn
             (setvar "PEDITACCEPT" 1)
             (command "_.PEDIT" e "")
             (setq e (entlast))))))))
  (if (and e
           (= (cdr (assoc 0 (entget e))) "LWPOLYLINE")
           (> (vlax-curve-getDistAtParam e (vlax-curve-getEndParam e)) 1e-6))
    e
    (progn (princ "\nNo valid centre line - nothing created.") nil)))

;;----------------------------------------------------------------------------
;;  Road surface hatch
;;----------------------------------------------------------------------------
(defun rp:surface (cl e1 e2 elev / o1 o2 tmp h bnd pat r)
  (if (and (= (length e1) 1) (= (length e2) 1))
    (progn
      (setq o1  (car e1)
            o2  (car e2)
            pat (strcase (vl-string-trim " " (rp:val "hpat"))))
      (if (vlax-curve-isClosed cl)
        (progn
          (if (< (vla-get-Area o1) (vla-get-Area o2)) (setq tmp o1 o1 o2 o2 tmp))
          (setq h (rp:newhatch pat T elev))
          (vla-put-Layer h "ROAD-SURFACE")
          (setq r (vl-catch-all-apply
                    (function
                      (lambda ()
                        (vla-AppendOuterLoop h (rp:objarr (list o1)))
                        (vla-AppendInnerLoop h (rp:objarr (list o2)))))
                    nil)))
        (progn
          (setq bnd (rp:mkpl (rp:bnd-verts o1 o2) "ROAD-SURFACE" elev T)
                h   (rp:newhatch pat nil elev))
          (vla-put-Layer h "ROAD-SURFACE")
          (setq r (vl-catch-all-apply 'vla-AppendOuterLoop (list h (rp:objarr (list bnd)))))))
      (cond
        ((vl-catch-all-error-p r)
         (vla-Delete h)
         (setq h nil)
         (princ "\nWarning: road surface hatch could not be created."))
        (T
         (if (/= (vla-get-PatternName h) "SOLID")
           (vl-catch-all-apply 'vla-put-PatternScale (list h (rp:num "hscl"))))
         (vla-Evaluate h)
         (vl-catch-all-apply 'vla-put-EntityTransparency (list h "50"))))
      (if bnd (vla-Delete bnd))
      h)
    (progn
      (princ "\nWarning: surface hatch skipped (edge offset split into several pieces).")
      nil)))

;;----------------------------------------------------------------------------
;;  Bands, cones and kerbs along a road
;;----------------------------------------------------------------------------
;; Solid band between side offsets o1 and o2 (+ left), chunked every 50 m.
;; lines = T also draws the two long boundary lines (black)
(defun rp:band (cl a b o1 o2 lay elev fac lines / s0 s1 n i d pa pb bnd h)
  (setq s0 a)
  (while (< s0 (- b 1e-6))
    (setq s1 (min b (+ s0 (* 50.0 fac)))
          n  (max 1 (fix (+ 0.999999 (/ (- s1 s0) fac))))
          i  0 pa nil pb nil)
    (repeat (1+ n)
      (setq d  (+ s0 (* (- s1 s0) (/ (float i) n)))
            pa (cons (rp:offpt cl d o1) pa)
            pb (cons (rp:offpt cl d o2) pb)
            i  (1+ i)))
    (setq bnd (rp:poly (append (reverse pa) pb) lay elev)
          h   (rp:newhatch "SOLID" nil elev))
    (vla-put-Layer h lay)
    (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-AppendOuterLoop (list h (rp:objarr (list bnd))))))
      (progn (vla-Evaluate h) (setq *rp:hatches* (cons h *rp:hatches*)))
      (vla-Delete h))
    (vla-Delete bnd)
    (setq s0 s1))
  (if lines
    (foreach o (list o1 o2)
      (setq i 0 pa nil n (max 1 (fix (+ 0.999999 (/ (- b a) fac)))))
      (repeat (1+ n)
        (setq pa (cons (list (rp:offpt cl (+ a (* (- b a) (/ (float i) n))) o) 0.0) pa) i (1+ i)))
      (rp:mkpl (reverse pa) "ROAD-BARRIER-OUTLINE" elev nil)))
  (- b a))

;; Traffic cone symbol (plan) : orange disc, white band, black outline
(defun rp:cone (c dia elev / o i)
  (setq o (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.5 dia))
        i (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.3 dia)))
  (vla-put-Layer o "ROAD-BARRIER-OUTLINE")
  (vla-put-Layer i "ROAD-CONE-BAND")
  (rp:solidfill o i "ROAD-CONE" elev)
  (rp:solidfill i nil "ROAD-CONE-BAND" elev)
  (vla-put-Layer (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.12 dia)) "ROAD-BARRIER-OUTLINE"))

;; Cones along the road at side offset off, every sp. Returns the count
(defun rp:cones (cl len off sp dia elev / d n)
  (setq d (* 0.5 sp) n 0)
  (while (<= d len)
    (rp:cone (rp:offpt cl d off) dia elev)
    (setq n (1+ n) d (+ d sp)))
  n)

;;----------------------------------------------------------------------------
;;  Barricades : alternating red / white units between side offsets d1 and d2
;;----------------------------------------------------------------------------
;; One run of edge treatment between side offsets d1 (inner) and d2 (outer).
;; typ "0" barricades / "1" traffic cones / "2" kerb stone.
;; Returns (red white cones kerb-length)
(defun rp:edge-run (cl len d1 d2 typ blen fac elev / r)
  (cond
    ((= typ "1")
     (list 0 0 (rp:cones cl len (* 0.5 (+ d1 d2)) blen (abs (- d2 d1)) elev) 0.0))
    ((= typ "2")
     (setq *rp:unitfill* "ROAD-KERB"
           r (rp:barrier cl len d1 d2 blen (min blen (* 0.25 fac)) elev)
           *rp:unitfill* nil)
     (list 0 0 0 len))
    (T
     (setq r (rp:barrier cl len d1 d2 blen (min blen (* 0.25 fac)) elev))
     (list (car r) (cadr r) 0 0.0))))

;; Does the road have an edge treatment on side sg ?
(defun rp:edge-on (data sg)
  (or (/= (rp:xv (if (> sg 0) "BL" "BR") data) "0,0")
      (= (rp:xv (if (> sg 0) "EL" "ER") data) "1")))

(defun rp:etype (data) (if (= (rp:xv "ETYPE" data) "") "0" (rp:xv "ETYPE" data)))

(defun rp:barrier (cl len d1 d2 seg step elev / d de n i dd pa pb cnt nred nwht)
  (setq d 0.0 cnt 0 nred 0 nwht 0)
  (while (< d (- len 1e-6))
    (setq de (+ d seg))
    (if (> de (- len (* 0.25 seg))) (setq de len))      ; no tiny slivers at the end
    (setq n  (max 1 (fix (+ 0.999999 (/ (- de d) step))))
          pa nil pb nil i 0)
    (repeat (1+ n)
      (setq dd (+ d (* (- de d) (/ (float i) n)))
            pa (cons (rp:offpt cl dd d1) pa)
            pb (cons (rp:offpt cl dd d2) pb)
            i  (1+ i)))
    (rp:solidfill (rp:poly (append (reverse pa) pb) "ROAD-BARRIER-OUTLINE" elev)
                  nil
                  (cond (*rp:unitfill* *rp:unitfill*)
                        ((= 0 (rem cnt 2)) "ROAD-BARRIER-RED")
                        (T "ROAD-BARRIER-WHITE"))
                  elev)
    (if (= 0 (rem cnt 2)) (setq nred (1+ nred)) (setq nwht (1+ nwht)))
    (setq cnt (1+ cnt) d de))
  (list nred nwht))

;;----------------------------------------------------------------------------
;;  Signs
;;----------------------------------------------------------------------------
;; Speed limit : red ring, white centre, black number
(defun rp:sign-speed (c sz spd elev / o i)
  (setq o (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.5 sz))
        i (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.39 sz)))
  (vla-put-Layer o "ROAD-SIGN")
  (vla-put-Layer i "ROAD-SIGN-RED")
  (rp:solidfill o i "ROAD-SIGN-RED" elev)
  (rp:solidfill i nil "ROAD-SIGN-WHITE" elev)
  (rp:text spd c (* 0.32 sz) "ROAD-SIGN" elev))

;; Curve warning : red triangle with bend arrow (dir -1 = bend left, +1 = right)
(defun rp:pt+ (p v k) (list (+ (car p) (* k (car v))) (+ (cadr p) (* k (cadr v)))))

;; Triangle sign body : black outline, red border, white centre (inv = point down)
(defun rp:tri-sign (c sz elev inv / tri o i)
  (setq tri (if inv
              '((0.0 -0.57735) (0.5 0.288675) (-0.5 0.288675))
              '((0.0 0.57735) (-0.5 -0.288675) (0.5 -0.288675)))
        o   (rp:poly (rp:xf tri c 0.0 sz) "ROAD-SIGN" elev)
        i   (rp:poly (rp:xf tri c 0.0 (* 0.62 sz)) "ROAD-SIGN-RED" elev))
  (rp:solidfill o i "ROAD-SIGN-RED" elev)
  ;; warning triangles : yellow background (HDS Fig 19.1.2.1); give way : white
  (rp:solidfill i nil (if inv "ROAD-SIGN-WHITE" "ROAD-SIGN-YELLOW") elev))

;; Bend ahead : triangle with bend arrow (dir -1 = bend left, +1 = bend right)
(defun rp:sign-warn (c sz dir elev)
  (rp:tri-sign c sz elev nil)
  (rp:mkwpl
    (list (list (rp:xf1 '(0.0 -0.13) c sz) (* 0.035 sz) (* 0.035 sz))
          (list (rp:xf1 '(0.0 0.0) c sz)   (* 0.035 sz) (* 0.035 sz))
          (list (rp:xf1 (list (* dir 0.05) 0.05) c sz) (* 0.10 sz) 0.0)
          (list (rp:xf1 (list (* dir 0.11) 0.11) c sz) 0.0 0.0))
    "ROAD-SIGN" elev))

;; Road works ahead : triangle with "!" and a ROAD WORKS supplementary plate
(defun rp:icon-works (c sz elev / d)
  (rp:tri-sign c sz elev nil)
  (rp:solidfill (rp:poly (rp:xf '((-0.03 -0.03) (0.03 -0.03) (0.045 0.2) (-0.045 0.2)) c 0.0 sz)
                         "ROAD-SIGN" elev)
                nil "ROAD-SIGN" elev)
  (setq d (vla-AddCircle *rp:spc* (rp:p3 (rp:xf1 '(0.0 -0.1) c sz) elev) (* 0.04 sz)))
  (vla-put-Layer d "ROAD-SIGN")
  (rp:solidfill d nil "ROAD-SIGN" elev)
  (rp:solidfill (rp:poly (rp:xf '((-0.75 -0.72) (0.75 -0.72) (0.75 -0.4) (-0.75 -0.4)) c 0.0 sz)
                         "ROAD-SIGN" elev)
                nil "ROAD-SIGN-WHITE" elev)
  (rp:text "ROAD WORKS" (rp:xf1 '(0.0 -0.56) c sz) (* 0.14 sz) "ROAD-SIGN" elev))

(defun rp:ngon (n r a0 / i lst)
  (setq i 0)
  (repeat n
    (setq lst (cons (list (* r (cos (+ a0 (/ (* 2.0 pi i) n))))
                          (* r (sin (+ a0 (/ (* 2.0 pi i) n)))))
                    lst)
          i   (1+ i)))
  (reverse lst))

;; STOP : red octagon, white border, white STOP text
(defun rp:icon-stop (c sz elev / b)
  (rp:solidfill (rp:poly (rp:xf (rp:ngon 8 0.5 (/ pi 8.0)) c 0.0 sz) "ROAD-SIGN" elev)
                nil "ROAD-SIGN-RED" elev)
  (setq b (rp:poly (rp:xf (rp:ngon 8 0.45 (/ pi 8.0)) c 0.0 sz) "ROAD-SIGN-WHITE" elev))
  (vla-put-ConstantWidth b (* 0.025 sz))
  (rp:text "STOP" c (* 0.22 sz) "ROAD-SIGN-WHITE" elev))

;; GIVE WAY : inverted triangle
(defun rp:icon-giveway (c sz elev) (rp:tri-sign c sz elev T))

;; NO ENTRY : red disc with white bar
(defun rp:icon-noentry (c sz elev / o)
  (setq o (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.5 sz)))
  (vla-put-Layer o "ROAD-SIGN")
  (rp:solidfill o nil "ROAD-SIGN-RED" elev)
  (rp:solidfill (rp:poly (rp:xf '((-0.34 -0.08) (0.34 -0.08) (0.34 0.08) (-0.34 0.08)) c 0.0 sz)
                         "ROAD-SIGN-WHITE" elev)
                nil "ROAD-SIGN-WHITE" elev))

;; KEEP RIGHT : blue disc with white arrow pointing down-right
(defun rp:icon-keepright (c sz elev / o)
  (setq o (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.5 sz)))
  (vla-put-Layer o "ROAD-SIGN")
  (rp:solidfill o nil "ROAD-SIGN-BLUE" elev)
  (rp:solidfill (rp:poly (rp:xf '((-0.3 -0.06) (0.1 -0.06) (0.1 -0.16) (0.32 0.0)
                                  (0.1 0.16) (0.1 0.06) (-0.3 0.06))
                                c (* -0.25 pi) sz)
                         "ROAD-SIGN-WHITE" elev)
                nil "ROAD-SIGN-WHITE" elev))

(defun rp:draw-icon (typ c sz arg elev)
  (cond
    ((= typ "speed")     (rp:sign-speed c sz arg elev))
    ((= typ "warn")      (rp:sign-warn c sz (atof arg) elev))
    ((= typ "works")     (rp:icon-works c sz elev))
    ((= typ "stop")      (rp:icon-stop c sz elev))
    ((= typ "giveway")   (rp:icon-giveway c sz elev))
    ((= typ "noentry")   (rp:icon-noentry c sz elev))
    ((= typ "keepright") (rp:icon-keepright c sz elev))
    ((= typ "closed")    (rp:sign-closed c sz elev))))

;; Chevron board : white board with red chevron, pointing into the bend
(defun rp:chevron (c ang sz elev / k tmp)
  ;; permanent W37-1A : yellow board, black chevron ; road works 404/405 : black board, yellow chevron
  (setq k   (* 0.6 sz)
        tmp (= (rp:val "sset") "1"))
  (rp:solidfill (rp:poly (rp:xf '((-0.35 -0.45) (0.35 -0.45) (0.35 0.45) (-0.35 0.45)) c ang k)
                         "ROAD-SIGN" elev)
                nil (if tmp "ROAD-SIGN" "ROAD-SIGN-YELLOW") elev)
  (rp:solidfill (rp:poly (rp:xf '((-0.25 0.35) (0.0 0.35) (0.25 0.0) (0.0 -0.35) (-0.25 -0.35) (0.0 0.0))
                                c ang k)
                         "ROAD-SIGN" elev)
                nil (if tmp "ROAD-SIGN-YELLOW" "ROAD-SIGN") elev))

(defun rp:chevrons (cl c off sz fac elev / n k d f)
  (setq n (max 3 (1+ (fix (/ (- (cadr c) (car c)) (* 10.0 fac))))) k 0)
  (repeat n
    (setq d (+ (car c) (* (- (cadr c) (car c)) (/ (float k) (1- n))))
          f (rp:frame cl d))
    (rp:chevron (rp:loc f off 0.0)
                (+ (angle '(0.0 0.0) (caddr f)) (* (nth 4 c) 0.5 pi))
                sz elev)
    (setq k (1+ k)))
  n)

;; ROAD CLOSED : road works sign 406 (yellow diamond, black border and text)
;; for the temporary sign set, otherwise a white board with red border
(defun rp:sign-closed (c sz elev / o i)
  (if (= (rp:val "sset") "1")
    (progn
      (setq o (rp:poly (rp:xf '((0.0 -0.75) (0.75 0.0) (0.0 0.75) (-0.75 0.0)) c 0.0 sz) "ROAD-SIGN" elev))
      (vla-put-ConstantWidth o (* 0.03 sz))
      (rp:solidfill (rp:poly (rp:xf '((0.0 -0.75) (0.75 0.0) (0.0 0.75) (-0.75 0.0)) c 0.0 sz) "ROAD-SIGN" elev)
                    nil "ROAD-SIGN-YELLOW" elev)
      (rp:text "ROAD" (rp:xf1 '(0.0 0.1) c sz) (* 0.16 sz) "ROAD-SIGN" elev)
      (rp:text "CLOSED" (rp:xf1 '(0.0 -0.12) c sz) (* 0.16 sz) "ROAD-SIGN" elev))
    (rp:sign-closed-board c sz elev)))

(defun rp:sign-closed-board (c sz elev / o i)
  (setq o (rp:poly (rp:xf '((-1.1 -0.4) (1.1 -0.4) (1.1 0.4) (-1.1 0.4)) c 0.0 sz) "ROAD-SIGN" elev)
        i (rp:poly (rp:xf '((-1.0 -0.3) (1.0 -0.3) (1.0 0.3) (-1.0 0.3)) c 0.0 sz) "ROAD-SIGN-RED" elev))
  (rp:solidfill o i "ROAD-SIGN-RED" elev)
  (rp:solidfill i nil "ROAD-SIGN-WHITE" elev)
  (rp:text "ROAD CLOSED" c (* 0.17 sz) "ROAD-SIGN" elev))

;;----------------------------------------------------------------------------
;;  Oman HDS 2017 Section 19 values by speed limit (GCC Manual based)
;;  (triangle side, circular dia, STOP side, GIVE WAY height, warning distance)
;;  Tables 19.1.3.3, 19.1.3.4, 19.1.3.6. STOP / GIVE WAY sizes are not given
;;  for 100 and 120 km/h; the 80 km/h values are used there.
;;----------------------------------------------------------------------------
(defun rp:hds-row (spd)
  (cond ((<= spd 50) '(600 600 750 750 50))
        ((<= spd 60) '(750 750 900 750 75))
        ((<= spd 80) '(900 750 1200 900 150))
        ((<= spd 100) '(1200 900 1200 900 200))
        (T '(1500 1200 1200 900 300))))

;; plate size text for a sign type
(defun rp:plate (typ spd / r)
  (setq r (rp:hds-row spd))
  (cond ((member typ '("works" "warn")) (strcat "Triangle " (itoa (nth 0 r))))
        ((member typ '("speed" "keepright" "noentry")) (strcat "Circle " (itoa (nth 1 r))))
        ((= typ "stop") (strcat "Octagon " (itoa (nth 2 r))))
        ((= typ "giveway") (strcat "Triangle " (itoa (nth 3 r))))
        (T "-")))

;; lane line patterns (mark, gap) in m - Figure 19.2.1.1 table 1
(defun rp:l1 (spd) (cond ((<= spd 50) '(2.0 6.0)) ((<= spd 80) '(3.0 9.0)) (T '(4.0 12.0))))
(defun rp:l2 (spd) (cond ((<= spd 50) '(6.0 2.0)) ((<= spd 80) '(9.0 3.0)) (T '(12.0 4.0))))

;;----------------------------------------------------------------------------
;;  Signage engine : post + plate facing traffic + leader + symbol + ID tag
;;----------------------------------------------------------------------------
(defun rp:sign-post (post n ic sz fac id plate elev / pc)
  (setq pc (vla-AddCircle *rp:spc* (rp:p3 post elev) (* 0.15 fac)))
  (vla-put-Layer pc "ROAD-SIGN")
  (rp:solidfill pc nil "ROAD-SIGN" elev)
  (rp:mkwpl (list (list (rp:pt+ post n (* -0.45 fac)) (* 0.12 fac) (* 0.12 fac))
                  (list (rp:pt+ post n (* 0.45 fac)) 0.0 0.0))
            "ROAD-SIGN" elev)
  (if (> (distance post ic) (* 0.6 sz))
    (rp:line post (rp:towards ic post (* 0.55 sz)) "ROAD-SIGN" elev))
  (rp:text id (list (car ic) (- (cadr ic) (if plate (* 0.95 sz) (* 0.72 sz))))
           (* 0.22 sz) "ROAD-SIGN" elev))

;; r = (dist side facing type arg description)   side R / L / M(edian) / X(across)
(defun rp:draw-sign (cl r id sz fac elev offR offL xL len / d side f n post ic in)
  (setq d (car r) side (nth 1 r) f (rp:frame cl d) n (cadr f))
  (cond
    ((= side "R")
     (setq post (rp:loc f (- offR) 0.0)
           ic   (rp:loc f (- (+ offR (* 0.6 fac) (* 0.7 sz))) 0.0)))
    ((= side "L")
     (setq post (rp:loc f offL 0.0)
           ic   (rp:loc f (+ offL (* 0.6 fac) (* 0.7 sz) xL) 0.0)))
    ((= side "M")
     (setq post (car f)
           ic   (rp:loc f 0.0 (* (if (= (nth 2 r) "F") -1.0 1.0) (+ fac (* 0.8 sz))))))
    (T
     (setq in   (if (> d (* 0.5 len)) -1.0 1.0)
           post (car f)
           ic   (rp:loc f 0.0 (* -1.0 in (+ fac (* 0.5 sz)))))))
  (if (= side "X")
    (rp:text id (list (car ic) (- (cadr ic) (* 0.6 sz))) (* 0.22 sz) "ROAD-SIGN" elev)
    (progn
      (rp:draw-icon (nth 3 r) ic sz (nth 4 r) elev)
      (rp:sign-post post n ic sz fac id (= (nth 3 r) "works") elev)))
  post)

(defun rp:dpos (len dr d) (if (= dr 1) (min len d) (max 0.0 (- len d))))

;; Plans and draws all signs, returns the sign schedule :
;; list of (ID description chainage side facing E N type arg)
(defun rp:signs (cl len curves fac sz elev offR offL xL ends endf closed st
                 / two sp wd spd d0 reqs sd fc lr jt jd i id post sched)
  (setq two (rp:on "twoway")
        sp  (* fac (rp:num "ssp"))
        wd  (* fac (if (rp:on "sauto") (nth 4 (rp:hds-row (rp:num "speed"))) (rp:num "warnd")))
        spd (rtos (rp:num "speed") 2 0)
        d0  (min (* 5.0 fac) (* 0.25 len)))
  ;; entry signs : forward traffic at the start, reverse traffic at the end
  (foreach dr (if two '(1 -1) '(1))
    (setq sd (if (= dr 1) "R" "L") fc (if (= dr 1) "F" "B"))
    (if (rp:on "srw")
      (setq reqs (cons (list (rp:dpos len dr d0) sd fc "works" "" "Road works ahead") reqs)))
    (if (rp:on "sspeed")
      (setq reqs (cons (list (rp:dpos len dr (+ d0 (if (rp:on "srw") sp 0.0))) sd fc "speed" spd
                             (strcat "Speed limit " spd " km/h"))
                       reqs)))
    (if (and (rp:on "bc") (rp:on "skr"))
      (setq reqs (cons (list (rp:dpos len dr 0.0) "M" fc "keepright" "" "Keep right") reqs))))
  ;; bend ahead, before every bend of 10 deg or more
  (if (rp:on "swarn")
    (foreach c curves
      (if (>= (nth 3 c) (/ pi 18.0))
        (progn
          (setq lr (> (nth 4 c) 0))
          (setq reqs (cons (list (max 0.0 (- (car c) wd)) "R" "F" "warn" (if lr "-1" "1")
                                 (strcat "Bend ahead - " (if lr "left" "right")))
                           reqs))
          (if two
            (setq reqs (cons (list (min len (+ (cadr c) wd)) "L" "B" "warn" (if lr "1" "-1")
                                   (strcat "Bend ahead - " (if lr "right" "left")))
                             reqs)))))))
  ;; tie-in control, no entry, road closed boards
  (if (not closed)
    (progn
      (setq jt (cond ((= (rp:val "jctl") "0") "stop") ((= (rp:val "jctl") "1") "giveway"))
            jd (if (= jt "stop") "STOP" "Give way"))
      (if (and jt (member endf '("0" "3")))
        (setq reqs (cons (list (max 0.0 (- len (* 3.0 fac))) "R" "F" jt "" jd) reqs)))
      (if (and jt two (member ends '("0" "3")))
        (setq reqs (cons (list (min len (* 3.0 fac)) "L" "B" jt "" jd) reqs)))
      (if (and (not two) (/= endf "1"))
        (setq reqs (cons (list (max 0.0 (- len (* 3.0 fac))) "L" "B" "noentry" "" "No entry") reqs)))
      (if (= ends "1") (setq reqs (cons (list 0.0 "X" "B" "closed" "" "Road closed board") reqs)))
      (if (= endf "1") (setq reqs (cons (list len "X" "F" "closed" "" "Road closed board") reqs)))))
  ;; number in chainage order and draw
  (setq reqs (vl-sort reqs '(lambda (a b) (< (car a) (car b))))
        i    0)
  (foreach r reqs
    (setq i     (1+ i)
          id    (strcat "SG-" (rp:z2 i))
          post  (rp:draw-sign cl r id sz fac elev offR offL xL len)
          sched (cons (list id (nth 5 r) (rp:chfmt (+ st (/ (car r) fac)))
                            (cdr (assoc (nth 1 r) '(("R" . "Right") ("L" . "Left")
                                                    ("M" . "Median") ("X" . "Across road"))))
                            (if (= (nth 2 r) "F") "Forward (CH +)" "Reverse (CH -)")
                            (rtos (/ (car post) fac) 2 3) (rtos (/ (cadr post) fac) 2 3)
                            (nth 3 r) (nth 4 r)
                            (rp:plate (nth 3 r) (rp:num "speed")))
                      sched)))
  (reverse sched))

;; Lane direction arrow marking (5 m long), pointing in direction ang
;; Straight arrow S3 (HDS Fig 19.2.1.5) : 5.0 m long up to 60 km/h, 7.5 m above
(defun rp:arrow (c ang k elev / l h)
  (setq l (* 0.5 (if (and *rp:arrl* (> *rp:arrl* 0.0)) *rp:arrl* 5.0))
        h (- l 2.05))
  (rp:solidfill
    (rp:poly (rp:xf (list (list (- l) -0.075) (list h -0.075) (list h -0.375) (list l 0.0)
                          (list h 0.375) (list h 0.075) (list (- l) 0.075))
                    c ang k)
             "ROAD-MARKING" elev)
    nil "ROAD-MARKING-FILL" elev))

;; Delineator posts on the outside of a curve (HDS Fig 19.1.2.7) : spacing S by
;; radius inside the curve, then 2S, 3S, 6S (max 100 m) on the tangents
(defun rp:deli-s (r)
  (cond ((>= r 500.0) 50.0) ((>= r 300.0) (+ 30.0 (* 20.0 (/ (- r 300.0) 200.0))))
        ((>= r 200.0) (+ 20.0 (* 10.0 (/ (- r 200.0) 100.0))))
        ((>= r 100.0) (+ 15.0 (* 5.0 (/ (- r 100.0) 100.0))))
        ((>= r 75.0) (+ 12.0 (* 3.0 (/ (- r 75.0) 25.0))))
        ((>= r 50.0) (+ 10.0 (* 2.0 (/ (- r 50.0) 25.0))))
        ((>= r 25.0) (+ 7.0 (* 3.0 (/ (- r 25.0) 25.0))))
        (T 7.0)))

(defun rp:deli-post (p fac elev / o)
  (setq o (rp:poly (list (list (- (car p) (* 0.075 fac)) (- (cadr p) (* 0.075 fac)))
                         (list (+ (car p) (* 0.075 fac)) (- (cadr p) (* 0.075 fac)))
                         (list (+ (car p) (* 0.075 fac)) (+ (cadr p) (* 0.075 fac)))
                         (list (- (car p) (* 0.075 fac)) (+ (cadr p) (* 0.075 fac))))
                   "ROAD-BARRIER-OUTLINE" elev))
  (rp:solidfill o nil "ROAD-DELINEATOR" elev)
  (vla-put-Layer (vla-AddCircle *rp:spc* (rp:p3 p elev) (* 0.035 fac)) "ROAD-SIGN-RED"))

(defun rp:delineators (cl len curves offL offR fac elev / n c s sp d out lst)
  (setq n 0)
  (foreach c curves
    (if (>= (nth 3 c) (/ pi 36.0))
      (progn
        (setq s   (* fac (rp:deli-s (/ (nth 2 c) fac)))
              out (if (> (nth 4 c) 0) (- offR) offL)
              lst nil d (car c))
        (while (<= d (+ (cadr c) 1e-6)) (setq lst (cons d lst) d (+ d s)))
        (foreach k (list (* 2.0 s) (+ (* 2.0 s) (min (* 3.0 s) (* 100.0 fac)))
                         (+ (* 2.0 s) (min (* 3.0 s) (* 100.0 fac)) (min (* 6.0 s) (* 100.0 fac))))
          (setq lst (cons (- (car c) k) (cons (+ (cadr c) k) lst))))
        (foreach d lst
          (if (and (>= d 0.0) (<= d len))
            (progn (rp:deli-post (rp:offpt cl d out) fac elev) (setq n (1+ n))))))))
  n)

;; Arrows in both lanes on every straight of 12 m or more (one set per 60 m)
(defun rp:lane-arrows (cl strs hw fac two elev / n s ln k i d f a)
  (setq n 0)
  (foreach s strs
    (setq ln (- (cadr s) (car s)))
    (if (>= ln (* 12.0 fac))
      (progn
        (setq k (max 1 (fix (/ ln (* 60.0 fac)))) i 1)
        (repeat k
          (setq d (+ (car s) (* ln (/ (float i) (1+ k))))
                f (rp:frame cl d)
                a (angle '(0.0 0.0) (caddr f)))
          (if *rp:lanes*
            (foreach lnx *rp:lanes*
              (rp:arrow (rp:loc f (car lnx) 0.0) (if (and two (cadr lnx)) (+ a pi) a) fac elev)
              (setq n (1+ n)))
            (progn
              (rp:arrow (rp:loc f (* -0.5 hw) 0.0) a fac elev)
              (rp:arrow (rp:loc f (* 0.5 hw) 0.0) (if two (+ a pi) a) fac elev)
              (setq n (+ n 2))))
          (setq i (1+ i))))))
  n)

;; Left-aligned text
(defun rp:ltext (str pt h lay / tx)
  (setq tx (vla-AddText *rp:spc* str (rp:p3 pt 0.0) h))
  (vla-put-Alignment tx acAlignmentMiddleLeft)
  (vla-put-TextAlignmentPoint tx (rp:p3 pt 0.0))
  (vla-put-Layer tx lay)
  tx)

;; Sign legend with real symbols, for the report
(defun rp:legend (pt sched th / lz x y seen pc)
  (setq lz (* 3.0 th) x (car pt) y (cadr pt))
  (rp:ltext "SIGN LEGEND" (list x y) (* 1.3 th) "ROAD-REPORT")
  (setq y (- y (* 1.6 lz)))
  (foreach r sched
    (if (not (member (nth 1 r) seen))
      (progn
        (setq seen (cons (nth 1 r) seen))
        (rp:draw-icon (nth 7 r) (list (+ x lz) y) (if (= (nth 7 r) "closed") (* 0.6 lz) lz) (nth 8 r) 0.0)
        (rp:ltext (nth 1 r) (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT")
        (setq y (- y (if (= (nth 7 r) "works") (* 2.0 lz) (* 1.5 lz)))))))
  ;; post, chevron board, lane arrow, ID tag
  (setq pc (vla-AddCircle *rp:spc* (rp:p3 (list (+ x lz) y) 0.0) (* 0.06 lz)))
  (vla-put-Layer pc "ROAD-SIGN")
  (rp:solidfill pc nil "ROAD-SIGN" 0.0)
  (rp:mkwpl (list (list (list (+ x lz) (- y (* 0.25 lz))) (* 0.05 lz) (* 0.05 lz))
                  (list (list (+ x lz) (+ y (* 0.25 lz))) 0.0 0.0))
            "ROAD-SIGN" 0.0)
  (rp:ltext "Sign post with plate (plate faces the traffic)" (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT")
  (setq y (- y (* 1.3 lz)))
  (rp:chevron (list (+ x lz) y) 0.0 lz 0.0)
  (rp:ltext "Chevron board (points into the bend)" (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT")
  (setq y (- y (* 1.3 lz)))
  (rp:arrow (list (+ x lz) y) 0.0 (/ lz 4.0) 0.0)
  (rp:ltext "Lane direction arrow (road marking)" (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT")
  (setq y (- y (* 1.3 lz)))
  (rp:text "SG-01" (list (+ x lz) y) (* 0.5 th) "ROAD-SIGN" 0.0)
  (rp:ltext "Sign ID - see SIGN SCHEDULE" (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT"))

;;----------------------------------------------------------------------------
;;  Road ends : "0" tie-in line / "1" road closed / "2" none
;;  returns (red-units white-units road-closed-signs)
;;----------------------------------------------------------------------------
(defun rp:road-end (cl d atend mode hw blen bwid th fac sz elev ch / f in p s s2 cnt nr nw ln mt ip)
  (setq f (rp:frame cl d) in (if atend -1.0 1.0) p (car f) nr 0 nw 0)
  (cond
    ((= mode "0")
     (setq ln (vla-AddLine *rp:spc* (rp:p3 (rp:loc f (- (+ hw fac)) 0.0) elev)
                                    (rp:p3 (rp:loc f (+ hw fac) 0.0) elev)))
     (vla-put-Layer ln "ROAD-TIEIN")
     (vla-put-LinetypeScale ln (/ fac (getvar "LTSCALE")))
     (foreach s (list (- hw) 0.0 hw)
       (vla-put-Layer (vla-AddCircle *rp:spc* (rp:p3 (rp:loc f s 0.0) elev) (* 0.3 fac)) "ROAD-TIEIN"))
     (setq ip (rp:loc f 0.0 (* -1.0 in (+ fac (* 3.0 th))))
           mt (vla-AddMText *rp:spc* (rp:p3 ip elev) (* 30.0 th)
                (strcat "TIE-IN WITH EXISTING ROAD\\PCH " (rp:chfmt ch)
                        "\\PE " (rtos (/ (car p) fac) 2 3) "   N " (rtos (/ (cadr p) fac) 2 3))))
     (vla-put-Height mt th)
     (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
     (vla-put-InsertionPoint mt (rp:p3 ip elev))
     (vla-put-Layer mt "ROAD-TIEIN")
     (list 0 0 0))
    ((= mode "1")
     (setq s (- hw) cnt 0)
     (while (< s (- hw 1e-6))
       (setq s2 (min hw (+ s blen)))
       (if (> s2 (- hw (* 0.25 blen))) (setq s2 hw))
       (rp:solidfill
         (rp:poly (list (rp:loc f s 0.0) (rp:loc f s2 0.0)
                        (rp:loc f s2 (* in bwid)) (rp:loc f s (* in bwid)))
                  "ROAD-BARRIER-OUTLINE" elev)
         nil (if (= 0 (rem cnt 2)) "ROAD-BARRIER-RED" "ROAD-BARRIER-WHITE") elev)
       (if (= 0 (rem cnt 2)) (setq nr (1+ nr)) (setq nw (1+ nw)))
       (setq cnt (1+ cnt) s s2))
     (rp:sign-closed (rp:loc f 0.0 (* -1.0 in (+ fac (* 0.5 sz)))) sz elev)
     (list nr nw 1))
    (T (list 0 0 0))))

;;----------------------------------------------------------------------------
;;  Chainage
;;----------------------------------------------------------------------------
(defun rp:chfmt (v / km m s p)
  (setq v  (/ (fix (+ (* v 1000.0) (if (< v 0) -0.5 0.5))) 1000.0)
        km (fix (/ v 1000.0))
        m  (abs (- v (* km 1000.0)))
        s  (if (equal m (fix (+ m 0.5)) 0.0005) (itoa (fix (+ m 0.5))) (rtos m 2 3)))
  (while (< (if (setq p (vl-string-search "." s)) p (strlen s)) 3)
    (setq s (strcat "0" s)))
  (strcat (if (and (< v 0) (= km 0)) "-" "") (itoa km) "+" s))

(defun rp:chmark (cl d v hw lofs th elev / a b ip ang flip ln tx)
  (setq a    (rp:offpt cl d (- hw))
        b    (rp:offpt cl d hw)
        ip   (rp:offpt cl d lofs)
        ang  (angle a b)
        flip (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))))
  (setq ln (vla-AddLine *rp:spc* (rp:p3 a elev) (rp:p3 b elev)))
  (vla-put-Layer ln "ROAD-CHAINAGE")
  (setq tx (vla-AddText *rp:spc* (strcat "CH " (rp:chfmt v)) (rp:p3 ip elev) th))
  (vla-put-Layer tx "ROAD-CHAINAGE")
  (vla-put-Alignment tx (if flip acAlignmentMiddleRight acAlignmentMiddleLeft))
  (vla-put-TextAlignmentPoint tx (rp:p3 ip elev))
  (vla-put-Rotation tx (if flip (+ ang pi) ang)))

(defun rp:chainage (cl len fac hw lofs elev closed / iv st th k d dl n)
  (setq iv   (* fac (rp:num "chint"))
        st   (rp:num "chst")
        th   (* fac (rp:num "txth"))
        lofs (+ lofs (* 0.5 th))
        dl   (list 0.0)
        k    (fix (/ (* st fac) iv))
        d    (- (* (1+ k) iv) (* st fac)))
  (if (< d (* 0.001 iv)) (setq d (+ d iv)))
  (while (< d (- len (* 2.0 th)))
    (setq dl (cons d dl) d (+ d iv)))
  (if (not closed) (setq dl (cons len dl)))
  (setq n 0)
  (foreach x (reverse dl)
    (rp:chmark cl x (+ st (/ x fac)) hw lofs th elev)
    (setq n (1+ n)))
  n)

;;----------------------------------------------------------------------------
;;  Radius on plan : radius line + arrow + R value, centre mark, TC / CT ticks
;;  with chainage and a curve data label for every bend
;;----------------------------------------------------------------------------
(defun rp:towards (a b dist / l)
  (setq l (distance a b))
  (if (< l 1e-12)
    a
    (list (+ (car a)  (* dist (/ (- (car b) (car a)) l)))
          (+ (cadr a) (* dist (/ (- (cadr b) (cadr a)) l))))))

(defun rp:line (a b lay elev / ln)
  (setq ln (vla-AddLine *rp:spc* (rp:p3 a elev) (rp:p3 b elev)))
  (vla-put-Layer ln lay)
  ln)

;; Text beside the road at distance d, offset off (+ left / - right), reading outward
(defun rp:sidetext (cl d str off th lay elev / a ip ang flip tx)
  (setq a    (rp:offpt cl d 0.0)
        ip   (rp:offpt cl d off)
        ang  (angle a ip)
        flip (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))))
  (setq tx (vla-AddText *rp:spc* str (rp:p3 ip elev) th))
  (vla-put-Layer tx lay)
  (vla-put-Alignment tx (if flip acAlignmentMiddleRight acAlignmentMiddleLeft))
  (vla-put-TextAlignmentPoint tx (rp:p3 ip elev))
  (vla-put-Rotation tx (if flip (+ ang pi) ang)))

;; bl / br : barricades on left / right,  chon : chainage labels on (left side)
(defun rp:curve-labels (cl curves hw fac th st elev bl br chon bgap bwid atcl
                        / n c dir rr ri dm ctr edge sp ang rot mid ah tx mt lo ix)
  (setq n 0)
  (foreach c curves
    (setq n (1+ n))                                        ; same numbers as report C1, C2...
    (if (> (nth 3 c) 0.0175)                               ; ignore bends under 1 deg
      (progn
        (setq dir  (nth 4 c)                               ; +1 left turn / -1 right turn
              rr   (nth 2 c)                               ; radius at centre line
              ri   (- rr hw)                               ; radius at inner edge
              dm   (* 0.5 (+ (car c) (cadr c)))            ; middle of the curve
              ctr  (rp:offpt cl dm (* dir rr))             ; curve centre point
              edge (rp:offpt cl dm (* dir hw)))            ; inner edge, mid curve
        (if atcl (setq edge (rp:offpt cl dm 0.0)))         ; radius shown to the centre line
        (if (> ri 0.0)
          (progn
            ;; radius line : full from centre, or a short leader for big radii
            (setq sp (if (<= ri (+ (* 50.0 fac) (rp:cin dir))) ctr (rp:towards edge ctr (+ (* 12.0 th) (rp:cin dir))))
                  ah (rp:towards edge sp (* 0.7 th)))
            (rp:mkwpl (list (list sp 0.0 0.0) (list ah (* 0.35 th) 0.0) (list edge 0.0 0.0))
                      "ROAD-CURVE" elev)
            ;; centre mark
            (if (equal sp ctr 1e-9)
              (progn
                (rp:line (polar ctr 0.0 (* 0.6 th)) (polar ctr pi (* 0.6 th)) "ROAD-CURVE" elev)
                (rp:line (polar ctr (* 0.5 pi) (* 0.6 th)) (polar ctr (* 1.5 pi) (* 0.6 th))
                         "ROAD-CURVE" elev)))
            ;; R value along the radius line (always readable)
            (setq ang (angle sp edge)
                  rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang)
                  mid (polar (rp:towards sp edge (* 0.5 (distance sp edge))) (+ rot (* 0.5 pi)) (* 0.7 th))
                  tx  (rp:text (strcat "R=" (rtos (/ (if atcl rr ri) fac) 2 2) (if atcl " CL" ""))
                               mid th "ROAD-CURVE" elev))
            (vla-put-Rotation tx rot)
            ;; curve data label, beyond the start of the radius line
            (setq ix (polar sp (angle edge sp) (* 3.5 th))
                  mt (vla-AddMText *rp:spc* (rp:p3 ix elev) 0.0
                       (strcat "C" (itoa n)
                               "\\PR inner = " (rtos (/ ri fac) 2 3) " m"
                               "\\PR CL = "    (rtos (/ rr fac) 2 3) " m"
                               "\\PR outer = " (rtos (/ (+ rr hw) fac) 2 3) " m"
                               "\\PL (CL) = "  (rtos (/ (- (cadr c) (car c)) fac) 2 3) " m"
                               "\\PA = " (rtos (/ (* 2.0 hw (- (cadr c) (car c))) fac fac) 2 2) " m\\U+00B2"
                               "\\P\\U+0394 = " (vl-string-subst "\\U+00B0" "%%d" (rp:dms (nth 3 c) T)))))
            (vla-put-Height mt (* 0.8 th))
            (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
            (vla-put-InsertionPoint mt (rp:p3 ix elev))
            (vla-put-Layer mt "ROAD-CURVE")))
        ;; TC / CT ticks across the road + labels on the inner side
        (setq lo (* dir (+ hw
                           (if (if (> dir 0) bl br) (+ bgap bwid) 0.0)
                           (rp:cin dir)
                           (* 0.3 fac) (* 0.5 th)
                           (if (and chon (> dir 0)) (* 11.0 th) 0.0))))
        (foreach tp (list (list (car c) "TC") (list (cadr c) "CT"))
          (rp:line (rp:offpt cl (car tp) (- hw)) (rp:offpt cl (car tp) hw) "ROAD-CURVE" elev)
          (rp:sidetext cl (car tp)
                       (strcat (cadr tp) (itoa n) "  " (rp:chfmt (+ st (/ (car tp) fac))))
                       lo (* 0.8 th) "ROAD-CURVE" elev)))))
  n)

;;----------------------------------------------------------------------------
;;  Straight sections : list of (dist-start dist-end direction-angle P1 P2)
;;----------------------------------------------------------------------------
(defun rp:straights (o / n i p1 p2 lst)
  (setq n (fix (+ 0.5 (vlax-curve-getEndParam o))) i 0)
  (repeat n
    (if (< (abs (vla-GetBulge o i)) 1e-9)
      (progn
        (setq p1 (vlax-curve-getPointAtParam o i)
              p2 (vlax-curve-getPointAtParam o (1+ i)))
        (if (> (distance p1 p2) 1e-6)
          (setq lst (cons (list (vlax-curve-getDistAtParam o i)
                                (vlax-curve-getDistAtParam o (1+ i))
                                (angle p1 p2) p1 p2)
                          lst)))))
    (setq i (1+ i)))
  (reverse lst))

;; Whole-circle bearing (from North, clockwise) of a drawing angle
(defun rp:brg (ang) (rem (+ (- (* 0.5 pi) ang) (* 4.0 pi)) (* 2.0 pi)))

;; Plan labels for straights, on the right side beyond barricades and signs
;; ob = clear distance from the centre line to start drawing
(defun rp:straight-labels (cl strs hw fac th st elev ob / n s d1 d2 od ot ang rot ip mt)
  (setq n  0
        od (- (+ ob (* 0.8 th)))          ; extent bar
        ot (- (+ ob (* 4.2 th))))         ; label centre
  (foreach s strs
    (setq n  (1+ n)
          d1 (car s)
          d2 (cadr s))
    ;; extent bar with end ticks
    (rp:line (rp:offpt cl d1 od) (rp:offpt cl d2 od) "ROAD-SECTION" elev)
    (rp:line (rp:offpt cl d1 (+ od (* 0.6 th))) (rp:offpt cl d1 (- od (* 0.6 th))) "ROAD-SECTION" elev)
    (rp:line (rp:offpt cl d2 (+ od (* 0.6 th))) (rp:offpt cl d2 (- od (* 0.6 th))) "ROAD-SECTION" elev)
    ;; label, parallel to the road and always readable
    (setq ang (nth 2 s)
          rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang)
          ip  (rp:offpt cl (* 0.5 (+ d1 d2)) ot)
          mt  (vla-AddMText *rp:spc* (rp:p3 ip elev) 0.0
                (strcat "S" (itoa n) "  STRAIGHT"
                        "\\PL = " (rtos (/ (- d2 d1) fac) 2 3) " m    A = "
                        (rtos (/ (* 2.0 hw (- d2 d1)) fac fac) 2 2) " m\\U+00B2"
                        "\\PCH " (rp:chfmt (+ st (/ d1 fac))) " - " (rp:chfmt (+ st (/ d2 fac)))
                        "\\PBRG " (vl-string-subst "\\U+00B0" "%%d" (rp:dms (rp:brg ang) T)))))
    (vla-put-Height mt (* 0.8 th))
    (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
    (vla-put-InsertionPoint mt (rp:p3 ip elev))
    (vla-put-Rotation mt rot)
    (vla-put-Layer mt "ROAD-SECTION"))
  n)

;;----------------------------------------------------------------------------
;;  Road data stored on the centre line (XDATA) - used by ROADREPORT
;;----------------------------------------------------------------------------
(defun rp:xput (e alst)
  (regapp "ROADPRO")
  (entmod (append (entget e)
                  (list (list -3 (cons "ROADPRO"
                                       (mapcar '(lambda (p) (cons 1000 (strcat (car p) "=" (cdr p))))
                                               alst)))))))

(defun rp:xget (e / x p)
  (setq x (cdr (assoc "ROADPRO" (cdr (assoc -3 (entget e '("ROADPRO")))))))
  (mapcar '(lambda (g / s)
             (setq s (cdr g) p (vl-string-search "=" s))
             (if p (cons (substr s 1 p) (substr s (+ p 2))) (cons s "")))
          x))

(defun rp:xv (k data / v) (if (setq v (cdr (assoc k data))) v ""))

(defun rp:pair (r) (if r (strcat (itoa (car r)) "," (itoa (cadr r))) "0,0"))

(defun rp:pairget (s / p)
  (if (and s (setq p (vl-string-search "," s)))
    (list (atoi (substr s 1 p)) (atoi (substr s (+ p 2))))
    (list 0 0)))

;;----------------------------------------------------------------------------
;;  Report
;;----------------------------------------------------------------------------
(defun rp:today () (menucmd "M=$(edtime,$(getvar,date),DD-MON-YYYY)"))

(defun rp:pad (s n) (while (< (strlen s) n) (setq s (strcat s " "))) s)

(defun rp:fm (v) (strcat (rtos v 2 3) " m"))

(defun rp:z2 (n) (if (< n 10) (strcat "0" (itoa n)) (itoa n)))

(defun rp:dms (a tbl / ts d m s)
  (setq ts (fix (+ (* (/ a pi) 648000.0) 0.5))
        d  (/ ts 3600)
        m  (/ (rem ts 3600) 60)
        s  (rem ts 60))
  (if tbl
    (strcat (itoa d) "%%d" (rp:z2 m) "'" (rp:z2 s) "\"")
    (strcat (itoa d) "d " (rp:z2 m) "m " (rp:z2 s) "s")))

(defun rp:brow (lbl pr)
  (if (> (+ (car pr) (cadr pr)) 0)
    (list lbl (strcat (itoa (car pr)) " red + " (itoa (cadr pr)) " white = "
                      (itoa (+ (car pr) (cadr pr))) " units"))))

(defun rp:endtxt (mode p fac)
  (strcat (cond ((= mode "0") "Tie-in") ((= mode "1") "Road closed")
                ((= mode "2") "Open end") ((= mode "3") "Junction") (T "Closed loop"))
          "  E " (rtos (/ (car p) fac) 2 3) "  N " (rtos (/ (cadr p) fac) 2 3)))

(defun rp:join (lst sep)
  (if lst (apply 'strcat (cons (car lst) (mapcar '(lambda (x) (strcat sep x)) (cdr lst)))) ""))

(defun rp:csv (f lst)
  (write-line
    (rp:join (mapcar '(lambda (s) (strcat "\"" (vl-string-translate "\"" "'" s) "\"")) lst) ",")
    f))

(defun rp:write-csv (path title rows crows srows secs signs wsto tsto jsto / f)
  (if (setq f (open path "w"))
    (progn
      (rp:csv f (list title))
      (foreach r rows
        (if (= (car r) "#")
          (progn (rp:csv f '("")) (rp:csv f (list (cadr r))))
          (rp:csv f r)))
      (rp:csv f '(""))
      (rp:csv f '("CURVE DATA"))
      (rp:csv f '("No" "Turn" "TC Chainage" "CT Chainage" "Radius CL (m)" "Arc Length CL (m)"
                  "Deflection" "TC Easting" "TC Northing" "CT Easting" "CT Northing"))
      (if crows (foreach r crows (rp:csv f r)) (rp:csv f '("-" "No curves")))
      (rp:csv f '(""))
      (rp:csv f '("ROAD SECTIONS"))
      (rp:csv f '("Section" "Type" "From Chainage" "To Chainage" "Length CL (m)"
                  "Left Edge (m)" "Right Edge (m)" "Area (m2)" "Bearing / Radius"))
      (foreach r secs (rp:csv f r))
      (rp:csv f '(""))
      (rp:csv f '("SIGN SCHEDULE"))
      (rp:csv f '("Sign ID" "Sign" "Chainage" "Side" "Facing traffic" "Post Easting" "Post Northing" "Plate size (mm)"))
      (foreach r signs (rp:csv f r))
      (if wsto
        (progn
          (rp:csv f '(""))
          (rp:csv f '("LANE WIDENING SETTING-OUT (new road edge)"))
          (rp:csv f '("Widening" "Point" "Chainage" "Offset from CL (m, + left)" "Easting" "Northing"))
          (foreach r wsto (rp:csv f r))))
      (if tsto
        (progn
          (rp:csv f '(""))
          (rp:csv f '("ROAD TAPER SETTING-OUT (new road edge)"))
          (rp:csv f '("Taper" "Point" "Chainage" "Offset from CL (m, + left)" "Easting" "Northing"))
          (foreach r tsto (rp:csv f r))))
      (if jsto
        (progn
          (rp:csv f '(""))
          (rp:csv f '("JUNCTION SETTING-OUT (kerb returns)"))
          (rp:csv f '("Junction" "Point" "Chainage" "Easting" "Northing"))
          (foreach r jsto (rp:csv f r))))
      (rp:csv f '(""))
      (rp:csv f '("SETTING-OUT DATA"))
      (rp:csv f '("Point" "Chainage" "CL Easting" "CL Northing" "Left Edge Easting"
                  "Left Edge Northing" "Right Edge Easting" "Right Edge Northing"))
      (foreach r srows (rp:csv f r))
      (close f)
      path)
    (progn (princ (strcat "\nCould not write " path " - is it open in Excel?")) nil)))

(defun rp:mktable (pt title hdr rows cw th / nc nr tb r c)
  (setq nc (length cw)
        nr (+ 2 (length rows))
        tb (vla-AddTable *rp:spc* (vlax-3d-point pt) nr nc (* 1.8 th) (car cw)))
  (vla-put-RegenerateTableSuppressed tb :vlax-true)
  (vla-put-Layer tb "ROAD-REPORT")
  (vl-catch-all-apply 'vla-put-HorzCellMargin (list tb (* 0.4 th)))
  (vl-catch-all-apply 'vla-put-VertCellMargin (list tb (* 0.3 th)))
  (vla-SetTextHeight tb acTitleRow (* 1.3 th))
  (vla-SetTextHeight tb acHeaderRow th)
  (vla-SetTextHeight tb acDataRow th)
  (setq c 0)
  (foreach wd cw (vla-SetColumnWidth tb c wd) (setq c (1+ c)))
  (vla-SetText tb 0 0 title)
  (setq c 0)
  (foreach h hdr (vla-SetText tb 1 c h) (setq c (1+ c)))
  (setq r 2)
  (foreach row rows
    (if (= (car row) "#")
      (progn
        (vla-MergeCells tb r r 0 (1- nc))
        (vla-SetText tb r 0 (cadr row))
        (vla-SetCellAlignment tb r 0 acMiddleLeft))
      (progn
        (setq c 0)
        (foreach s row
          (if (< c nc)
            (progn
              (vla-SetText tb r c s)
              (vla-SetCellAlignment tb r c (if (= c 0) acMiddleLeft acMiddleCenter))))
          (setq c (1+ c)))))
    (setq r (1+ r)))
  (vla-put-RegenerateTableSuppressed tb :vlax-false)
  tb)

(defun rp:tables (pt name rows ctab srows sect schd sched wsto tsto jsto th / x t1)
  (setq t1 (rp:mktable pt (strcat "ROAD REPORT - " name) '("DESCRIPTION" "VALUE")
                       rows (list (* 28.0 th) (* 28.0 th)) th))
  (if sched
    (rp:legend (list (car pt) (- (cadr pt) (vla-get-Height t1) (* 5.0 th))) sched th))
  (setq x (+ (car pt) (* 59.0 th)))
  (rp:mktable (list x (cadr pt) 0.0) "CURVE DATA"
              '("No" "TURN" "TC CH" "CT CH" "RADIUS (m)" "ARC (m)" "DEFLECTION")
              (if ctab ctab (list (list "-" "No curves" "" "" "" "" "")))
              (mapcar '(lambda (k) (* k th)) '(4.0 6.0 10.0 10.0 9.0 8.0 11.0)) th)
  (setq x (+ x (* 61.0 th)))
  (rp:mktable (list x (cadr pt) 0.0) "SETTING-OUT DATA"
              '("POINT" "CHAINAGE" "CL E" "CL N" "LEFT E" "LEFT N" "RIGHT E" "RIGHT N")
              srows (mapcar '(lambda (k) (* k th)) '(9.0 10.0 12.0 12.0 12.0 12.0 12.0 12.0)) th)
  (setq x (+ x (* 93.0 th)))
  (rp:mktable (list x (cadr pt) 0.0) "ROAD SECTIONS"
              '("SEC" "TYPE" "FROM CH" "TO CH" "LENGTH (m)" "LEFT (m)" "RIGHT (m)" "AREA (m2)" "BEARING / RADIUS")
              sect (mapcar '(lambda (k) (* k th)) '(5.0 8.0 10.0 10.0 9.0 9.0 9.0 10.0 15.0)) th)
  (setq x (+ x (* 87.0 th)))
  (rp:mktable (list x (cadr pt) 0.0) "SIGN SCHEDULE"
              '("ID" "SIGN" "CHAINAGE" "SIDE" "FACING TRAFFIC" "POST E" "POST N" "PLATE (mm)")
              schd (mapcar '(lambda (k) (* k th)) '(6.0 18.0 10.0 9.0 13.0 12.0 12.0 12.0)) th)
  (setq x (+ x (* 12.0 th)))   ; plate column added to the sign schedule
  (if wsto
    (progn
      (setq x (+ x (* 82.0 th)))
      (rp:mktable (list x (cadr pt) 0.0) "LANE WIDENING SETTING-OUT"
                  '("WIDENING" "POINT" "CHAINAGE" "OFFSET (m)" "EASTING" "NORTHING")
                  wsto (mapcar '(lambda (k) (* k th)) '(9.0 7.0 10.0 10.0 12.0 12.0)) th)))
  (if tsto
    (progn
      (setq x (+ x (if wsto (* 62.0 th) (* 82.0 th))))
      (rp:mktable (list x (cadr pt) 0.0) "ROAD TAPER SETTING-OUT"
                  '("TAPER" "POINT" "CHAINAGE" "OFFSET (m)" "EASTING" "NORTHING")
                  tsto (mapcar '(lambda (k) (* k th)) '(9.0 7.0 10.0 10.0 12.0 12.0)) th)))
  (if jsto
    (progn
      (setq x (+ x (if (or wsto tsto) (* 62.0 th) (* 82.0 th))))
      (rp:mktable (list x (cadr pt) 0.0) "JUNCTION SETTING-OUT"
                  '("JUNCTION" "POINT" "CHAINAGE" "EASTING" "NORTHING")
                  jsto (mapcar '(lambda (k) (* k th)) '(9.0 9.0 14.0 12.0 12.0)) th))))

;; Main report : full = T  -> command line + CSV + tables in drawing
;;               full = nil -> command line only
(defun rp:report-make (e full / data fac w hw obj len closed st iv curves tsum rin rc
                         bl br bc be nr nw ns rows ctab ccsv srows pts mp i k d p pl pr
                         name path pt th lbl strs sl cl secs sect secc a q
                         sched sgrows cnt schd wid wrows wsto wtot tr ttot jr mq mrows)
  (setq data (rp:xget e)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq w        (* fac (atof (rp:xv "W" data)))
        hw       (* 0.5 w)
        obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        closed   (vlax-curve-isClosed obj)
        st       (atof (rp:xv "CHST" data))
        iv       (* fac (atof (rp:xv "CHINT" data)))
        curves   (rp:curves obj)
        name     (rp:xv "NAME" data)
        tsum     0.0)
  (foreach c curves (setq tsum (+ tsum (* (nth 4 c) (nth 3 c)))))
  (setq strs (rp:straights obj) sl 0.0 cl 0.0)
  (foreach s strs (setq sl (+ sl (- (cadr s) (car s)))))
  (foreach c curves (setq cl (+ cl (- (cadr c) (car c)))))
  (setq rin (atof (rp:xv "RIN" data))
        rc  (cond ((<= rin 0.0) 0.0)
                  ((= (rp:xv "RREF" data) "0") (+ rin (/ hw fac)))
                  (T rin))
        bl  (rp:pairget (rp:xv "BL" data))
        br  (rp:pairget (rp:xv "BR" data))
        bc  (rp:pairget (rp:xv "BC" data))
        be  (rp:pairget (rp:xv "BE" data))
        nr  (+ (car bl) (car br) (car bc) (car be))
        nw  (+ (cadr bl) (cadr br) (cadr bc) (cadr be))
        ns  (+ (atoi (rp:xv "NSPD" data)) (atoi (rp:xv "NWRN" data))
               (atoi (rp:xv "NCHV" data)) (atoi (rp:xv "NCLS" data))))
  ;; ---- signs : from the sign schedule (older roads : stored counts) ----
  (setq sched (vlax-ldata-get obj "ROADPRO_SIGNS"))
  (if sched
    (progn
      (foreach r sched
        (if (setq a (assoc (nth 1 r) cnt))
          (setq cnt (subst (cons (car a) (1+ (cdr a))) a cnt))
          (setq cnt (cons (cons (nth 1 r) 1) cnt))))
      (setq sgrows (mapcar '(lambda (x) (list (car x) (itoa (cdr x)))) (reverse cnt))))
    (setq sgrows (list (list (strcat "Speed limit signs (" (rp:xv "SPEED" data) " km/h)") (rp:xv "NSPD" data))
                       (list "Curve warning signs" (rp:xv "NWRN" data))
                       (list "ROAD CLOSED signs" (rp:xv "NCLS" data)))))
  ;; ---- lane widening ----
  (setq wid (vlax-ldata-get obj "ROADPRO_WIDEN") wtot 0.0)
  (if wid
    (progn
      (setq wrows (list '("#" "LANE WIDENING")))
      (foreach r wid
        (setq wtot  (+ wtot (atof (nth 9 r)))
              wrows (append wrows
                            (list (list (strcat (car r) " - " (cadr r) " side")
                                        (strcat "+" (caddr r) " m,  CH " (nth 3 r) " - " (nth 4 r)))
                                  (list (strcat "   " (car r) " taper in / out")
                                        (strcat (nth 5 r) " / " (nth 6 r) " m,  " (nth 7 r)))
                                  (list (strcat "   " (car r) " match points") (nth 8 r))
                                  (list (strcat "   " (car r) " area") (strcat (nth 9 r) " m2")))))
        (foreach q (nth 10 r) (setq wsto (cons q wsto))))
      (setq wsto  (reverse wsto)
            wrows (append wrows
                          (list (list "Widening area total" (strcat (rtos wtot 2 2) " m2"))
                                (list "Total paved area (road + widening)"
                                      (strcat (rtos (+ (/ (* w len) fac fac) wtot) 2 2) " m2")))))))
  ;; ---- junctions ----
  (setq jr (rp:junc-report obj))
  ;; ---- road markings (paint quantities) ----
  (setq mq (vlax-ldata-get obj "ROADPRO_MKQTY"))
  (if mq
    (setq mrows (list '("#" "ROAD MARKINGS")
                      (list "Yellow edge lines L4 (both sides)" (strcat (rtos (/ (car mq) fac) 2 1) " m"))
                      (list (strcat "White centre line(s) 120 mm - "
                                    (cond ((= (rp:xv "CMARK" data) "1") "double continuous")
                                          ((= (rp:xv "CMARK" data) "2") "L2A continuous")
                                          (T "L1 / L2 / L2A by speed")))
                            (strcat (rtos (/ (cadr mq) fac) 2 1) " m"))
                      (list "SLOW words / lane arrows" (strcat (itoa (fix (caddr mq))) " / " (rp:xv "NARR" data)))
                      (list "Paint area (lines)"
                            (strcat (rtos (+ (* 0.12 (/ (car mq) fac)) (* 0.12 (/ (cadr mq) fac))) 2 2) " m2")))))
  ;; ---- road tapers ----
  (setq tr   (rp:taper-report obj fac hw st iv len)
        ttot (if tr (list (list "Total paved area (road + widening + tapers)"
                                (strcat (rtos (+ (/ (* w len) fac fac) wtot (caddr tr)) 2 2) " m2")))))
  ;; ---- summary rows ----
  (setq rows
    (vl-remove nil
     (append
      (list
        '("#" "GENERAL")
        (list "Road name / ID" name)
        (list "Report date" (rp:today))
        (list "Road created" (rp:xv "DATE" data))
        (list "Drawing" (getvar "DWGNAME"))
        (list "Drawing units" (if (= fac 1.0) "Meters" "Millimeters"))
        '("#" "GEOMETRY")
        (list "Start chainage" (rp:chfmt st))
        (list "End chainage" (rp:chfmt (+ st (/ len fac))))
        (list "Centre line length" (rp:fm (/ len fac)))
        (list "Road width" (rp:fm (/ w fac)))
        (list "Left edge length" (rp:fm (/ (- len (* hw tsum)) fac)))
        (list "Right edge length" (rp:fm (/ (+ len (* hw tsum)) fac)))
        (list "Road surface area" (strcat (rtos (/ (* w len) fac fac) 2 2) " m2"))
        (list "Straight sections" (strcat (itoa (length strs)) "  (total " (rp:fm (/ sl fac)) ")"))
        (list "Curve sections" (strcat (itoa (length curves)) "  (total " (rp:fm (/ cl fac)) ")"))
        (list "Design turning radius"
              (if (> rc 0.0)
                (strcat "inner " (rtos (- rc (/ hw fac)) 2 2) " / CL " (rtos rc 2 2)
                        " / outer " (rtos (+ rc (/ hw fac)) 2 2) " m")
                (if (= (rp:xv "RMODE" data) "0") "Match existing (CL as drawn)" "none")))
        (list "Minimum CL radius"
              (if curves (rp:fm (/ (apply 'min (mapcar 'caddr curves)) fac)) "-"))
        '("#" "ROAD EDGE, SHOULDER AND CENTRE")
        (list "Edge treatment"
              (cond ((= (rp:xv "ETYPE" data) "1") "Traffic cones")
                    ((= (rp:xv "ETYPE" data) "2") "Kerb stone")
                    (T "Barricades (red / white)")))
        (list "Centre"
              (cond ((= (rp:xv "CTYPE" data) "1") "Barricades (red / white)")
                    ((= (rp:xv "CTYPE" data) "2") "Traffic cones")
                    ((= (rp:xv "CTYPE" data) "0")
                     (cond ((member (rp:xv "MED" data) '("1" "2")) "Median (see corridor)")
                           ((= (rp:xv "CMARK" data) "1") "Double continuous white line")
                           ((= (rp:xv "CMARK" data) "2") "Single continuous line L2A")
                           (T "Centre line L1 / L2 / L2A by speed")))
                    (T (if (/= (rp:xv "BC" data) "0,0") "Barricades (red / white)" "Lane line"))))
        (list "Paved shoulder" (strcat (rp:xv "BGAP" data) " m each side,  area "
                                       (rtos (* 2.0 (atof (rp:xv "BGAP" data)) (/ len fac)) 2 2) " m2"))
        (if (= (rp:xv "ETYPE" data) "1")
          (list "Traffic cones (left / right)" (strcat (rp:xv "EQL" data) " / " (rp:xv "EQR" data) " nos")))
        (if (= (rp:xv "ETYPE" data) "2")
          (list "Kerb stone (left / right)" (strcat (rp:xv "EQL" data) " / " (rp:xv "EQR" data) " m")))
        (if (= (rp:xv "CTYPE" data) "2")
          (list "Centre traffic cones" (strcat (rp:xv "EQC" data) " nos")))
        (list "Unit size (L x W)" (strcat (rp:xv "BLEN" data) " x " (rp:xv "BWID" data) " m"))
        (rp:brow "Left side" bl)
        (rp:brow "Right side" br)
        (rp:brow "Centre median" bc)
        (rp:brow "Road-end closures" be)
        (list "TOTAL barricades" (strcat (itoa nr) " red + " (itoa nw) " white = "
                                         (itoa (+ nr nw)) " units"))
        '("#" "SIGNS AND MARKINGS"))
      sgrows
      (list
        (list "TOTAL signs" (if sched (itoa (length sched)) (itoa ns)))
        (if (/= (rp:xv "NDELI" data) "") (list "Delineator posts on curves" (rp:xv "NDELI" data)))
        (list "Sign set" (if (= (rp:xv "SSET" data) "1") "Temporary (road works)" "Permanent"))
        (list "Signs and markings reference" "Oman HDS 2017 Sec.19 / GCC Manual - check QTCM in Qatar")
        (list "Chevron boards on bends" (if (= (rp:xv "NCHV" data) "") "0" (rp:xv "NCHV" data)))
        (list "Lane direction arrows" (if (= (rp:xv "NARR" data) "") "0" (rp:xv "NARR" data)))
        '("#" "ROAD ENDS")
        (list "Start" (rp:endtxt (rp:xv "ENDS" data) (rp:offpt obj 0.0 0.0) fac))
        (list "Finish" (rp:endtxt (rp:xv "ENDF" data) (rp:offpt obj len 0.0) fac))
        '("#" "CHAINAGE")
        (list "Interval" (rp:fm (/ iv fac)))
        (list "Chainage marks" (rp:xv "NCHM" data)))
      wrows (car tr) ttot (car jr) mrows (rp:corr-rows obj data))))
  ;; ---- command line ----
  (princ "\n")
  (princ "\n==================== ROAD PRO - REPORT ====================")
  (foreach r rows
    (if (= (car r) "#")
      (princ (strcat "\n  [" (cadr r) "]"))
      (princ (strcat "\n    " (rp:pad (car r) 30) ": " (cadr r)))))
  (princ "\n===========================================================")
  (if full
    (progn
      ;; ---- curve data ----
      (setq i 1)
      (foreach c curves
        (setq k (list (itoa i) (if (> (nth 4 c) 0) "Left" "Right")
                      (rp:chfmt (+ st (/ (car c) fac))) (rp:chfmt (+ st (/ (cadr c) fac)))
                      (rtos (/ (nth 2 c) fac) 2 3) (rtos (/ (- (cadr c) (car c)) fac) 2 3)))
        (setq ctab (cons (append k (list (rp:dms (nth 3 c) T))) ctab)
              ccsv (cons (append k (list (rp:dms (nth 3 c) nil)
                                         (rtos (/ (car (nth 5 c)) fac) 2 3)
                                         (rtos (/ (cadr (nth 5 c)) fac) 2 3)
                                         (rtos (/ (car (nth 6 c)) fac) 2 3)
                                         (rtos (/ (cadr (nth 6 c)) fac) 2 3)))
                         ccsv)
              i    (1+ i)))
      (setq ctab (reverse ctab) ccsv (reverse ccsv))
      ;; ---- setting-out points ----
      (setq pts (list (cons 0.0 "START")))
      (if (not closed) (setq pts (cons (cons len "END") pts)))
      (if (> iv 0.0)
        (progn
          (setq k (fix (/ (* st fac) iv))
                d (- (* (1+ k) iv) (* st fac)))
          (if (< d (* 0.001 iv)) (setq d (+ d iv)))
          (while (< d (- len (* 0.001 iv)))
            (setq pts (cons (cons d "CH") pts) d (+ d iv)))))
      (setq i 1)
      (foreach c curves
        (setq pts (cons (cons (car c) (strcat "TC" (itoa i)))
                        (cons (cons (cadr c) (strcat "CT" (itoa i))) pts))
              i   (1+ i)))
      (setq pts (vl-sort pts '(lambda (a b) (< (car a) (car b)))))
      (foreach q pts
        (if (and mp (< (- (car q) (caar mp)) (* 0.001 fac)))
          (setq mp (cons (cons (caar mp)
                               (cond ((= (cdar mp) "CH") (cdr q))
                                     ((= (cdr q) "CH") (cdar mp))
                                     (T (strcat (cdar mp) "/" (cdr q)))))
                         (cdr mp)))
          (setq mp (cons q mp))))
      (foreach q (reverse mp)
        (setq p  (rp:offpt obj (car q) 0.0)
              pl (rp:offpt obj (car q) hw)
              pr (rp:offpt obj (car q) (- hw))
              srows (cons (list (cdr q) (rp:chfmt (+ st (/ (car q) fac)))
                                (rtos (/ (car p) fac) 2 3)  (rtos (/ (cadr p) fac) 2 3)
                                (rtos (/ (car pl) fac) 2 3) (rtos (/ (cadr pl) fac) 2 3)
                                (rtos (/ (car pr) fac) 2 3) (rtos (/ (cadr pr) fac) 2 3))
                          srows)))
      (setq srows (reverse srows))
      ;; ---- road sections : straights and curves in road order ----
      (setq i 0)
      (foreach s strs
        (setq i (1+ i) secs (cons (list (car s) (strcat "S" (itoa i)) s) secs)))
      (setq i 0)
      (foreach c curves
        (setq i (1+ i) secs (cons (list (car c) (strcat "C" (itoa i)) c) secs)))
      (setq secs (vl-sort secs '(lambda (a b) (< (car a) (car b)))))
      (foreach q secs
        (setq a (caddr q)
              d (- (cadr a) (car a))
              k (list (cadr q)
                      (if (= (substr (cadr q) 1 1) "S")
                        "Straight"
                        (if (> (nth 4 a) 0) "Curve Left" "Curve Right"))
                      (rp:chfmt (+ st (/ (car a) fac)))
                      (rp:chfmt (+ st (/ (cadr a) fac)))
                      (rtos (/ d fac) 2 3)
                      (rtos (/ (if (= (substr (cadr q) 1 1) "S") d (- d (* (nth 4 a) hw (nth 3 a)))) fac) 2 3)
                      (rtos (/ (if (= (substr (cadr q) 1 1) "S") d (+ d (* (nth 4 a) hw (nth 3 a)))) fac) 2 3)
                      (rtos (/ (* w d) fac fac) 2 2)))
        (if (= (substr (cadr q) 1 1) "S")
          (setq sect (cons (append k (list (strcat "BRG " (rp:dms (rp:brg (nth 2 a)) T)))) sect)
                secc (cons (append k (list (strcat "BRG " (rp:dms (rp:brg (nth 2 a)) nil)))) secc))
          (setq sect (cons (append k (list (strcat "R " (rtos (/ (nth 2 a) fac) 2 3) " m (CL)"))) sect)
                secc (cons (append k (list (strcat "R " (rtos (/ (nth 2 a) fac) 2 3) " m (CL)"))) secc))))
      (setq sect (reverse sect) secc (reverse secc))
      ;; ---- sign schedule ----
      (setq schd (if sched
                   (mapcar '(lambda (r) (list (nth 0 r) (nth 1 r) (nth 2 r) (nth 3 r)
                                              (nth 4 r) (nth 5 r) (nth 6 r)
                                              (if (nth 9 r) (nth 9 r) "-")))
                           sched)
                   (list (list "-" "No sign schedule" "" "" "" "" "" ""))))
      ;; ---- Excel (CSV) ----
      (setq path (rp:write-csv
                   (strcat (getvar "DWGPREFIX")
                           (vl-string-translate "\\/:*?\"<>| " "__________" name)
                           "_RoadPro_Report.csv")
                   (strcat "ROAD PRO REPORT - " name) rows ccsv srows secc schd wsto (cadr tr) (cadr jr)))
      (if path (princ (strcat "\n  Excel report saved : " path)))
      ;; ---- tables in drawing ----
      (setq th (* 0.8 fac (rp:num "txth")))
      (if (setq pt (getpoint "\nPick top-left corner for report tables <Enter = skip>: "))
        (rp:tables pt name rows ctab srows sect schd sched wsto (cadr tr) (cadr jr) th))
      (if path
        (progn
          (initget "Yes No")
          (if (/= (getkword "\nOpen the Excel report now? [Yes/No] <Yes>: ") "No")
            (startapp "explorer" (strcat "\"" path "\"")))))))
  (princ))

;;----------------------------------------------------------------------------
;;  Main builder
;;----------------------------------------------------------------------------
(defun rp:run (/ fac w hw rad0 rc ri blen bwid bgap step cl obj len elev closed lt
                 
                 e1 e2 surf resL resR resC resE nch curves strs sz th st ends endf r
                 offR offL sched nChv nArr nCls et ct eqL eqR eqC sho plan mo chk mark0 k)
  (rp:space)
  (setq *rp:hatches* nil
        fac  (if (= (rp:val "units") "1") 1000.0 1.0)
        plan (rp:lane-plan (rp:num "width"))
        w    (* fac (car plan))
        mo   (* fac (nth 5 plan))
        hw   (* 0.5 w)
        rad0 (* fac (rp:num "radius"))
        blen (* fac (rp:num "blen"))
        bwid (* fac (rp:num "bwid"))
        bgap (* fac (rp:num "bgap"))
        et   (rp:val "etype")
        ct   (rp:val "ctype")
        *rp:arrl* (if (<= (rp:num "speed") 60.0) (* 5.0 1.0) 7.5)
        rc   (cond ((= (rp:val "rmode") "0") 0.0)            ; match existing : keep the CL as drawn
                   ((<= rad0 0.0) 0.0)
                   ((= (rp:val "rref") "1") (+ rad0 hw))     ; radius given at inner edge
                   (T rad0))                                  ; radius given at centre line
        ri   (- rc hw))
  (cond
    ((and (> rc 0.0) (<= ri 0.0))
     (alert (strcat "Turning radius is too small for this road width.\n\n"
                    "Measured at the centre line it must be more than half\n"
                    "the road width (" (rtos (/ hw fac) 2 2) " m).")))
    ((car (setq chk (rp:corr-check (rp:num "width"))))
     (alert (strcat "Lanes, median, sidewalks ... settings are not valid:\n\n" (rp:join2 (car chk) "\n"))))
    (T
     (rp:world)
     (rp:linetypes)
     (rp:layers)
     (setq mark0 (entlast))
     (foreach m (cadr chk) (princ (strcat "\n  Corridor warning: " m)))
     (foreach m (nth 6 plan) (princ (strcat "\n  " m)))
     (if (and (setq cl (rp:get-centreline)) (rp:cl-ok cl rc fac hw))
       (progn
         ;; 1. turning radius at every bend : filleted in rp:cl-ok
         (setq obj      (vlax-ename->vla-object cl)
               elev     (vla-get-Elevation obj)
               closed   (vlax-curve-isClosed obj)
               len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
               *rp:len* len
               curves   (rp:curves obj))
         (vl-catch-all-apply 'vla-put-ConstantWidth (list obj 0.0))
         ;; 2. road edges
         (setq e1 (rp:offset obj hw)
               e2 (rp:offset obj (- hw)))
         (foreach o (append e1 e2) (rp:props o "ROAD-EDGE" "ByLayer" 1.0))
         ;; 3. centre line
         (setq lt (rp:cl-ltype))
         (rp:props obj "ROAD-CL" lt (/ fac (getvar "LTSCALE")))
         ;; 4. road surface
         (if (rp:on "hatch") (setq surf (rp:surface obj e1 e2 elev)))
         ;; 4b. paved shoulders between the carriageway edge and the edge treatment
         (setq sho nil)
         (if (> bgap 0.0)
           (foreach sg '(1.0 -1.0)
             (setq sho (cons (rp:band obj 0.0 len (* sg hw) (* sg (+ hw bgap)) "ROAD-SHOULDER" elev fac nil) sho))))
         ;; 5. edge treatment : barricades / cones / kerb stone, and the centre
         (if (and (> rc 0.0) (or (rp:on "bl") (rp:on "br")) (<= ri (+ bgap bwid)))
           (princ "\nWarning: the edge treatment on the inside of bends is tighter than the radius - increase the radius or reduce the width / shoulder."))
         (setq step (min blen (* 0.5 fac)) eqL "0" eqR "0" eqC "0")
         (foreach sg (vl-remove nil (list (if (rp:on "bl") 1.0) (if (rp:on "br") -1.0)))
           (cond
             ((= et "1")
              (setq r (itoa (rp:cones obj len (* sg (+ hw bgap (* 0.5 bwid))) blen bwid elev))))
             ((= et "2")
              (setq *rp:unitfill* "ROAD-KERB")
              (rp:barrier obj len (* sg (+ hw bgap)) (* sg (+ hw bgap bwid)) blen step elev)
              (setq *rp:unitfill* nil
                    r (rtos (/ len fac) 2 1)))
             (T
              (setq r (rp:barrier obj len (* sg (+ hw bgap)) (* sg (+ hw bgap bwid)) blen step elev))
              (if (> sg 0) (setq resL r) (setq resR r))
              (setq r (itoa (+ (car r) (cadr r))))))
           (if (> sg 0) (setq eqL r) (setq eqR r)))
         (cond
           ((= ct "1")
            (setq resC (rp:barrier obj len (+ mo (* -0.5 bwid)) (+ mo (* 0.5 bwid)) blen step elev)
                  eqC  (itoa (+ (car resC) (cadr resC)))))
           ((= ct "2")
            (setq eqC (itoa (rp:cones obj len mo blen bwid elev)))))
         ;; 6. chainage
         (setq th (* fac (rp:num "txth"))
               st (rp:num "chst"))
         (if (rp:on "ch")
           (setq nch (rp:chainage obj len fac hw
                                  (+ hw (if (rp:on "bl") (+ bgap bwid) 0.0) (rp:corr-extra 1.0 fac bgap bwid) (* 0.3 fac))
                                  elev closed)))
         ;; 6b. radius, TC / CT and curve data on plan
         (setq *rp:cinx* (list (rp:corr-extra 1.0 fac bgap bwid) (rp:corr-extra -1.0 fac bgap bwid)))
         (if (rp:on "rlab")
           (rp:curve-labels obj curves hw fac th st elev (rp:on "bl") (rp:on "br")
                            (rp:on "ch") bgap bwid (= (rp:val "rref") "0")))
         (setq *rp:cinx* nil)
         ;; 6c. straight sections on plan (right side, beyond barricades and signs)
         (setq sz   (* fac (rp:num "signsz"))
               offR (+ hw (if (rp:on "br") (+ bgap bwid) 0.0) (* 0.5 fac))
               offL (+ hw (if (rp:on "bl") (+ bgap bwid) 0.0) (* 0.5 fac))
               strs (rp:straights obj))
         (if (rp:on "slab")
           (rp:straight-labels obj strs hw fac th st elev (+ offR (* 0.6 fac) (* 1.5 sz) (rp:corr-extra -1.0 fac bgap bwid))))
         ;; 7. road ends
         (setq resE (list 0 0)
               nCls 0
               ends (if closed "-" (rp:val "endst"))
               endf (if closed "-" (rp:val "endfn")))
         (if (not closed)
           (foreach en (list (list 0.0 nil ends) (list len T endf))
             (setq r    (rp:road-end obj (car en) (cadr en) (caddr en) hw blen bwid th fac sz
                                     elev (+ st (/ (car en) fac)))
                   resE (list (+ (car resE) (car r)) (+ (cadr resE) (cadr r)))
                   nCls (+ nCls (caddr r)))))
         ;; 8. chevron boards on the outside of every bend of 10 deg or more
         (setq nChv 0
               offR (+ hw bgap (if (rp:on "br") bwid 0.0) (* 0.5 fac))
               offL (+ hw bgap (if (rp:on "bl") bwid 0.0) (* 0.5 fac)))
         ;; 8b. delineator posts : 0.30 m beyond the paved shoulder / edge treatment
         (setq *rp:ndeli* 0)
         (if (rp:on "deli")
           (setq *rp:ndeli* (rp:delineators obj len curves (- offL (* 0.2 fac)) (- offR (* 0.2 fac)) fac elev)))
         (if (rp:on "schev")
           (foreach c curves
             (if (>= (nth 3 c) (/ pi 18.0))
               (setq nChv (+ nChv (rp:chevrons obj c
                                               (if (> (nth 4 c) 0)
                                                 (- (+ offR (* 0.35 sz)))
                                                 (+ offL (* 0.35 sz)))
                                               sz fac elev))))))
         ;; 9. signs : post, plate, leader, symbol, ID tag (traffic keeps right)
         (setq sched (rp:signs obj len curves fac sz elev offR offL
                               (if (rp:on "ch") (* 10.0 th) 0.0) ends endf closed st))
         ;; 10. lane direction arrows
         (setq *rp:lanes* nil k 1)
         (if (> (nth 1 plan) 0)
           (progn
             (repeat (nth 2 plan)
               (setq *rp:lanes* (cons (list (- mo (* 0.5 fac (nth 4 plan)) (* fac (nth 3 plan) (- k 0.5))) nil) *rp:lanes*) k (1+ k)))
             (setq k 1)
             (repeat (nth 1 plan)
               (setq *rp:lanes* (cons (list (+ mo (* 0.5 fac (nth 4 plan)) (* fac (nth 3 plan) (- k 0.5))) T) *rp:lanes*) k (1+ k)))))
         (setq nArr (if (rp:on "sarr") (rp:lane-arrows obj strs hw fac (rp:on "twoway") elev) 0))
         (setq *rp:lanes* nil)
         ;; 11. draw order: surface bottom, fills above, all lines and text on top
         (if *rp:hatches* (rp:toback *rp:hatches*))
         (if surf (rp:toback (list surf)))
         ;; 12. store road data on the centre line, then report
         (rp:xput cl
           (list (cons "NAME"  (rp:val "rname"))   (cons "VER"   *rp:ver*)
                 (cons "DATE"  (rp:today))         (cons "FAC"   (rtos fac 2 0))
                 (cons "W"     (rtos (/ w fac) 2 4)) (cons "RIN" (rtos (/ rad0 fac) 2 4))
                 (cons "RREF"  (if (= (rp:val "rref") "1") "0" "1"))  (cons "CHST"  (rp:val "chst"))
                 (cons "CHINT" (rp:val "chint"))   (cons "BLEN"  (rp:val "blen"))
                 (cons "BWID"  (rp:val "bwid"))    (cons "BGAP"  (rp:val "bgap"))
                 (cons "BL"    (rp:pair resL))     (cons "BR"    (rp:pair resR))
                 (cons "BC"    (rp:pair resC))     (cons "BE"    (rp:pair resE))
                 (cons "SPEED" (rtos (rp:num "speed") 2 0))
                 (cons "NCHV"  (itoa nChv))        (cons "NARR"  (itoa nArr))
                 (cons "NCLS"  (itoa nCls))        (cons "ENDS"  ends)
                 (cons "ENDF"  endf)               (cons "NCHM"  (itoa (if nch nch 0)))
                 (cons "TWOWAY" (rp:val "twoway"))
                 (cons "RMODE" (rp:val "rmode"))   (cons "ETYPE" et)  (cons "CTYPE" ct)
                 (cons "EL" (if (rp:on "bl") "1" "0")) (cons "ER" (if (rp:on "br") "1" "0"))
                 (cons "EQL" eqL) (cons "EQR" eqR) (cons "EQC" eqC)
                 (cons "CMARK" (rp:val "cmark")) (cons "SSET" (rp:val "sset"))
                 (cons "NDELI" (itoa *rp:ndeli*))
                 (cons "CARR" (rp:val "ccarr")) (cons "LMODE" (rp:val "clmode"))
                 (cons "NL" (itoa (nth 1 plan))) (cons "NR" (itoa (nth 2 plan)))
                 (cons "LW" (rtos (nth 3 plan) 2 3)) (cons "MW" (rtos (nth 4 plan) 2 3))
                 (cons "MO" (rtos (nth 5 plan) 2 4)) (cons "MED" (rp:val "cmed"))))
         (vlax-ldata-put obj "ROADPRO_SIGNS" sched)
         (vlax-ldata-put obj "ROADPRO_SET" (rp:snapshot))
         (if (rp:corr-any) (rp:corr-run cl))
         (if (rp:on "mark") (rp:mark-run cl))
         (rp:report-make cl (rp:on "report"))
         ;; 13. typical cross section
         (if (rp:on "xsec") (rp:xsec-run cl "0"))
         (rp:track cl mark0))))))

;;----------------------------------------------------------------------------
;;  CROSS SECTIONS
;;  Drawn true size (1 unit = 1 m, or 1 mm for mm drawings), looking in the
;;  direction of increasing chainage : the road's LEFT side is on the LEFT.
;;----------------------------------------------------------------------------
(setq *rp:xdcl*
 (list
  "roadxsec : dialog {"
  "  label = \"ROAD PRO  -  Cross Section\";"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Section\";"
  "      : popup_list { key = \"xmode\";  label = \"Draw:\";                      edit_width = 26; }"
  "      : edit_box   { key = \"xch\";    label = \"Chainage (m):\";              edit_width = 8; }"
  "      : edit_box   { key = \"xint\";   label = \"Interval (m):\";              edit_width = 8; }"
  "      : edit_box   { key = \"xcf\";    label = \"Crossfall (%):\";             edit_width = 8; }"
  "      : popup_list { key = \"xcamb\";  label = \"Crossfall type:\";            edit_width = 26; }"
  "      : edit_box   { key = \"xverge\"; label = \"Verge beyond barricade (m):\"; edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Pavement layers (thickness 0 = not used)\";"
  "      : row { : edit_box { key = \"xl1n\"; label = \"1\"; edit_width = 26; }"
  "              : edit_box { key = \"xl1t\"; label = \"t (m)\"; edit_width = 6; } }"
  "      : row { : edit_box { key = \"xl2n\"; label = \"2\"; edit_width = 26; }"
  "              : edit_box { key = \"xl2t\"; label = \"t (m)\"; edit_width = 6; } }"
  "      : row { : edit_box { key = \"xl3n\"; label = \"3\"; edit_width = 26; }"
  "              : edit_box { key = \"xl3t\"; label = \"t (m)\"; edit_width = 6; } }"
  "    }"
  "  }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Barricade profile (red / white, black outline)\";"
  "      : popup_list { key = \"xbtype\"; label = \"Type:\";       edit_width = 26; }"
  "      : edit_box   { key = \"xbh\";    label = \"Height (m):\"; edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Sign post\";"
  "      : toggle   { key = \"xsign\";   label = \"Show sign post with height\"; }"
  "      : edit_box { key = \"xsclr\";   label = \"Clearance to sign (m):\"; edit_width = 8; }"
  "      : edit_box { key = \"xsplate\"; label = \"Sign size (m):\";         edit_width = 8; }"
  "    }"
  "  }"
  "  spacer;"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:xdlg-modes ()
  (mode_tile "xch"  (if (= (get_tile "xmode") "1") 0 1))
  (mode_tile "xint" (if (= (get_tile "xmode") "2") 0 1))
  (foreach k '("xsclr" "xsplate") (mode_tile k (if (= (get_tile "xsign") "1") 0 1))))

(defun rp:xdlg-accept (/ bad v)
  (foreach k '(("xch" "Chainage" 1) ("xint" "Interval" 0) ("xcf" "Crossfall" 1)
               ("xverge" "Verge" 1) ("xl1t" "Layer 1 thickness" 1) ("xl2t" "Layer 2 thickness" 1)
               ("xl3t" "Layer 3 thickness" 1) ("xbh" "Barricade height" 0)
               ("xsclr" "Sign clearance" 0) ("xsplate" "Sign size" 0))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (if (= (caddr k) 1) (< v 0.0) (<= v 0.0)))
          (setq bad k)))))
  (if bad
    (progn
      (set_tile "error" (strcat (cadr bad)
                                (if (= (caddr bad) 1)
                                  " must be zero or a positive number."
                                  " must be a number greater than zero.")))
      (mode_tile (car bad) 2))
    (progn
      (foreach k *rp:xkeys* (rp:set k (get_tile k)))
      (done_dialog 1))))

(defun rp:xdialog (/ fn f id res)
  (setq fn (vl-filename-mktemp "roadxsec.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:xdcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadxsec" id))
        (progn
          (rp:fill "xmode"  '("Typical cross section" "At one chainage" "At every chainage interval"))
          (rp:fill "xcamb"  '("Camber (falls both sides)" "One-way, falls to right" "One-way, falls to left"))
          (rp:fill "xbtype" '("Water-filled plastic barrier" "New Jersey concrete barrier"))
          (foreach k *rp:xkeys* (set_tile k (rp:val k)))
          (rp:xdlg-modes)
          (foreach k '("xmode" "xsign") (action_tile k "(rp:xdlg-modes)"))
          (action_tile "accept" "(rp:xdlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; ---- local section coordinates -> drawing ----
(defun rp:xp (x y) (list (+ (car *rp:xo*) x) (+ (cadr *rp:xo*) y)))

(defun rp:xpl (pts lay closed)
  (rp:mkpl (mapcar '(lambda (p) (list (rp:xp (car p) (cadr p)) 0.0)) pts) lay 0.0 closed))

(defun rp:xline (a b lay) (rp:line (rp:xp (car a) (cadr a)) (rp:xp (car b) (cadr b)) lay 0.0))

(defun rp:xtext (str p h) (rp:ltext str (rp:xp (car p) (cadr p)) h "ROAD-XSEC-TEXT"))

(defun rp:xmtext (str p h / mt)
  (setq mt (vla-AddMText *rp:spc* (rp:p3 (rp:xp (car p) (cadr p)) 0.0) 0.0 str))
  (vla-put-Height mt h)
  (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
  (vla-put-InsertionPoint mt (rp:p3 (rp:xp (car p) (cadr p)) 0.0))
  (vla-put-Layer mt "ROAD-XSEC-TEXT")
  mt)

;; finished surface level at x (0 at the centre line), level beyond the edges
(defun rp:ys (x / mw mo)
  (setq x  (max (- *rp:xhw*) (min *rp:xhw* x))
        mw (if *rp:xc* (car *rp:xc*) 0.0)
        mo (if *rp:xc* (cadr *rp:xc*) 0.0))
  (cond ((= *rp:ct* "1") (* -1.0 *rp:cf* x))
        ((= *rp:ct* "2") (* *rp:cf* x))
        ((> mw 0.0) (* -1.0 *rp:cf* (max 0.0 (- (abs (- x mo)) (* 0.5 mw)))))
        (T (* -1.0 *rp:cf* (abs x)))))

;; carriageway top line shifted by dy
(defun rp:xsurf (dy / mw mo)
  (setq mw (if *rp:xc* (car *rp:xc*) 0.0) mo (if *rp:xc* (cadr *rp:xc*) 0.0))
  (cond
   ((and (= *rp:ct* "0") (> mw 0.0))
    (list (list (- *rp:xhw*) (+ (rp:ys (- *rp:xhw*)) dy)) (list (- mo (* 0.5 mw)) dy) (list (+ mo (* 0.5 mw)) dy)
          (list *rp:xhw* (+ (rp:ys *rp:xhw*) dy))))
   ((= *rp:ct* "0")
    (list (list (- *rp:xhw*) (+ (rp:ys (- *rp:xhw*)) dy)) (list 0.0 dy) (list *rp:xhw* (+ (rp:ys *rp:xhw*) dy))))
   (T
    (list (list (- *rp:xhw*) (+ (rp:ys (- *rp:xhw*)) dy)) (list *rp:xhw* (+ (rp:ys *rp:xhw*) dy))))))

(defun rp:xlay (kn kt fac) (if (> (rp:num kt) 0.0) (list (rp:val kn) (* fac (rp:num kt)))))

(defun rp:xlayers (fac)
  (vl-remove nil (list (rp:xlay "xl1n" "xl1t" fac) (rp:xlay "xl2n" "xl2t" fac) (rp:xlay "xl3n" "xl3t" fac))))

(defun rp:xthk (fac / tt) (setq tt 0.0) (foreach l (rp:xlayers fac) (setq tt (+ tt (cadr l)))) tt)

(defun rp:dim (p1 p2 loc rot th fac / d)
  (setq d (vla-AddDimRotated *rp:spc*
            (rp:p3 (rp:xp (car p1) (cadr p1)) 0.0)
            (rp:p3 (rp:xp (car p2) (cadr p2)) 0.0)
            (rp:p3 (rp:xp (car loc) (cadr loc)) 0.0)
            rot))
  (vla-put-Layer d "ROAD-XSEC-DIM")
  (foreach pr (list (list 'vla-put-TextHeight th)
                    (list 'vla-put-ArrowheadSize (* 0.6 th))
                    (list 'vla-put-ExtensionLineExtension (* 0.4 th))
                    (list 'vla-put-ExtensionLineOffset (* 0.3 th))
                    (list 'vla-put-TextGap (* 0.25 th))
                    (list 'vla-put-PrimaryUnitsPrecision
                          (if (= fac 1.0) acDimPrecisionTwo acDimPrecisionZero)))
    (vl-catch-all-apply (car pr) (list d (cadr pr))))
  d)

;; barricade profile, base centre (cx,by), base width bw, height bh
(defun rp:xbar (cx by bw bh lay / prof)
  (setq prof (if (= (rp:val "xbtype") "1")
               '((-0.5 0.0) (0.5 0.0) (0.5 0.09) (0.38 0.4) (0.12 1.0) (-0.12 1.0) (-0.38 0.4) (-0.5 0.09))
               '((-0.5 0.0) (0.5 0.0) (0.5 0.12) (0.32 0.2) (0.25 0.92) (0.15 1.0)
                 (-0.15 1.0) (-0.25 0.92) (-0.32 0.2) (-0.5 0.12))))
  (rp:solidfill (rp:xpl (mapcar '(lambda (p) (list (+ cx (* bw (car p))) (+ by (* bh (cadr p))))) prof)
                        "ROAD-BARRIER-OUTLINE" T)
                nil lay 0.0))

;; Edge treatment profile in section : "0" barricade, "1" traffic cone, "2" kerb
(defun rp:xedge (cx by bw bh typ lay fac / k)
  (cond
    ((= typ "1")
     (setq k (* 0.75 fac))
     (rp:solidfill (rp:xpl (list (list (- cx (* 0.5 bw)) by) (list (+ cx (* 0.5 bw)) by)
                                 (list (+ cx (* 0.5 bw)) (+ by (* 0.04 fac))) (list (- cx (* 0.5 bw)) (+ by (* 0.04 fac))))
                           "ROAD-BARRIER-OUTLINE" T)
                   nil "ROAD-BARRIER-OUTLINE" 0.0)
     (rp:solidfill (rp:xpl (list (list (- cx (* 0.35 bw)) (+ by (* 0.04 fac))) (list (+ cx (* 0.35 bw)) (+ by (* 0.04 fac)))
                                 (list (+ cx (* 0.08 bw)) (+ by k)) (list (- cx (* 0.08 bw)) (+ by k)))
                           "ROAD-BARRIER-OUTLINE" T)
                   nil "ROAD-CONE" 0.0)
     (foreach bd '((0.40 0.50) (0.62 0.70))
       (rp:solidfill (rp:xpl (list (list (- cx (* bw (- 0.35 (* 0.27 (car bd))))) (+ by (* k (car bd))))
                                   (list (+ cx (* bw (- 0.35 (* 0.27 (car bd))))) (+ by (* k (car bd))))
                                   (list (+ cx (* bw (- 0.35 (* 0.27 (cadr bd))))) (+ by (* k (cadr bd))))
                                   (list (- cx (* bw (- 0.35 (* 0.27 (cadr bd))))) (+ by (* k (cadr bd)))))
                             "ROAD-BARRIER-OUTLINE" T)
                     nil "ROAD-BARRIER-WHITE" 0.0)))
    ((= typ "2")
     (rp:solidfill (rp:xpl (list (list (- cx (* 0.5 bw)) (- by (* 0.30 fac))) (list (+ cx (* 0.5 bw)) (- by (* 0.30 fac)))
                                 (list (+ cx (* 0.5 bw)) (+ by (* 0.15 fac))) (list (- cx (* 0.5 bw)) (+ by (* 0.15 fac))))
                           "ROAD-BARRIER-OUTLINE" T)
                   nil "ROAD-XSEC-CONC" 0.0))
    (T (rp:xbar cx by bw bh lay))))

;; crossfall arrow + % text, dir +1 falls to the right, -1 to the left
(defun rp:xfall (x dir th fac / y1 y2 p1 p2 pm)
  (setq p1 (list (- x (* dir 0.7 fac)) (+ (rp:ys (- x (* dir 0.7 fac))) (* 0.35 fac)))
        p2 (list (+ x (* dir 0.7 fac)) (+ (rp:ys (+ x (* dir 0.7 fac))) (* 0.35 fac)))
        pm (rp:towards p2 p1 (* 0.25 fac)))
  (rp:mkwpl (list (list (rp:xp (car p1) (cadr p1)) 0.0 0.0)
                  (list (rp:xp (car pm) (cadr pm)) (* 0.12 fac) 0.0)
                  (list (rp:xp (car p2) (cadr p2)) 0.0 0.0))
            "ROAD-XSEC-TEXT" 0.0)
  (rp:xmtext (strcat (rtos (rp:num "xcf") 2 1) "%") (list x (+ (rp:ys x) (* 0.35 fac) (* 1.2 th))) th))

;; sign post with footing and sign face; dims = T adds clearance dimension + note
(defun rp:xpost (px py sclr spl spd fac th dims / po)
  (rp:solidfill (rp:xpl (list (list (- px (* 0.2 fac)) py) (list (+ px (* 0.2 fac)) py)
                              (list (+ px (* 0.2 fac)) (- py (* 0.6 fac)))
                              (list (- px (* 0.2 fac)) (- py (* 0.6 fac))))
                        "ROAD-XSEC" T)
                nil "ROAD-XSEC-CONC" 0.0)
  (setq po (rp:xpl (list (list px (- py (* 0.5 fac))) (list px (+ py sclr))) "ROAD-SIGN" nil))
  (vla-put-ConstantWidth po (* 0.076 fac))
  (rp:sign-speed (rp:xp px (+ py sclr (* 0.5 spl))) spl spd 0.0)
  (if dims
    (progn
      (rp:dim (list px py) (list px (+ py sclr)) (list (+ px (* 0.5 spl) (* 0.6 fac)) py) (* 0.5 pi) th fac)
      (rp:xtext (strcat "TRAFFIC SIGN " (rtos (/ spl fac) 2 2) " m ON 76 mm POST")
                (list (+ px (* 0.5 spl) (* 1.4 fac)) (+ py sclr (* 0.5 spl))) th)
      (rp:xtext "WITH CONCRETE FOOTING 0.40 x 0.60 m"
                (list (+ px (* 0.5 spl) (* 1.4 fac)) (- (+ py sclr (* 0.5 spl)) (* 1.6 th))) th))))

;; One complete cross section with its origin (CL, finished level) at org
(defun rp:xsection (org hw bgap bwid bl br bc fac two spd title note
                    / th bh vg sclr spl lys tt yL yR xl xr xo1 xo2 ybot d0 d1 i pg ytx xt
                      gx1 gx2 x ln top xs ys2 yd1 yd2 yd3 cxL cxR btxt ny hh)
  (setq *rp:xo*  org
        *rp:cf*  (/ (rp:num "xcf") 100.0)
        *rp:ct*  (rp:val "xcamb")
        *rp:xhw* hw
        th   (* 0.2 fac (rp:num "txth"))
        bh   (* fac (rp:num "xbh"))
        vg   (* fac (rp:num "xverge"))
        sclr (* fac (rp:num "xsclr"))
        spl  (* fac (rp:num "xsplate"))
        lys  (rp:xlayers fac)
        tt   (rp:xthk fac)
        yL   (rp:ys (- hw))
        yR   (rp:ys hw)
        xl   (+ hw (if bl (+ bgap bwid) 0.0))
        xr   (+ hw (if br (+ bgap bwid) 0.0))
        xo1  (- (+ (max xl (+ hw (rp:xc-ext2 1.0))) vg))
        xo2  (+ (max xr (+ hw (rp:xc-ext2 -1.0))) vg)
        ybot (- (min yL yR) tt)
        xt   (+ xo2 (* 2.0 tt) (* 1.5 fac))
        ny   0)
  ;; ---- shoulders / verges ----
  (if (> tt 0.0)
    (progn
      (rp:solidfill (rp:xpl (list (list (- hw) yL) (list xo1 yL) (list (- xo1 (* 2.0 tt)) (- yL tt))
                                  (list (- hw) (- yL tt)))
                            "ROAD-XSEC" T)
                    nil "ROAD-XSEC-SHLD" 0.0)
      (rp:solidfill (rp:xpl (list (list hw yR) (list xo2 yR) (list (+ xo2 (* 2.0 tt)) (- yR tt))
                                  (list hw (- yR tt)))
                            "ROAD-XSEC" T)
                    nil "ROAD-XSEC-SHLD" 0.0)))
  ;; ---- pavement layers with labels ----
  (setq d0 0.0 i 0)
  (foreach l lys
    (setq i  (1+ i)
          d1 (+ d0 (cadr l))
          pg (append (rp:xsurf (- d0)) (reverse (rp:xsurf (- d1)))))
    (rp:solidfill (rp:xpl pg "ROAD-XSEC" T) nil (strcat "ROAD-XSEC-L" (itoa i)) 0.0)
    (setq ytx (- (+ yR (* 0.8 fac)) (* ny 2.0 th)) ny (1+ ny))
    (rp:xline (list (* 0.6 hw) (- (rp:ys (* 0.6 hw)) (* 0.5 (+ d0 d1)))) (list (- xt (* 0.3 fac)) ytx)
              "ROAD-XSEC-THIN")
    (rp:xtext (strcat (rtos (/ (* 1000.0 (cadr l)) fac) 2 0) " mm  " (car l)) (list xt ytx) th)
    (setq d0 d1))
  (if (> tt 0.0)
    (progn
      (setq ytx (- (+ yR (* 0.8 fac)) (* ny 2.0 th)) ny (1+ ny))
      (rp:xline (list (* 0.5 (+ xr xo2)) (- yR (* 0.5 tt))) (list (- xt (* 0.3 fac)) ytx) "ROAD-XSEC-THIN")
      (rp:xtext "COMPACTED SHOULDER / VERGE" (list xt ytx) th)))
  (setq ytx (- (+ yR (* 0.8 fac)) (* ny 2.0 th)) ny (1+ ny))
  (rp:xline (list (+ xo2 (* 2.0 tt) (* 0.6 fac)) (- yR tt)) (list (- xt (* 0.3 fac)) ytx) "ROAD-XSEC-THIN")
  (rp:xtext "SUBGRADE - COMPACTED" (list xt ytx) th)
  ;; ---- finished surface line ----
  (setq ln (rp:xpl (append (list (list xo1 yL)) (rp:xsurf 0.0) (list (list xo2 yR))) "ROAD-XSEC" nil))
  (vla-put-ConstantWidth ln (* 0.02 fac))
  ;; ---- subgrade / ground line with ground ticks ----
  (setq gx1 (- xo1 (* 2.0 tt) (* 1.5 fac))
        gx2 (+ xo2 (* 2.0 tt) (* 1.5 fac)))
  (rp:xpl (append (list (list gx1 (- yL tt)) (list (- xo1 (* 2.0 tt)) (- yL tt)))
                  (rp:xsurf (- tt))
                  (list (list (+ xo2 (* 2.0 tt)) (- yR tt)) (list gx2 (- yR tt))))
          "ROAD-XSEC" nil)
  (setq x gx1)
  (while (<= x gx2)
    (rp:xline (list x (- (rp:ys x) tt)) (list (- x (* 0.25 fac)) (- (rp:ys x) tt (* 0.25 fac)))
              "ROAD-XSEC-THIN")
    (setq x (+ x (* 0.5 fac))))
  ;; ---- paved shoulders ----
  (if (> bgap 0.0)
    (progn
      (setq d1 (if lys (cadr (car lys)) (* 0.05 fac)))
      (rp:solidfill (rp:xpl (list (list (- hw) yL) (list (- (+ hw bgap)) yL) (list (- (+ hw bgap)) (- yL d1))
                                  (list (- hw) (- yL d1))) "ROAD-XSEC" T) nil "ROAD-XSEC-L1" 0.0)
      (rp:solidfill (rp:xpl (list (list hw yR) (list (+ hw bgap) yR) (list (+ hw bgap) (- yR d1))
                                  (list hw (- yR d1))) "ROAD-XSEC" T) nil "ROAD-XSEC-L1" 0.0)
      (setq ytx (- (+ yR (* 0.8 fac)) (* ny 2.0 th)) ny (1+ ny))
      (rp:xline (list (+ hw (* 0.5 bgap)) (- yR (* 0.5 d1))) (list (- xt (* 0.3 fac)) ytx) "ROAD-XSEC-THIN")
      (rp:xtext (strcat "PAVED SHOULDER " (rtos (/ bgap fac) 2 2) " m") (list xt ytx) th)))
  ;; ---- edge treatment with height : barricade / cone / kerb ----
  (setq cxL  (- (+ hw bgap (* 0.5 bwid)))
        cxR  (+ hw bgap (* 0.5 bwid))
        hh   (cond ((= *rp:xet* "1") (* 0.75 fac)) ((= *rp:xet* "2") (* 0.15 fac)) (T bh))
        btxt (cond ((= *rp:xet* "1") "TRAFFIC CONE")
                   ((= *rp:xet* "2") "KERB STONE")
                   ((= (rp:val "xbtype") "1") "NEW JERSEY CONCRETE BARRIER (RED / WHITE)")
                   (T "WATER-FILLED BARRIER (RED / WHITE)")))
  (if bl (rp:xedge cxL yL bwid bh *rp:xet* "ROAD-BARRIER-RED" fac))
  (if br (rp:xedge cxR yR bwid bh *rp:xet* "ROAD-BARRIER-WHITE" fac))
  (if bc (rp:xedge 0.0 0.0 bwid bh (if (= *rp:xct* "2") "1" "0") "ROAD-BARRIER-RED" fac))
  (cond
    (bl
     (rp:dim (list (- cxL (* 0.5 bwid)) yL) (list (- cxL (* 0.5 bwid)) (+ yL hh))
             (list (- cxL (* 0.5 bwid) (* 0.6 fac)) yL) (* 0.5 pi) th fac)
     (rp:xmtext (strcat btxt "\\PH = " (rtos (/ hh fac) 2 2) " m" (if (= *rp:xet* "2") " UPSTAND" ""))
                (list cxL (+ yL (max hh bh) (* 2.2 th))) th))
    (br
     (rp:dim (list (+ cxR (* 0.5 bwid)) yR) (list (+ cxR (* 0.5 bwid)) (+ yR hh))
             (list (+ cxR (* 0.5 bwid) (* 0.6 fac)) yR) (* 0.5 pi) th fac)
     (rp:xmtext (strcat btxt "\\PH = " (rtos (/ hh fac) 2 2) " m" (if (= *rp:xet* "2") " UPSTAND" ""))
                (list cxR (+ yR (max hh bh) (* 2.2 th))) th)))
  (if bc
    (rp:xmtext (strcat "MEDIAN " (if (= *rp:xct* "2") "TRAFFIC CONES" "BARRICADE"))
               (list 0.0 (+ bh (* 3.5 th))) th))
  ;; ---- v3.4 median, sidewalks, walkways, drains, utilities ----
  (if *rp:xc* (rp:xcorr hw yL yR fac th))
  ;; ---- sign posts with clearance height ----
  (if (rp:on "xsign")
    (progn
      (rp:xpost (+ xr (* 0.5 fac)) yR sclr spl spd fac th T)
      (if two (rp:xpost (- (+ xl (* 0.5 fac))) yL sclr spl spd fac th nil))))
  ;; ---- centre line ----
  (setq top (+ (max bh (if (rp:on "xsign") (+ sclr spl) 0.0)) (* 0.8 fac))
        ln  (rp:xline (list 0.0 (- ybot (* 0.4 fac))) (list 0.0 top) "ROAD-CL"))
  (vla-put-LinetypeScale ln (/ (* 0.12 fac) (getvar "LTSCALE")))
  (rp:xmtext "CL" (list 0.0 (+ top (* 1.0 th))) (* 1.4 th))
  ;; ---- crossfall ----
  (if (> *rp:cf* 0.0)
    (if (= *rp:ct* "0")
      (progn (rp:xfall (* -0.5 hw) -1.0 th fac) (rp:xfall (* 0.5 hw) 1.0 th fac))
      (rp:xfall 0.0 (if (= *rp:ct* "1") 1.0 -1.0) th fac)))
  ;; ---- dimensions : chain, carriageway, total ----
  (setq xs (rp:xc-dims (vl-remove nil (list xo1
                                (if bl (- xl)) (if bl (- (+ hw bgap)))
                                (- hw) 0.0 hw
                                (if br (+ hw bgap)) (if br xr)
                                xo2)) hw)
        yd1 (- ybot (* 0.9 fac))
        yd2 (- ybot (* 1.7 fac))
        yd3 (- ybot (* 2.5 fac)))
  (while (cdr xs)
    (if (> (- (cadr xs) (car xs)) 1e-6)
      (rp:dim (list (car xs) (rp:ys (car xs))) (list (cadr xs) (rp:ys (cadr xs)))
              (list (* 0.5 (+ (car xs) (cadr xs))) yd1) 0.0 th fac))
    (setq xs (cdr xs)))
  (rp:dim (list (- hw) yL) (list hw yR) (list 0.0 yd2) 0.0 th fac)
  (rp:dim (list xo1 yL) (list xo2 yR) (list 0.0 yd3) 0.0 th fac)
  (rp:xtext "CARRIAGEWAY" (list (+ hw (* 0.5 fac)) yd2) (* 0.8 th))
  (rp:xtext "TOTAL FORMATION" (list (+ xo2 (* 0.5 fac)) yd3) (* 0.8 th))
  ;; ---- title ----
  (rp:xmtext (strcat "{\\L" title "}") (list 0.0 (- yd3 (* 1.6 fac))) (* 1.6 th))
  (rp:xmtext (strcat (if (/= note "") (strcat note "\\P") "")
                     "Looking towards increasing chainage  |  1 unit = 1 "
                     (if (= fac 1.0) "m" "mm") "  |  True scale")
             (list 0.0 (- yd3 (* 1.6 fac) (* 2.8 th))) (* 0.9 th))
  (princ))

(defun rp:xnote (d curves strs fac / i r)
  (setq i 0)
  (foreach c curves
    (setq i (1+ i))
    (if (and (not r) (>= d (- (car c) 1e-6)) (<= d (+ (cadr c) 1e-6)))
      (setq r (strcat "On curve C" (itoa i) " - " (if (> (nth 4 c) 0) "left" "right")
                      " bend, R (CL) = " (rtos (/ (nth 2 c) fac) 2 3) " m"))))
  (setq i 0)
  (foreach s strs
    (setq i (1+ i))
    (if (and (not r) (>= d (- (car s) 1e-6)) (<= d (+ (cadr s) 1e-6)))
      (setq r (strcat "On straight S" (itoa i)))))
  (if r r ""))

(defun rp:take (lst n / r) (repeat (min n (length lst)) (setq r (cons (car lst) r) lst (cdr lst))) (reverse r))

;; mode "0" typical / "1" one chainage / "2" every interval
(defun rp:xsec-run (e mode / data fac obj len st hw bl br bc bgap bwid two spd nm curves strs
                       pt ch d dl k iv n vg tt top dx dy lx th)
  (setq data (rp:xget e)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        st       (atof (rp:xv "CHST" data))
        hw       (* 0.5 fac (atof (rp:xv "W" data)))
        bl       (or (/= (rp:xv "BL" data) "0,0") (= (rp:xv "EL" data) "1"))
        br       (or (/= (rp:xv "BR" data) "0,0") (= (rp:xv "ER" data) "1"))
        bc       (or (/= (rp:xv "BC" data) "0,0") (member (rp:xv "CTYPE" data) '("1" "2")))
        *rp:xet* (if (= (rp:xv "ETYPE" data) "") "0" (rp:xv "ETYPE" data))
        *rp:xct* (if (= (rp:xv "CTYPE" data) "2") "2" "1")
        bgap     (* fac (atof (rp:xv "BGAP" data)))
        bwid     (* fac (atof (rp:xv "BWID" data)))
        two      (/= (rp:xv "TWOWAY" data) "0")
        spd      (if (= (rp:xv "SPEED" data) "") "30" (rp:xv "SPEED" data))
        nm       (rp:xv "NAME" data)
        curves   (rp:curves obj)
        strs     (rp:straights obj)
        *rp:hatches* nil
        *rp:cset* (vlax-ldata-get obj "ROADPRO_SET"))
  (setq *rp:xc* (list (* fac (atof (rp:xv "MW" data))) (- (* fac (atof (rp:xv "MO" data)))) (rp:xv "MED" data)
                      (atoi (rp:xv "NL" data)) (atoi (rp:xv "NR" data)) (* fac (atof (rp:xv "LW" data)))
                      (if *rp:cset* (rp:corr-layout bgap bwid bl br fac))))
  (cond
    ((= mode "1")
     (setq ch (rp:num "xch")
           d  (* fac (- ch st)))
     (if (or (< d -1e-6) (> d (+ len 1e-6)))
       (alert (strcat "Chainage " (rp:chfmt ch) " is outside this road\n("
                      (rp:chfmt st) " to " (rp:chfmt (+ st (/ len fac))) ")."))
       (if (setq pt (getpoint "\nPick point for the section centre line (finished road level): "))
         (rp:xsection pt hw bgap bwid bl br bc fac two spd
                      (strcat "CROSS SECTION AT CH " (rp:chfmt ch) "  -  " nm)
                      (rp:xnote d curves strs fac)))))
    ((= mode "2")
     (setq iv (* fac (rp:num "xint"))
           dl (list 0.0)
           k  (fix (/ (* st fac) iv))
           d  (- (* (1+ k) iv) (* st fac)))
     (if (< d (* 0.001 iv)) (setq d (+ d iv)))
     (while (< d (- len (* 0.001 iv))) (setq dl (cons d dl) d (+ d iv)))
     (setq dl (reverse (cons len dl)))
     (if (> (length dl) 60)
       (progn (princ "\nMore than 60 sections - only the first 60 are drawn.") (setq dl (rp:take dl 60))))
     (setq vg  (* fac (rp:num "xverge"))
           tt  (rp:xthk fac)
           th  (* 0.2 fac (rp:num "txth"))
           top (+ (max (* fac (rp:num "xbh"))
                       (if (rp:on "xsign") (* fac (+ (rp:num "xsclr") (rp:num "xsplate"))) 0.0))
                  (* 2.5 fac))
           lx  (+ hw (max (+ bgap bwid) (rp:xc-ext)) vg (* 2.0 tt) (* 3.0 fac))
           dx  (+ (* 2.0 lx) (* 32.0 th) (* 4.0 fac))
           dy  (+ top tt (* 9.0 fac)))
     (if (setq pt (getpoint (strcat "\nPick top-left corner for " (itoa (length dl)) " cross sections: ")))
       (progn
         (setq n 0)
         (foreach dd dl
           (rp:xsection (list (+ (car pt) (* (rem n 3) dx) lx) (- (cadr pt) top (* (/ n 3) dy)))
                        hw bgap bwid bl br bc fac two spd
                        (strcat "SECTION AT CH " (rp:chfmt (+ st (/ dd fac))))
                        (rp:xnote dd curves strs fac))
           (setq n (1+ n)))
         (princ (strcat "\n  " (itoa n) " cross sections drawn.")))))
    (T
     (if (setq pt (getpoint "\nPick point for the TYPICAL CROSS SECTION centre line <Enter = skip>: "))
       (rp:xsection pt hw bgap bwid bl br bc fac two spd
                    (strcat "TYPICAL CROSS SECTION  -  " nm) ""))))
  (if *rp:hatches* (rp:toback *rp:hatches*))
  (setq *rp:cset* nil *rp:xc* nil)
  (princ))

;;----------------------------------------------------------------------------
;;  LANE WIDENING
;;  Extra lane from a start chainage to an end chainage on the left, right or
;;  both sides, with taper in and taper out.
;;    Taper type  : Straight (linear)  or  Curve (reverse curve, tangent ends)
;;    Match point : Fillet with radius R  or  Direct link (sharp joint)
;;  The geometry is built in station-offset space and mapped onto the centre
;;  line, so it follows straights and curves of the road.
;;----------------------------------------------------------------------------
(setq *rp:wdcl*
 (list
  "roadwiden : dialog {"
  "  label = \"ROAD PRO  -  Lane Widening\";"
  "  : text { key = \"info\"; width = 60; }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Extra lane  (Left side when different)\";"
  "      : popup_list { key = \"wside\"; label = \"Side:\";                 edit_width = 16; }"
  "      : edit_box   { key = \"wwid\";  label = \"Extra width (m):\";      edit_width = 8; }"
  "      : edit_box   { key = \"wst\";   label = \"Start chainage (m):\";   edit_width = 8; }"
  "      : edit_box   { key = \"wen\";   label = \"End chainage (m):\";     edit_width = 8; }"
  "      : edit_box   { key = \"wtin\";  label = \"Taper in length (m):\";  edit_width = 8; }"
  "      : edit_box   { key = \"wtout\"; label = \"Taper out length (m):\"; edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Right side  (Both sides only)\";"
  "      : toggle   { key = \"wdiff\";  label = \"Different chainage on right side\"; }"
  "      : edit_box { key = \"wwid2\";  label = \"Extra width (m):\";      edit_width = 8; }"
  "      : edit_box { key = \"wst2\";   label = \"Start chainage (m):\";   edit_width = 8; }"
  "      : edit_box { key = \"wen2\";   label = \"End chainage (m):\";     edit_width = 8; }"
  "      : edit_box { key = \"wtin2\";  label = \"Taper in length (m):\";  edit_width = 8; }"
  "      : edit_box { key = \"wtout2\"; label = \"Taper out length (m):\"; edit_width = 8; }"
  "      : edit_box { key = \"wrad2\";  label = \"Fillet radius (m):\";    edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Taper and match points\";"
  "      : popup_list { key = \"wtype\";  label = \"Taper type:\";  edit_width = 26; }"
  "      : popup_list { key = \"wmatch\"; label = \"Match point:\"; edit_width = 26; }"
  "      : edit_box   { key = \"wrad\";   label = \"Fillet radius (m):\"; edit_width = 8; }"
  "      : toggle { key = \"wbar\"; label = \"Move barricades to the new edge\"; }"
  "      : toggle { key = \"warr\"; label = \"Lane arrow in the new lane\"; }"
  "      : toggle { key = \"wlab\"; label = \"Labels, width dimension, match points\"; }"
  "    }"
  "  }"
  "  spacer;"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:wdlg-modes (/ st both)
  (setq st   (= (get_tile "wtype") "0")
        both (= (get_tile "wside") "2"))
  (mode_tile "wmatch" (if st 0 1))
  (mode_tile "wrad" (if (and st (= (get_tile "wmatch") "0")) 0 1))
  (mode_tile "wdiff" (if both 0 1))
  (foreach k '("wwid2" "wst2" "wen2" "wtin2" "wtout2")
    (mode_tile k (if (and both (= (get_tile "wdiff") "1")) 0 1)))
  (mode_tile "wrad2" (if (and both (= (get_tile "wdiff") "1") st (= (get_tile "wmatch") "0")) 0 1)))

(defun rp:wdlg-accept (/ bad v r2)
  (setq r2 (and (= (get_tile "wside") "2") (= (get_tile "wdiff") "1")))
  (foreach k (append
               '(("wwid" "Extra width" 0) ("wst" "Start chainage" 1) ("wen" "End chainage" 1)
                 ("wtin" "Taper in length" 1) ("wtout" "Taper out length" 1) ("wrad" "Fillet radius" 0))
               (if r2 '(("wwid2" "Right extra width" 0) ("wst2" "Right start chainage" 1)
                        ("wen2" "Right end chainage" 1) ("wtin2" "Right taper in length" 1)
                        ("wtout2" "Right taper out length" 1) ("wrad2" "Right fillet radius" 0))))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (if (= (caddr k) 1) (< v 0.0) (<= v 0.0)))
          (setq bad k)))))
  (cond
    (bad
     (set_tile "error" (strcat (cadr bad)
                               (if (= (caddr bad) 1)
                                 " must be zero or a positive number."
                                 " must be a number greater than zero.")))
     (mode_tile (car bad) 2))
    ((<= (rp:dist (get_tile "wen")) (rp:dist (get_tile "wst")))
     (set_tile "error" "End chainage must be greater than the start chainage.")
     (mode_tile "wen" 2))
    ((and r2 (<= (rp:dist (get_tile "wen2")) (rp:dist (get_tile "wst2"))))
     (set_tile "error" "Right side: end chainage must be greater than the start chainage.")
     (mode_tile "wen2" 2))
    (T
     (foreach k *rp:wkeys* (rp:set k (get_tile k)))
     (done_dialog 1))))

(defun rp:wdialog (info / fn f id res)
  (setq fn (vl-filename-mktemp "roadwiden.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:wdcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadwiden" id))
        (progn
          (rp:fill "wside"  '("Left" "Right" "Both sides"))
          (rp:fill "wtype"  '("Straight (linear) taper" "Curve (reverse-curve) taper"))
          (rp:fill "wmatch" '("Fillet at match points" "Direct link (no fillet)"))
          (foreach k *rp:wkeys* (set_tile k (rp:val k)))
          (set_tile "info" info)
          (rp:wdlg-modes)
          (foreach k '("wtype" "wmatch" "wside" "wdiff") (action_tile k "(rp:wdlg-modes)"))
          (action_tile "accept" "(rp:wdlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; ---- profile helpers (station s, offset o) ----
(defun rp:acos (x) (setq x (max -1.0 (min 1.0 x))) (atan (sqrt (- 1.0 (* x x))) x))

(defun rp:unit2 (a b / d)
  (setq d (distance a b))
  (if (< d 1e-12) (list 1.0 0.0) (list (/ (- (car b) (car a)) d) (/ (- (cadr b) (cadr a)) d))))

;; Fillet the corner k between p0-k and k-p1 with radius r : list of arc points
(defun rp:fillet-pts (p0 k p1 r n / u1 u2 cr dl tl t1 sg c a0 i lst)
  (setq u1 (rp:unit2 p0 k)
        u2 (rp:unit2 k p1)
        cr (- (* (car u1) (cadr u2)) (* (cadr u1) (car u2)))
        dl (rp:acos (+ (* (car u1) (car u2)) (* (cadr u1) (cadr u2)))))
  (if (or (< (abs cr) 1e-9) (<= r 0.0))
    (list k)
    (progn
      (setq tl (* r (/ (sin (* 0.5 dl)) (cos (* 0.5 dl))))
            t1 (list (- (car k) (* tl (car u1))) (- (cadr k) (* tl (cadr u1))))
            sg (if (> cr 0.0) 1.0 -1.0)
            c  (list (- (car t1) (* sg r (cadr u1))) (+ (cadr t1) (* sg r (car u1))))
            a0 (angle c t1)
            i  0)
      (repeat (1+ n)
        (setq lst (cons (polar c (+ a0 (* sg dl (/ (float i) n))) r) lst) i (1+ i)))
      (reverse lst))))

;; Reverse-curve taper offset at x along a taper of length tl and width w
(defun rp:rc-o (x tl w / r)
  (setq r (/ (+ (* tl tl) (* w w)) (* 4.0 w)))
  (if (<= x (* 0.5 tl))
    (- r (sqrt (max 0.0 (- (* r r) (* x x)))))
    (- w (- r (sqrt (max 0.0 (- (* r r) (* (- tl x) (- tl x)))))))))

(defun rp:densify (pts step / out a b n i)
  (setq out (list (car pts)) a (car pts))
  (foreach b (cdr pts)
    (setq n (max 1 (fix (+ 0.999999 (/ (distance a b) step)))) i 1)
    (repeat n
      (setq out (cons (list (+ (car a) (* (- (car b) (car a)) (/ (float i) n)))
                            (+ (cadr a) (* (- (cadr b) (cadr a)) (/ (float i) n))))
                      out)
            i   (1+ i)))
    (setq a b))
  (reverse out))

;; Widening profile : dense list of (s o) from the first to the last match point
(defun rp:wprofile (s1 st en s2 w curve rf fac / k pts big n out s)
  (if curve
    (progn
      (setq out (list (list s1 0.0)) s (+ s1 (* 0.25 fac)))
      (while (< s st)
        (setq out (cons (list s (rp:rc-o (- s s1) (- st s1) w)) out) s (+ s (* 0.25 fac))))
      (setq out (cons (list st w) out))
      (setq out (cons (list en w) out) s (+ en (* 0.25 fac)))
      (while (< s s2)
        (setq out (cons (list s (rp:rc-o (- s2 s) (- s2 en) w)) out) s (+ s (* 0.25 fac))))
      (setq out (reverse (cons (list s2 0.0) out)))
      (rp:densify out (* 0.5 fac)))
    (progn
      (setq big (max (* 2.0 rf) fac)
            k   (list (list (- s1 big) 0.0) (list s1 0.0) (list st w) (list en w)
                      (list s2 0.0) (list (+ s2 big) 0.0))
            pts (list (car k)))
      (setq n 1)
      (repeat 4
        (setq pts (append pts
                          (if (> rf 0.0)
                            (rp:fillet-pts (nth (1- n) k) (nth n k) (nth (1+ n) k) rf
                                           (max 6 (fix (/ (* rf 0.4) (* 0.25 fac)))))
                            (list (nth n k))))
              n   (1+ n)))
      (setq pts (append pts (list (last k))))
      ;; drop the lead-in and lead-out on the original edge
      (while (and (cadr pts) (< (abs (cadr (cadr pts))) 1e-7)) (setq pts (cdr pts)))
      (setq pts (reverse pts))
      (while (and (cadr pts) (< (abs (cadr (cadr pts))) 1e-7)) (setq pts (cdr pts)))
      (rp:densify (reverse pts) (* 0.5 fac)))))

;; Offset of the profile at station s (0 outside the widening)
(defun rp:prof-o (pts s / a b r)
  (if (<= s (car (car pts)))
    (cadr (car pts))
    (progn
      (setq a (car pts) pts (cdr pts))
      (while (and pts (not r))
        (setq b (car pts))
        (if (<= s (car b))
          (setq r (if (< (- (car b) (car a)) 1e-9)
                    (cadr b)
                    (+ (cadr a) (* (- (cadr b) (cadr a)) (/ (- s (car a)) (- (car b) (car a))))))))
        (setq a b pts (cdr pts)))
      (if r r 0.0))))

;; Remove barricade units on one side between stations sA and sB
;; returns (red-removed white-removed first-centre last-centre)
(defun rp:wbar-remove (cl sg hw sA sB blen / ss i e o mn mx c p d f lat nr nw dmin dmax lay)
  (setq nr 0 nw 0
        ss (ssget "_X" '((8 . "ROAD-BARRIER-RED,ROAD-BARRIER-WHITE,ROAD-BARRIER-OUTLINE,ROAD-CONE,ROAD-CONE-BAND,ROAD-KERB"))))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (setq e (ssname ss i) o (vlax-ename->vla-object e) i (1+ i))
        (vla-GetBoundingBox o 'mn 'mx)
        (setq mn (vlax-safearray->list mn) mx (vlax-safearray->list mx)
              c  (list (* 0.5 (+ (car mn) (car mx))) (* 0.5 (+ (cadr mn) (cadr mx))))
              p  (vlax-curve-getClosestPointTo cl (list (car c) (cadr c) (caddr mn)))
              d  (vlax-curve-getDistAtPoint cl p))
        (if d
          (progn
            (setq f   (rp:frame cl d)
                  lat (+ (* (- (car c) (car (car f))) (car (cadr f)))
                         (* (- (cadr c) (cadr (car f))) (cadr (cadr f)))))
            (if (and (> (* sg lat) hw)
                     (>= d (- sA (* 0.5 blen))) (<= d (+ sB (* 0.5 blen))))
              (progn
                (setq lay (vla-get-Layer o))
                (cond ((= lay "ROAD-BARRIER-RED") (setq nr (1+ nr)))
                      ((= lay "ROAD-BARRIER-WHITE") (setq nw (1+ nw))))
                (if (/= lay "ROAD-BARRIER-OUTLINE")
                  (setq dmin (if dmin (min dmin d) d) dmax (if dmax (max dmax d) d)))
                (vla-Delete o))))))))
  (list nr nw dmin dmax))

;; Barricade units along the widened edge between stations d0 and d1
(defun rp:barrier-prof (cl pts sg hw gap bwid d0 d1 seg step elev k0
                        / d de n i dd o pa pb cnt nred nwht)
  (setq d d0 cnt k0 nred 0 nwht 0)
  (if (= *rp:etype* "1")
    ;; traffic cones along the new edge
    (progn
      (setq d (+ d0 (* 0.5 seg)))
      (while (<= d d1)
        (rp:cone (rp:offpt cl d (* sg (+ hw (rp:prof-o pts d) gap (* 0.5 bwid)))) bwid elev)
        (setq d (+ d seg)))
      (setq d d1)))
  (if (= *rp:etype* "2") (setq *rp:unitfill* "ROAD-KERB"))
  (while (< d (- d1 1e-6))
    (setq de (+ d seg))
    (if (> de (- d1 (* 0.25 seg))) (setq de d1))
    (setq n  (max 1 (fix (+ 0.999999 (/ (- de d) step))))
          pa nil pb nil i 0)
    (repeat (1+ n)
      (setq dd (+ d (* (- de d) (/ (float i) n)))
            o  (rp:prof-o pts dd)
            pa (cons (rp:offpt cl dd (* sg (+ hw o gap))) pa)
            pb (cons (rp:offpt cl dd (* sg (+ hw o gap bwid))) pb)
            i  (1+ i)))
    (rp:solidfill (rp:poly (append (reverse pa) pb) "ROAD-BARRIER-OUTLINE" elev)
                  nil
                  (cond (*rp:unitfill* *rp:unitfill*)
                        ((= 0 (rem cnt 2)) "ROAD-BARRIER-RED")
                        (T "ROAD-BARRIER-WHITE"))
                  elev)
    (if (= 0 (rem cnt 2)) (setq nred (1+ nred)) (setq nwht (1+ nwht)))
    (setq cnt (1+ cnt) d de))
  (setq *rp:unitfill* nil)
  (if (member *rp:etype* '("1" "2")) (list 0 0) (list nred nwht)))

;; Radius mark at station s on an edge at offset eoff : leader arrow + "R=.." text
;; placed on the pavement side of the edge, parallel to the road
(defun rp:rmark (cl s eoff sg rr fac th elev / pe pm pt f ang rot tx)
  (setq pe  (rp:offpt cl s (* sg eoff))
        pm  (rp:offpt cl s (* sg (- eoff (* 1.2 fac))))
        pt  (rp:offpt cl s (* sg (- eoff (* 1.2 fac) (* 0.9 th))))
        f   (rp:frame cl s)
        ang (angle '(0.0 0.0) (caddr f))
        rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang))
  (rp:mkwpl (list (list pm 0.0 0.0)
                  (list (rp:towards pe pm (* 0.5 th)) (* 0.25 th) 0.0)
                  (list pe 0.0 0.0))
            "ROAD-WIDENING" elev)
  (setq tx (rp:text (strcat "R=" (rtos (/ rr fac) 2 2)) pt (* 0.7 th) "ROAD-WIDENING" elev))
  (vla-put-Rotation tx rot)
  tx)

;; One side of a widening. Returns (record bar-change surface-hatch)
(defun rp:widen-side (cl id sg hw w s1 st en s2 curve rf fac th elev st0 iv
                      barq bgap bwid blen two
                      / pts wp ep bnd h area edge rmv add k0 sA sB mid f ang rot ip mt
                        dimo p1 p2 kp rows s o pp lbl side tr txt)
  (setq pts (rp:wprofile s1 st en s2 w curve rf fac)
        sA  (car (car pts))
        sB  (car (last pts))
        wp  (mapcar '(lambda (p) (rp:offpt cl (car p) (* sg (+ hw (cadr p))))) pts)
        ep  (mapcar '(lambda (p) (rp:offpt cl (car p) (* sg hw))) pts)
        side (if (> sg 0) "Left" "Right"))
  ;; new road edge
  (setq edge (rp:mkpl (mapcar '(lambda (p) (list p 0.0)) wp) "ROAD-EDGE" elev nil))
  ;; widening surface
  (setq bnd (rp:poly (append wp (reverse (cdr (reverse (cdr (reverse ep)))))) "ROAD-SURFACE" elev)
        h   (rp:newhatch "SOLID" nil elev))
  (vla-put-Layer h "ROAD-SURFACE")
  (vla-AppendOuterLoop h (rp:objarr (list bnd)))
  (vla-Evaluate h)
  (vl-catch-all-apply 'vla-put-EntityTransparency (list h "50"))
  (setq area (vla-get-Area h))
  (vla-Delete bnd)
  ;; barricades moved to the new edge
  (setq add (list 0 0) rmv (list 0 0 nil nil))
  (if barq
    (progn
      (setq rmv (rp:wbar-remove cl sg hw sA sB blen))
      (if (caddr rmv)
        (setq k0  (fix (+ 0.5 (/ (- (caddr rmv) (* 0.5 blen)) blen)))
              add (rp:barrier-prof cl pts sg hw bgap bwid
                                   (max 0.0 (- (caddr rmv) (* 0.5 blen)))
                                   (min *rp:len* (+ (cadddr rmv) (* 0.5 blen)))
                                   blen (min blen (* 0.5 fac)) elev k0)))))
  ;; lane arrow in the new lane
  (if (and (rp:on "warr") (>= (- en st) (* 12.0 fac)))
    (progn
      (setq f   (rp:frame cl (* 0.5 (+ st en)))
            ang (angle '(0.0 0.0) (caddr f)))
      (rp:arrow (rp:loc f (* sg (+ hw (* 0.5 w))) 0.0)
                (if (and (> sg 0) two) (+ ang pi) ang) fac elev)))
  ;; key points (taper start, full width start / end, taper end)
  (setq kp (list (list (car (car pts)) "TS")))
  (foreach q pts (if (and (>= (cadr q) (- w 1e-6)) (not (assoc "FS" (mapcar 'reverse kp))))
                   (setq kp (cons (list (car q) "FS") kp))))
  (foreach q (reverse pts) (if (and (>= (cadr q) (- w 1e-6)) (not (assoc "FE" (mapcar 'reverse kp))))
                             (setq kp (cons (list (car q) "FE") kp))))
  (setq kp (cons (list (car (last pts)) "TE") kp))
  ;; setting-out rows : key points + every chainage interval
  (if (> iv 0.0)
    (progn
      (setq s (* iv (fix (+ 1.0 (/ (+ sA (* st0 fac)) iv)))))
      (setq s (- s (* st0 fac)))
      (while (< s sB)
        (if (> s sA) (setq kp (cons (list s "CH") kp)))
        (setq s (+ s iv)))))
  (setq kp (vl-sort kp '(lambda (a b) (< (car a) (car b)))))
  (foreach q kp
    (setq o  (rp:prof-o pts (car q))
          pp (rp:offpt cl (car q) (* sg (+ hw o)))
          rows (cons (list (strcat id "-" (if (> sg 0) "L" "R")) (cadr q)
                           (rp:chfmt (+ st0 (/ (car q) fac)))
                           (rtos (/ (* sg (+ hw o)) fac) 2 3)
                           (rtos (/ (car pp) fac) 2 3) (rtos (/ (cadr pp) fac) 2 3))
                     rows)))
  (setq rows (reverse rows))
  ;; labels, dimension, match point markers
  (if (rp:on "wlab")
    (progn
      (foreach q kp
        (if (/= (cadr q) "CH")
          (progn
            (setq o  (rp:prof-o pts (car q))
                  pp (rp:offpt cl (car q) (* sg (+ hw o))))
            (vla-put-Layer (vla-AddCircle *rp:spc* (rp:p3 pp elev) (* 0.3 fac)) "ROAD-WIDENING")
            (rp:sidetext cl (car q) (strcat (cadr q) " " (rp:chfmt (+ st0 (/ (car q) fac))))
                         (* sg (+ hw o (* 0.8 fac))) (* 0.8 th) "ROAD-WIDENING" elev))))
      ;; radius marks : every fillet, or both arcs of each reverse-curve taper
      (if curve
        (foreach q (list (list (+ s1 (* 0.25 (- st s1))) (- st s1)) (list (+ s1 (* 0.75 (- st s1))) (- st s1))
                         (list (+ en (* 0.25 (- s2 en))) (- s2 en)) (list (+ en (* 0.75 (- s2 en))) (- s2 en)))
          (if (> (cadr q) 0.0)
            (rp:rmark cl (car q) (+ hw (rp:prof-o pts (car q))) sg
                      (/ (+ (* (cadr q) (cadr q)) (* w w)) (* 4.0 w)) fac th elev)))
        (if (> rf 0.0)
          (foreach sc (list s1 st en s2)
            (rp:rmark cl sc (+ hw (rp:prof-o pts sc)) sg rf fac th elev))))
      (setq mid (* 0.5 (+ st en))
            p1  (rp:offpt cl mid (* sg hw))
            p2  (rp:offpt cl mid (* sg (+ hw w)))
            f   (rp:frame cl mid)
            dimo (vla-AddDimAligned *rp:spc* (rp:p3 p1 elev) (rp:p3 p2 elev)
                                    (rp:p3 (rp:pt+ (rp:towards p1 p2 (* 0.5 w)) (caddr f) (* 3.0 fac)) elev)))
      (vla-put-Layer dimo "ROAD-WIDENING")
      (foreach pr (list (list 'vla-put-TextHeight (* 0.8 th)) (list 'vla-put-ArrowheadSize (* 0.5 th))
                        (list 'vla-put-PrimaryUnitsPrecision (if (= fac 1.0) acDimPrecisionTwo acDimPrecisionZero)))
        (vl-catch-all-apply (car pr) (list dimo (cadr pr))))
      (setq ang (angle '(0.0 0.0) (caddr f))
            rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang)
            ip  (rp:offpt cl mid (* sg (+ hw w bgap bwid (* 1.0 fac) (* 3.0 th))))
            tr  (if curve
                  (strcat "CURVE TAPER (REVERSE CURVE)  R in "
                          (rtos (/ (/ (+ (* (- st s1) (- st s1)) (* w w)) (* 4.0 w)) fac) 2 1) " m  /  R out "
                          (rtos (/ (/ (+ (* (- s2 en) (- s2 en)) (* w w)) (* 4.0 w)) fac) 2 1) " m")
                  (strcat "STRAIGHT TAPER 1:" (rtos (/ (- st s1) w) 2 1) " in, 1:" (rtos (/ (- s2 en) w) 2 1) " out"
                          (if (> rf 0.0) (strcat "  -  FILLET R=" (rtos (/ rf fac) 2 1) " m") "  -  DIRECT LINK")))
            mt  (vla-AddMText *rp:spc* (rp:p3 ip elev) 0.0
                  (strcat "LANE WIDENING " id " (" side ")  +" (rtos (/ w fac) 2 2) " m"
                          "\\PCH " (rp:chfmt (+ st0 (/ st fac))) " - " (rp:chfmt (+ st0 (/ en fac)))
                          "\\PTAPER IN " (rtos (/ (- st s1) fac) 2 1) " m  /  OUT " (rtos (/ (- s2 en) fac) 2 1) " m"
                          "\\P" tr
                          "\\PAREA = " (rtos (/ area fac fac) 2 2) " m\\U+00B2")))
      (vla-put-Height mt (* 0.8 th))
      (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
      (vla-put-InsertionPoint mt (rp:p3 ip elev))
      (vla-put-Rotation mt rot)
      (vla-put-Layer mt "ROAD-WIDENING")))
  (list (list (strcat id "-" (if (> sg 0) "L" "R")) side (rtos (/ w fac) 2 2)
              (rp:chfmt (+ st0 (/ st fac))) (rp:chfmt (+ st0 (/ en fac)))
              (rtos (/ (- st s1) fac) 2 1) (rtos (/ (- s2 en) fac) 2 1)
              (if curve "Curve (reverse curve)" "Straight")
              (if curve "Tangent (curve)" (if (> rf 0.0) (strcat "Fillet R " (rtos (/ rf fac) 2 1) " m") "Direct link"))
              (rtos (/ area fac fac) 2 2)
              rows)
        (list (- (car add) (car rmv)) (- (cadr add) (cadr rmv)))
        h pts))

;; Widening values for one side : (w st en s1 s2)
;; the right side uses its own fields when Both sides + different chainage
(defun rp:wside-par (sg fac st0 / sx st en)
  (setq sx (if (and (< sg 0) (= (rp:val "wside") "2") (= (rp:val "wdiff") "1")) "2" "")
        st (* fac (- (rp:num (strcat "wst" sx)) st0))
        en (* fac (- (rp:num (strcat "wen" sx)) st0)))
  (list (* fac (rp:num (strcat "wwid" sx))) st en
        (- st (* fac (rp:num (strcat "wtin" sx))))
        (+ en (* fac (rp:num (strcat "wtout" sx))))
        (* fac (rp:num (strcat "wrad" sx)))))

;; Keep the fillet radius inside the tapers and the full-width length
(defun rp:wrf (rf w st en s1 s2 fac sg / rfmax dl)
  (if (> rf 0.0)
    (progn
      (setq rfmax 1e99)
      (foreach tl (list (- st s1) (- s2 en))
        (setq dl    (atan w tl)
              rfmax (min rfmax (/ (min (* 0.5 (sqrt (+ (* tl tl) (* w w)))) (* 0.5 (- en st)))
                                  (/ (sin (* 0.5 dl)) (cos (* 0.5 dl)))))))
      (if (> rf rfmax)
        (progn
          (princ (strcat "\nFillet radius reduced to " (rtos (/ rfmax fac) 2 1) " m on the "
                         (if (> sg 0) "left" "right") " side so it fits inside the tapers."))
          rfmax)
        rf))
    rf))

(defun rp:widen-run (e / data fac obj len st0 hw bgap bwid blen two curve rf0 rf pr bad
                       sides recs old id bl br res surf iv elev th wgaps)
  (setq data (rp:xget e)
        *rp:etype* (rp:etype data)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        elev     (vla-get-Elevation obj)
        st0      (atof (rp:xv "CHST" data))
        iv       (* fac (atof (rp:xv "CHINT" data)))
        hw       (* 0.5 fac (atof (rp:xv "W" data)))
        bgap     (* fac (atof (rp:xv "BGAP" data)))
        bwid     (* fac (atof (rp:xv "BWID" data)))
        blen     (* fac (atof (rp:xv "BLEN" data)))
        two      (/= (rp:xv "TWOWAY" data) "0")
        th       (* fac (rp:num "txth"))
        curve    (= (rp:val "wtype") "1")
        rf0      (and (not curve) (= (rp:val "wmatch") "0"))
        sides    (cond ((= (rp:val "wside") "0") '(1.0))
                       ((= (rp:val "wside") "1") '(-1.0))
                       (T '(1.0 -1.0)))
        *rp:hatches* nil)
  (if (<= blen 0.0) (setq blen (* 2.0 fac)))
  ;; check every side before drawing anything
  (foreach sg sides
    (setq pr (rp:wside-par sg fac st0))
    (if (and (not bad) (or (< (nth 3 pr) -1e-6) (> (nth 4 pr) (+ len 1e-6))))
      (setq bad (list sg pr))))
  (cond
    (bad
     (alert (strcat "The " (if (> (car bad) 0) "LEFT" "RIGHT")
                    " side widening with its tapers runs outside the road.\n\n"
                    "Road : " (rp:chfmt st0) " to " (rp:chfmt (+ st0 (/ len fac))) "\n"
                    "Widening incl. tapers : " (rp:chfmt (+ st0 (/ (nth 3 (cadr bad)) fac))) " to "
                    (rp:chfmt (+ st0 (/ (nth 4 (cadr bad)) fac))) "\n\n"
                    "The start chainage is where the FULL width starts;\n"
                    "the taper in is added before it.")))
    (T
     (setq old (vlax-ldata-get obj "ROADPRO_WIDEN")
           id  (strcat "W" (itoa (1+ (length old))))
           bl  (rp:pairget (rp:xv "BL" data))
           br  (rp:pairget (rp:xv "BR" data)))
     (foreach sg sides
       (setq pr  (rp:wside-par sg fac st0)
             rf  (rp:wrf (if rf0 (nth 5 pr) 0.0) (nth 0 pr) (nth 1 pr) (nth 2 pr) (nth 3 pr) (nth 4 pr) fac sg)
             res (rp:widen-side obj id sg hw (nth 0 pr) (nth 3 pr) (nth 1 pr) (nth 2 pr) (nth 4 pr)
                                curve rf fac th elev st0 iv
                                (and (rp:on "wbar")
                                     (rp:edge-on data sg))
                                bgap bwid blen two))
       (setq wgaps (append wgaps
                           (list (list "E" sg (nth 3 pr) (nth 4 pr))
                                 (list "W" sg (rp:wprofile (nth 3 pr) (nth 1 pr) (nth 2 pr) (nth 4 pr) (nth 0 pr) curve rf fac))
                                 (list "A" sg (nth 1 pr) (nth 2 pr)))))
       (setq recs (cons (car res) recs)
             surf (cons (caddr res) surf))
       (if (> sg 0)
         (setq bl (list (+ (car bl) (car (cadr res))) (+ (cadr bl) (cadr (cadr res)))))
         (setq br (list (+ (car br) (car (cadr res))) (+ (cadr br) (cadr (cadr res)))))))
     ;; draw order, stored data
     (if *rp:hatches* (rp:toback *rp:hatches*))
     (if surf (rp:toback surf))
     (vlax-ldata-put obj "ROADPRO_WIDEN" (append old (reverse recs)))
     (vlax-ldata-put obj "ROADPRO_MKGAP" (append (vlax-ldata-get obj "ROADPRO_MKGAP") wgaps))
     (setq data (vl-remove-if '(lambda (x) (member (car x) '("BL" "BR"))) data))
     (rp:xput e (append data (list (cons "BL" (rp:pair bl)) (cons "BR" (rp:pair br)))))
     (rp:refresh e)
     (foreach r (reverse recs)
       (princ (strcat "\n  " (car r) " (" (cadr r) ") +" (caddr r) " m  CH " (nth 3 r) " - " (nth 4 r)
                      "  |  " (nth 7 r) ", " (nth 8 r) "  |  area " (nth 9 r) " m2")))
     (princ "\n  Lane widening added. Run RDR for the updated report.")))
  (princ))

;;----------------------------------------------------------------------------
;;  ROAD TAPER
;;  Widen (+) or narrow (-) the road edge on the left, right or both sides
;;  between ANY start and end chainage. The new width continues to the road
;;  end; add more tapers anywhere to change it again (they add up).
;;    Taper type  : Straight (linear)  or  Curve (reverse curve)
;;    Match point : Fillet with radius R  or  Direct link
;;  Each run rebuilds the edge, surface, barricades and labels of that side.
;;----------------------------------------------------------------------------
(setq *rp:tdcl*
 (list
  "roadtaper : dialog {"
  "  label = \"ROAD PRO  -  Road Taper\";"
  "  : text { key = \"info\"; width = 64; }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Where and how much  (Left side when different)\";"
  "      : popup_list { key = \"tside\";  label = \"Side:\";                     edit_width = 16; }"
  "      : edit_box   { key = \"tst\";    label = \"Taper start chainage (m):\"; edit_width = 8; }"
  "      : edit_box   { key = \"ten\";    label = \"Taper end chainage (m):\";   edit_width = 8; }"
  "      : edit_box   { key = \"tshift\"; label = \"Edge shift per side (m):\";  edit_width = 8; }"
  "      : text { label = \"+ = wider road     - = narrower road\"; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Right side  (Both sides only)\";"
  "      : toggle   { key = \"tdiff\";   label = \"Different chainage on right side\"; }"
  "      : edit_box { key = \"tst2\";    label = \"Taper start chainage (m):\"; edit_width = 8; }"
  "      : edit_box { key = \"ten2\";    label = \"Taper end chainage (m):\";   edit_width = 8; }"
  "      : edit_box { key = \"tshift2\"; label = \"Edge shift (m):\";           edit_width = 8; }"
  "      : edit_box { key = \"trad2\";   label = \"Fillet radius (m):\";        edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Taper and match points\";"
  "      : popup_list { key = \"ttype\";  label = \"Taper type:\";  edit_width = 26; }"
  "      : popup_list { key = \"tmatch\"; label = \"Match point:\"; edit_width = 26; }"
  "      : edit_box   { key = \"trad\";   label = \"Fillet radius (m):\"; edit_width = 8; }"
  "      : toggle { key = \"tbar\"; label = \"Barricades follow the new edge\"; }"
  "      : toggle { key = \"tlab\"; label = \"Labels and match points\"; }"
  "    }"
  "  }"
  "  : text { label = \"The new width continues to the road end. Run RDT again to add more tapers anywhere.\"; }"
  "  spacer;"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:tdlg-modes (/ st both)
  (setq st   (= (get_tile "ttype") "0")
        both (= (get_tile "tside") "2"))
  (mode_tile "tmatch" (if st 0 1))
  (mode_tile "trad" (if (and st (= (get_tile "tmatch") "0")) 0 1))
  (mode_tile "tdiff" (if both 0 1))
  (foreach k '("tst2" "ten2" "tshift2")
    (mode_tile k (if (and both (= (get_tile "tdiff") "1")) 0 1)))
  (mode_tile "trad2" (if (and both (= (get_tile "tdiff") "1") st (= (get_tile "tmatch") "0")) 0 1)))

(defun rp:tdlg-accept (/ bad v v2 r2)
  (setq r2 (and (= (get_tile "tside") "2") (= (get_tile "tdiff") "1")))
  (foreach k (append '(("tst" "Taper start chainage" 1) ("ten" "Taper end chainage" 1) ("trad" "Fillet radius" 0))
                     (if r2 '(("tst2" "Right taper start chainage" 1) ("ten2" "Right taper end chainage" 1)
                              ("trad2" "Right fillet radius" 0))))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (if (= (caddr k) 1) (< v 0.0) (<= v 0.0)))
          (setq bad k)))))
  (setq v  (rp:dist (get_tile "tshift"))
        v2 (rp:dist (get_tile "tshift2")))
  (cond
    (bad
     (set_tile "error" (strcat (cadr bad)
                               (if (= (caddr bad) 1)
                                 " must be zero or a positive number."
                                 " must be a number greater than zero.")))
     (mode_tile (car bad) 2))
    ((or (null v) (< (abs v) 0.001))
     (set_tile "error" "Edge shift must be a number, + to widen or - to narrow (not zero).")
     (mode_tile "tshift" 2))
    ((<= (rp:dist (get_tile "ten")) (rp:dist (get_tile "tst")))
     (set_tile "error" "Taper end chainage must be greater than the start chainage.")
     (mode_tile "ten" 2))
    ((and r2 (or (null v2) (< (abs v2) 0.001)))
     (set_tile "error" "Right side edge shift must be + to widen or - to narrow (not zero).")
     (mode_tile "tshift2" 2))
    ((and r2 (<= (rp:dist (get_tile "ten2")) (rp:dist (get_tile "tst2"))))
     (set_tile "error" "Right side: taper end chainage must be greater than the start chainage.")
     (mode_tile "ten2" 2))
    (T
     (foreach k *rp:tkeys* (rp:set k (get_tile k)))
     (done_dialog 1))))

(defun rp:tdialog (info / fn f id res)
  (setq fn (vl-filename-mktemp "roadtaper.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:tdcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadtaper" id))
        (progn
          (rp:fill "tside"  '("Left" "Right" "Both sides"))
          (rp:fill "ttype"  '("Straight (linear) taper" "Curve (reverse-curve) taper"))
          (rp:fill "tmatch" '("Fillet at match points" "Direct link (no fillet)"))
          (foreach k *rp:tkeys* (set_tile k (rp:val k)))
          (set_tile "info" info)
          (rp:tdlg-modes)
          (foreach k '("ttype" "tmatch" "tside" "tdiff") (action_tile k "(rp:tdlg-modes)"))
          (action_tile "accept" "(rp:tdlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; One-way taper profile (s o) : from 0 at the start match point to d at the end
(defun rp:tprofile (a b d curve rf fac / sg ad out s big k pts n)
  (if curve
    (progn
      (setq sg  (if (< d 0.0) -1.0 1.0)
            ad  (abs d)
            out (list (list a 0.0))
            s   (+ a (* 0.25 fac)))
      (while (< s b)
        (setq out (cons (list s (* sg (rp:rc-o (- s a) (- b a) ad))) out)
              s   (+ s (* 0.25 fac))))
      (rp:densify (reverse (cons (list b d) out)) (* 0.5 fac)))
    (progn
      (setq big (max (* 2.0 rf) fac)
            k   (list (list (- a big) 0.0) (list a 0.0) (list b d) (list (+ b big) d))
            n   (max 6 (fix (/ (* rf 0.4) (* 0.25 fac)))))
      (setq pts (append (list (car k))
                        (if (> rf 0.0)
                          (append (rp:fillet-pts (nth 0 k) (nth 1 k) (nth 2 k) rf n)
                                  (rp:fillet-pts (nth 1 k) (nth 2 k) (nth 3 k) rf n))
                          (list (nth 1 k) (nth 2 k)))))
      (while (and (cadr pts) (< (abs (cadr (cadr pts))) 1e-7)) (setq pts (cdr pts)))
      (rp:densify pts (* 0.5 fac)))))

;; Profile value that HOLDS the end value after the last point
(defun rp:prof-hold (pts s)
  (cond ((<= s (car (car pts))) (cadr (car pts)))
        ((>= s (car (last pts))) (cadr (last pts)))
        (T (rp:prof-o pts s))))

(defun rp:taper-profs (recs sg fac / out)
  (foreach r recs
    (if (= (nth 2 r) sg)
      (setq out (cons (rp:tprofile (nth 3 r) (nth 4 r) (nth 5 r) (= (nth 6 r) 1) (nth 7 r) fac) out))))
  (reverse out))

;; Edge offset from the CL on one side at station s (all tapers of that side)
(defun rp:soff (profs hw s / t0)
  (setq t0 hw)
  (foreach p profs (setq t0 (+ t0 (rp:prof-hold p s))))
  t0)

(defun rp:tstations (profs s0 len fac / s lst out prev)
  (setq s s0)
  (while (< s len) (setq lst (cons s lst) s (+ s fac)))
  (setq lst (cons len lst))
  (foreach p profs
    (foreach q p (if (and (>= (car q) s0) (<= (car q) len)) (setq lst (cons (car q) lst)))))
  (foreach x (vl-sort lst '<)
    (if (or (null prev) (> (- x prev) 1e-6)) (setq out (cons x out) prev x)))
  (reverse out))

(defun rp:since (mark / e lst)
  (setq e (if mark (entnext mark) (entnext)))
  (while e (setq lst (cons e lst) e (entnext e)))
  (reverse lst))

(defun rp:order-ss (enames opt / ss)
  (setq ss (ssadd))
  (foreach en enames (ssadd en ss))
  (if (> (sslength ss) 0) (command "_.DRAWORDER" ss "" opt)))

;; Break object e between points p1 and p2. The points are snapped onto e,
;; OSNAP is off, and BREAK is never left waiting for the user.
(defun rp:break (e p1 p2 / om q1 q2)
  (if (and e (entget e) p1 p2)
    (progn
      (setq q1 (vlax-curve-getClosestPointTo e (list (car p1) (cadr p1) (if (caddr p1) (caddr p1) 0.0)))
            q2 (vlax-curve-getClosestPointTo e (list (car p2) (cadr p2) (if (caddr p2) (caddr p2) 0.0))))
      (if (and q1 q2 (> (distance (list (car q1) (cadr q1)) (list (car q2) (cadr q2))) 1e-6))
        (progn
          (setq om (getvar "OSMODE"))
          (setvar "OSMODE" 0)
          (command "_.BREAK" (list e (trans q1 0 1)) "_F" (trans q1 0 1) (trans q2 0 1))
          (while (> (getvar "CMDACTIVE") 0) (command))
          (setvar "OSMODE" om)
          T)))))

;; Shorten the original road edge on one side, from station s to its end
(defun rp:break-edge (cl sg hw s fac elev / p ss i e cp best bl l om)
  (setq p  (rp:offpt cl s (* sg hw))
        ss (ssget "_X" '((0 . "LWPOLYLINE") (8 . "ROAD-EDGE")))
        i  0
        bl 0.0)
  (if ss
    (repeat (sslength ss)
      (setq e (ssname ss i) i (1+ i)
            cp (vlax-curve-getClosestPointTo e (list (car p) (cadr p) elev)))
      (if (and cp (< (distance (list (car cp) (cadr cp)) p) (* 0.002 fac)))
        (progn
          (setq l (vlax-curve-getDistAtParam e (vlax-curve-getEndParam e)))
          (if (> l bl) (setq best e bl l))))))
  (if best
    (progn
      (setq om (getvar "OSMODE"))
      (setvar "OSMODE" 0)
      (rp:break best (list (car p) (cadr p) elev) (vlax-curve-getEndPoint best))
      (setvar "OSMODE" om)
      T)
    (progn (princ "\nNote: original road edge not found on this side - it was left as it is.") nil)))

;; Wipeout over a narrowed area, returns its area
(defun rp:wipe (pts elev / pl ar w)
  (setq pl (rp:poly pts "ROAD-SURFACE" elev)
        ar (vla-get-Area pl))
  (command "_.WIPEOUT" "_P" (vlax-vla-object->ename pl) "_Y")
  (setq w (entlast))
  (if (and w (= (cdr (assoc 0 (entget w))) "WIPEOUT"))
    (vla-put-Layer (vlax-ename->vla-object w) "ROAD-SURFACE"))
  ar)

;; Rebuild everything a taper changes on one side. Returns (d-red d-white add-area cut-area)
(defun rp:taper-rebuild (cl sg hw fac len elev blen bgap bwid barq labq st0 th all
                         / sd recs profs s0 e en nr nw brk mark stl offs grp grps prev cur o k
                           newp oldp bnd h addA cutA rmv bstart rel add p q pp mid f ang rot ip mt
                           new ty ly wl bh sh oth)
  (setq sd    (if (> sg 0) "L" "R")
        recs  (vl-remove-if-not '(lambda (r) (= (nth 2 r) sg)) all)
        profs (rp:taper-profs all sg fac)
        s0    (apply 'min (mapcar '(lambda (x) (car (car x))) profs))
        nr 0 nw 0 addA 0.0 cutA 0.0 add (list 0 0))
  ;; 1. remove what earlier tapers drew on this side
  (foreach hd (vlax-ldata-get cl (strcat "ROADPRO_TMAN_" sd))
    (if (and (setq en (handent hd)) (entget en))
      (progn
        (if (= (cdr (assoc 0 (entget en))) "HATCH")
          (cond ((= (cdr (assoc 8 (entget en))) "ROAD-BARRIER-RED") (setq nr (1+ nr)))
                ((= (cdr (assoc 8 (entget en))) "ROAD-BARRIER-WHITE") (setq nw (1+ nw)))))
        (entdel en))))
  ;; 2. shorten the original edge (only further back than before)
  (setq brk (vlax-ldata-get cl (strcat "ROADPRO_TBRK_" sd)))
  (if (or (null brk) (< s0 (- brk 1e-6)))
    (progn
      (rp:break-edge cl sg hw s0 fac elev)
      (vlax-ldata-put cl (strcat "ROADPRO_TBRK_" sd) s0)))
  (setq mark (entlast))
  ;; 3. new edge from the first taper to the road end
  (setq stl  (rp:tstations profs s0 len fac)
        offs (mapcar '(lambda (x) (list x (rp:soff profs hw x))) stl))
  (rp:mkpl (mapcar '(lambda (x) (list (rp:offpt cl (car x) (* sg (cadr x))) 0.0)) offs) "ROAD-EDGE" elev nil)
  ;; 4. surface : added (hatch) and removed (wipeout) areas
  (setq cur 0)
  (foreach x offs
    (setq o (- (cadr x) hw)
          k (cond ((> o (* 0.001 fac)) 1) ((< o (* -0.001 fac)) -1) (T 0)))
    (cond
      ((and (/= k 0) (= k cur)) (setq grp (cons x grp)))
      (T
       (if grp (setq grps (cons (list cur (reverse (cons x grp))) grps)))
       (setq grp (if (/= k 0) (if prev (list x prev) (list x)) nil)
             cur k)))
    (setq prev x))
  (if grp (setq grps (cons (list cur (reverse grp)) grps)))
  (foreach g grps
    (if (>= (length (cadr g)) 2)
      (progn
        (setq newp (mapcar '(lambda (x) (rp:offpt cl (car x) (* sg (cadr x)))) (cadr g))
              oldp (reverse (mapcar '(lambda (x) (rp:offpt cl (car x) (* sg hw))) (cadr g))))
        (if (> (car g) 0)
          (progn
            (setq bnd (rp:poly (append newp oldp) "ROAD-SURFACE" elev)
                  h   (rp:newhatch "SOLID" nil elev))
            (vla-put-Layer h "ROAD-SURFACE")
            (vla-AppendOuterLoop h (rp:objarr (list bnd)))
            (vla-Evaluate h)
            (vl-catch-all-apply 'vla-put-EntityTransparency (list h "50"))
            (setq addA (+ addA (vla-get-Area h)))
            (vla-Delete bnd))
          (setq cutA (+ cutA (rp:wipe (append newp oldp) elev)))))))
  ;; 5. barricades follow the new edge
  (if barq
    (progn
      (setq rmv    (rp:wbar-remove cl sg hw s0 len blen)
            bstart (vlax-ldata-get cl (strcat "ROADPRO_TBAR_" sd))
            nr     (+ nr (car rmv))
            nw     (+ nw (cadr rmv)))
      (if (caddr rmv)
        (setq bstart (if bstart
                       (min bstart (- (caddr rmv) (* 0.5 blen)))
                       (- (caddr rmv) (* 0.5 blen)))))
      (if bstart
        (progn
          (setq bstart (max 0.0 bstart)
                rel    (mapcar '(lambda (x) (list (car x) (- (cadr x) hw))) offs))
          (vlax-ldata-put cl (strcat "ROADPRO_TBAR_" sd) bstart)
          (setq add (rp:barrier-prof cl rel sg hw bgap bwid bstart len blen
                                     (min blen (* 0.5 fac)) elev
                                     (fix (+ 0.5 (/ bstart blen)))))))))
  ;; 6. labels and match points
  (if labq
    (foreach r recs
      (setq p (rp:tprofile (nth 3 r) (nth 4 r) (nth 5 r) (= (nth 6 r) 1) (nth 7 r) fac))
      (foreach q (list (list (car (car p)) "TS") (list (car (last p)) "TE"))
        (setq o  (rp:soff profs hw (car q))
              pp (rp:offpt cl (car q) (* sg o)))
        (vla-put-Layer (vla-AddCircle *rp:spc* (rp:p3 pp elev) (* 0.3 fac)) "ROAD-WIDENING")
        (rp:sidetext cl (car q) (strcat (cadr q) " " (rp:chfmt (+ st0 (/ (car q) fac))))
                     (* sg (+ o (* 0.8 fac))) (* 0.8 th) "ROAD-WIDENING" elev))
      ;; radius marks : both fillets, or both arcs of the reverse curve
      (if (= (nth 6 r) 1)
        (foreach sc (list (+ (nth 3 r) (* 0.25 (- (nth 4 r) (nth 3 r))))
                          (+ (nth 3 r) (* 0.75 (- (nth 4 r) (nth 3 r)))))
          (rp:rmark cl sc (rp:soff profs hw sc) sg
                    (/ (+ (* (- (nth 4 r) (nth 3 r)) (- (nth 4 r) (nth 3 r))) (* (nth 5 r) (nth 5 r)))
                       (* 4.0 (abs (nth 5 r))))
                    fac th elev))
        (if (> (nth 7 r) 0.0)
          (foreach sc (list (nth 3 r) (nth 4 r))
            (rp:rmark cl sc (rp:soff profs hw sc) sg (nth 7 r) fac th elev))))
      (setq mid (* 0.5 (+ (nth 3 r) (nth 4 r)))
            f   (rp:frame cl mid)
            ang (angle '(0.0 0.0) (caddr f))
            rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang)
            ip  (rp:offpt cl mid (* sg (+ (rp:soff profs hw mid) bgap bwid fac (* 3.0 th))))
            mt  (vla-AddMText *rp:spc* (rp:p3 ip elev) 0.0
                  (strcat "ROAD TAPER " (car r) "  EDGE " (if (> (nth 5 r) 0) "+" "")
                          (rtos (/ (nth 5 r) fac) 2 2) " m"
                          "\\PCH " (rp:chfmt (+ st0 (/ (nth 3 r) fac))) " - "
                          (rp:chfmt (+ st0 (/ (nth 4 r) fac)))
                          "   L = " (rtos (/ (- (nth 4 r) (nth 3 r)) fac) 2 1) " m"
                          "\\P"
                          (if (= (nth 6 r) 1)
                            (strcat "CURVE TAPER (REVERSE CURVE)  R "
                                    (rtos (/ (/ (+ (* (- (nth 4 r) (nth 3 r)) (- (nth 4 r) (nth 3 r)))
                                                   (* (nth 5 r) (nth 5 r)))
                                                (* 4.0 (abs (nth 5 r))))
                                             fac) 2 1) " m")
                            (strcat "STRAIGHT TAPER 1:" (rtos (/ (- (nth 4 r) (nth 3 r)) (abs (nth 5 r))) 2 1)
                                    (if (> (nth 7 r) 0.0)
                                      (strcat "  -  FILLET R=" (rtos (/ (nth 7 r) fac) 2 1) " m")
                                      "  -  DIRECT LINK")))
                          "\\PROAD WIDTH " (nth 8 r) " m  >  " (nth 9 r) " m")))
      (vla-put-Height mt (* 0.8 th))
      (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
      (vla-put-InsertionPoint mt (rp:p3 ip elev))
      (vla-put-Rotation mt rot)
      (vla-put-Layer mt "ROAD-WIDENING")))
  ;; 7. draw order and bookkeeping
  (setq new (rp:since mark))
  (foreach en new
    (setq ty (cdr (assoc 0 (entget en))) ly (cdr (assoc 8 (entget en))))
    (cond ((= ty "WIPEOUT") (setq wl (cons en wl)))
          ((and (= ty "HATCH") (= ly "ROAD-SURFACE")) (setq sh (cons en sh)))
          ((= ty "HATCH") (setq bh (cons en bh)))
          (T (setq oth (cons en oth)))))
  (if wl  (rp:order-ss (reverse wl) "_F"))
  (if bh  (rp:order-ss (reverse bh) "_F"))
  (if oth (rp:order-ss (reverse oth) "_F"))
  (if sh  (rp:order-ss (reverse sh) "_B"))
  (vlax-ldata-put cl (strcat "ROADPRO_TMAN_" sd)
                  (mapcar '(lambda (x) (cdr (assoc 5 (entget x)))) new))
  (list (- (car add) nr) (- (cadr add) nw) addA cutA))

;; Taper values for one side : (a b d)
;; the right side uses its own fields when Both sides + different chainage
(defun rp:tside-par (sg fac st0 / sx)
  (setq sx (if (and (< sg 0) (= (rp:val "tside") "2") (= (rp:val "tdiff") "1")) "2" ""))
  (list (* fac (- (rp:num (strcat "tst" sx)) st0))
        (* fac (- (rp:num (strcat "ten" sx)) st0))
        (* fac (rp:num (strcat "tshift" sx)))
        (* fac (rp:num (strcat "trad" sx)))))

;; Road width (both sides) at station x for a list of taper records
(defun rp:twidth (recs x hw fac)
  (+ (rp:soff (rp:taper-profs recs 1.0 fac) hw x) (rp:soff (rp:taper-profs recs -1.0 fac) hw x)))

(defun rp:taper-run (e / data fac obj len st0 hw bgap bwid blen elev th curve rf0 rf pr a b d
                       hyp dl rfmax old n id sides newrecs all bad bads s profs bl br res sd)
  (setq data (rp:xget e)
        *rp:etype* (rp:etype data)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        elev     (vla-get-Elevation obj)
        st0      (atof (rp:xv "CHST" data))
        hw       (* 0.5 fac (atof (rp:xv "W" data)))
        bgap     (* fac (atof (rp:xv "BGAP" data)))
        bwid     (* fac (atof (rp:xv "BWID" data)))
        blen     (* fac (atof (rp:xv "BLEN" data)))
        th       (* fac (rp:num "txth"))
        curve    (= (rp:val "ttype") "1")
        rf0      (and (not curve) (= (rp:val "tmatch") "0"))
        sides    (cond ((= (rp:val "tside") "0") '(1.0))
                       ((= (rp:val "tside") "1") '(-1.0))
                       (T '(1.0 -1.0)))
        *rp:hatches* nil)
  (if (<= blen 0.0) (setq blen (* 2.0 fac)))
  ;; check every side before drawing anything
  (foreach sg sides
    (setq pr (rp:tside-par sg fac st0))
    (if (and (not bads)
             (or (< (car pr) -1e-6) (> (cadr pr) (+ len 1e-6)) (< (abs (caddr pr)) 1e-9)))
      (setq bads (list sg pr))))
  (cond
    ((vlax-curve-isClosed obj)
     (alert "Road tapers are not available on closed (loop) roads."))
    (bads
     (alert (strcat "The " (if (> (car bads) 0) "LEFT" "RIGHT") " side taper is not valid.\n\n"
                    "Road : " (rp:chfmt st0) " to " (rp:chfmt (+ st0 (/ len fac))) "\n"
                    "Taper : " (rp:chfmt (+ st0 (/ (car (cadr bads)) fac))) " to "
                    (rp:chfmt (+ st0 (/ (cadr (cadr bads)) fac)))
                    "\n\nThe taper must lie inside the road and the edge shift cannot be zero.")))
    (T
     (setq old (vlax-ldata-get obj "ROADPRO_TAPERS")
           n   (1+ (if (vlax-ldata-get obj "ROADPRO_TCOUNT") (vlax-ldata-get obj "ROADPRO_TCOUNT") 0))
           id  (strcat "T" (itoa n)))
     (foreach sg sides
       (setq pr (rp:tside-par sg fac st0)
             a  (car pr) b (cadr pr) d (caddr pr)
             rf (if rf0 (cadddr pr) 0.0))
       ;; keep the fillets inside the taper and the road
       (if (> rf 0.0)
         (progn
           (setq hyp   (sqrt (+ (* (- b a) (- b a)) (* d d)))
                 dl    (atan (abs d) (- b a))
                 rfmax (/ (min (* 0.5 hyp) (max (* 0.01 fac) a) (max (* 0.01 fac) (- len b)))
                          (/ (sin (* 0.5 dl)) (cos (* 0.5 dl)))))
           (if (> rf rfmax)
             (progn
               (princ (strcat "\nFillet radius reduced to " (rtos (/ rfmax fac) 2 1) " m on the "
                              (if (> sg 0) "left" "right") " side so it fits inside the taper."))
               (setq rf rfmax)))))
       (setq newrecs (cons (list (strcat id "-" (if (> sg 0) "L" "R")) (if (> sg 0) "Left" "Right")
                                 sg a b d (if curve 1 0) rf)
                           newrecs)))
     (setq newrecs (reverse newrecs)
           all     (append old newrecs))
     ;; the edge must stay clear of the centre line
     (foreach sg sides
       (setq profs (rp:taper-profs all sg fac) s 0.0)
       (while (and (not bad) (<= s len))
         (if (< (rp:soff profs hw s) (* 0.3 fac)) (setq bad s))
         (setq s (+ s fac))))
     (if bad
       (alert (strcat "The road edge would reach the centre line near CH "
                      (rp:chfmt (+ st0 (/ bad fac))) ".\n\nUse a smaller narrowing."))
       (progn
         (setq newrecs (mapcar '(lambda (r)
                                  (append r (list (rtos (/ (rp:twidth all (max 0.0 (- (nth 3 r) fac)) hw fac) fac) 2 2)
                                                  (rtos (/ (rp:twidth all (min len (+ (nth 4 r) fac)) hw fac) fac) 2 2))))
                               newrecs)
               all     (append old newrecs))
         (vlax-ldata-put obj "ROADPRO_TAPERS" all)
         (vlax-ldata-put obj "ROADPRO_TCOUNT" n)
         (setq bl (rp:pairget (rp:xv "BL" data))
               br (rp:pairget (rp:xv "BR" data)))
         (foreach sg sides
           (setq sd  (if (> sg 0) "L" "R")
                 res (rp:taper-rebuild obj sg hw fac len elev blen bgap bwid
                                       (and (rp:on "tbar") (rp:edge-on data sg))
                                       (rp:on "tlab") st0 th all))
           (vlax-ldata-put obj (strcat "ROADPRO_TAREA_" sd) (list (caddr res) (cadddr res)))
           (if (> sg 0)
             (setq bl (list (+ (car bl) (car res)) (+ (cadr bl) (cadr res))))
             (setq br (list (+ (car br) (car res)) (+ (cadr br) (cadr res))))))
         (setq data (vl-remove-if '(lambda (x) (member (car x) '("BL" "BR"))) data))
         (rp:xput e (append data (list (cons "BL" (rp:pair bl)) (cons "BR" (rp:pair br)))))
         (rp:refresh e)
         (foreach r newrecs
           (princ (strcat "\n  Road taper " (car r) " (" (cadr r) ") : CH "
                          (rp:chfmt (+ st0 (/ (nth 3 r) fac))) " - " (rp:chfmt (+ st0 (/ (nth 4 r) fac)))
                          ",  edge " (if (> (nth 5 r) 0) "+" "") (rtos (/ (nth 5 r) fac) 2 2)
                          " m,  road width " (nth 8 r) " m > " (nth 9 r) " m")))
         (princ "\n  Run RDR for the updated report.")))))
  (princ))

;; Report rows for tapers : (rows setting-out-rows net-area) or nil
(defun rp:taper-report (obj fac hw st0 iv len / recs rows sto sg profs p s0 s1 s kp o pp ar addT cutT)
  (setq recs (vlax-ldata-get obj "ROADPRO_TAPERS"))
  (if recs
    (progn
      (setq rows (list '("#" "ROAD TAPERS")))
      (foreach r recs
        (setq rows (append rows
                     (list (list (strcat (car r) " - " (cadr r) " side")
                                 (strcat "edge " (if (> (nth 5 r) 0) "+" "") (rtos (/ (nth 5 r) fac) 2 2)
                                         " m,  CH " (rp:chfmt (+ st0 (/ (nth 3 r) fac))) " - "
                                         (rp:chfmt (+ st0 (/ (nth 4 r) fac)))))
                           (list (strcat "   " (car r) " taper / match")
                                 (strcat (if (= (nth 6 r) 1) "Curve (reverse curve)" "Straight") ",  "
                                         (if (= (nth 6 r) 1) "tangent"
                                           (if (> (nth 7 r) 0.0)
                                             (strcat "fillet R " (rtos (/ (nth 7 r) fac) 2 1) " m")
                                             "direct link"))))
                           (list (strcat "   " (car r) " road width") (strcat (nth 8 r) " m  >  " (nth 9 r) " m"))))))
      (foreach r recs
        (setq sg    (nth 2 r)
              profs (rp:taper-profs recs sg fac)
              p     (rp:tprofile (nth 3 r) (nth 4 r) (nth 5 r) (= (nth 6 r) 1) (nth 7 r) fac)
              s0    (car (car p))
              s1    (car (last p))
              kp    (list (list s0 "TS") (list s1 "TE")))
        (if (> iv 0.0)
          (progn
            (setq s (- (* iv (fix (+ 1.0 (/ (+ s0 (* st0 fac)) iv)))) (* st0 fac)))
            (while (< s s1)
              (if (> s s0) (setq kp (cons (list s "CH") kp)))
              (setq s (+ s iv)))))
        (foreach q (vl-sort kp '(lambda (a b) (< (car a) (car b))))
          (setq o   (rp:soff profs hw (car q))
                pp  (rp:offpt obj (car q) (* sg o))
                sto (cons (list (car r) (cadr q) (rp:chfmt (+ st0 (/ (car q) fac)))
                                (rtos (/ (* sg o) fac) 2 3)
                                (rtos (/ (car pp) fac) 2 3) (rtos (/ (cadr pp) fac) 2 3))
                          sto))))
      (setq addT 0.0 cutT 0.0)
      (foreach sd '("L" "R")
        (if (setq ar (vlax-ldata-get obj (strcat "ROADPRO_TAREA_" sd)))
          (setq addT (+ addT (car ar)) cutT (+ cutT (cadr ar)))))
      (setq rows (append rows
                   (list (list "Taper area added / removed"
                               (strcat (rtos (/ addT fac fac) 2 2) " / " (rtos (/ cutT fac fac) 2 2) " m2"))
                         (list "Road width at road end"
                               (strcat (rtos (/ (+ (rp:soff (rp:taper-profs recs 1.0 fac) hw len)
                                                   (rp:soff (rp:taper-profs recs -1.0 fac) hw len))
                                                fac) 2 3) " m")))))
      (list rows (reverse sto) (/ (- addT cutT) fac fac)))))

;;----------------------------------------------------------------------------
;;  ROAD JUNCTION / TIE-IN
;;  Join a new (branch) road to an existing RoadPro road. The branch is built
;;  with the normal RoadPro settings, then the junction is formed:
;;    - main road edge opened between the kerb returns
;;    - kerb-return arcs (corner radius) left and right, radius marked
;;    - corner and mouth surface, barricades cleared from the mouth and
;;      placed around the corners, STOP / GIVE WAY on the branch
;;    - junction label and setting-out (TC / IP / CT of each corner)
;;----------------------------------------------------------------------------
(setq *rp:jdcl*
 (list
  "roadjunc : dialog {"
  "  label = \"ROAD PRO  -  Road Junction / Tie-in\";"
  "  : text { key = \"info\"; width = 62; }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Joining road (branch)\";"
  "      : edit_box   { key = \"jname\"; label = \"Branch road name / ID:\"; edit_width = 14; }"
  "      : edit_box   { key = \"jwid\";  label = \"Branch road width (m):\"; edit_width = 8; }"
  "      : popup_list { key = \"jmode\"; label = \"Branch centre line:\";    edit_width = 28; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Junction\";"
  "      : edit_box   { key = \"jrad\"; label = \"Corner (kerb return) radius (m):\"; edit_width = 8; }"
  "      : popup_list { key = \"jctl\"; label = \"Control on the branch:\";           edit_width = 18; }"
  "      : toggle     { key = \"jbar\"; label = \"Edge treatment around the corners\"; }"
  "      : popup_list { key = \"jcorner\"; label = \"Corner treatment:\"; edit_width = 22; }"
  "      : toggle     { key = \"jmark\"; label = \"Road markings in the turning area\"; }"
  "    }"
  "  }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Main road auxiliary lane at the junction\";"
  "      : toggle   { key = \"jaux\";   label = \"Add auxiliary lane (two taper lines)\"; }"
  "      : edit_box { key = \"jauxw\";  label = \"Lane width (m):\";              edit_width = 6; }"
  "      : edit_box { key = \"jlong\";  label = \"Approach taper, long (m):\";    edit_width = 6; }"
  "      : edit_box { key = \"jshort\"; label = \"Departure taper, short (m):\";  edit_width = 6; }"
  "      : edit_box { key = \"jstore\"; label = \"Storage length (m):\";          edit_width = 6; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Island on the branch\";"
  "      : popup_list { key = \"jisl\";  label = \"Island:\";           edit_width = 26; }"
  "      : edit_box   { key = \"jislw\"; label = \"Island width (m):\";  edit_width = 6; }"
  "      : edit_box   { key = \"jisll\"; label = \"Island length (m):\"; edit_width = 6; }"
  "    }"
  "  }"
  "  : text { label = \"Start the branch centre line ON the main road centre line and draw outward.\"; }"
  "  : text { label = \"Barricades, signs and chainage of the branch use your RDP settings.\"; }"
  "  spacer;"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:jdlg-modes ()
  (mode_tile "jcorner" (if (= (get_tile "jbar") "1") 0 1))
  (foreach k '("jauxw" "jlong" "jshort" "jstore") (mode_tile k (if (= (get_tile "jaux") "1") 0 1)))
  (foreach k '("jislw" "jisll") (mode_tile k (if (= (get_tile "jisl") "0") 1 0))))

(defun rp:jdlg-accept (/ bad v)
  (foreach k '(("jwid" "Branch road width") ("jrad" "Corner radius") ("jauxw" "Auxiliary lane width")
               ("jlong" "Long taper") ("jshort" "Short taper") ("jstore" "Storage length")
               ("jislw" "Island width") ("jisll" "Island length"))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (<= v 0.0)) (setq bad k)))))
  (cond
    (bad
     (set_tile "error" (strcat (cadr bad) " must be a number greater than zero."))
     (mode_tile (car bad) 2))
    ((= (vl-string-trim " " (get_tile "jname")) "")
     (set_tile "error" "Enter a name for the branch road.")
     (mode_tile "jname" 2))
    (T
     (foreach k *rp:jkeys* (rp:set k (get_tile k)))
     (done_dialog 1))))

(defun rp:jdialog (info / fn f id res)
  (setq fn (vl-filename-mktemp "roadjunc.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:jdcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadjunc" id))
        (progn
          (rp:fill "jmode" '("Draw new (from main road CL)" "Select existing Line/Pline/Arc"))
          (rp:fill "jctl"  '("STOP sign" "GIVE WAY sign" "No sign"))
          (rp:fill "jisl"  '("No island" "Splitter island - kerbed" "Splitter island - painted"))
          (rp:fill "jcorner" '("Same as main road" "Barricades (red / white)" "Traffic cones" "Kerb stone"))
          (foreach k *rp:jkeys* (set_tile k (rp:val k)))
          (set_tile "info" info)
          (rp:jdlg-modes)
          (foreach k '("jaux" "jisl" "jbar") (action_tile k "(rp:jdlg-modes)"))
          (action_tile "accept" "(rp:jdlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; ---- geometry helpers ----
(defun rp:p2 (p) (list (car p) (cadr p)))

(defun rp:inters (o1 o2 mode / v sa l out)
  (setq v (vl-catch-all-apply 'vla-IntersectWith (list o1 o2 mode)))
  (if (not (vl-catch-all-error-p v))
    (progn
      (setq sa (vlax-variant-value v))
      (if (and (= (type sa) 'SAFEARRAY) (>= (vlax-safearray-get-u-bound sa 1) 0))
        (progn
          (setq l (vlax-safearray->list sa))
          (while l (setq out (cons (list (car l) (cadr l) (caddr l)) out) l (cdddr l)))))))
  (reverse out))

(defun rp:nearest (pts p / best bd d)
  (setq bd 1e99)
  (foreach q pts (if (< (setq d (distance (rp:p2 q) (rp:p2 p))) bd) (setq best q bd d)))
  best)

(defun rp:cpt (obj p / z)
  (setq z (caddr (vlax-curve-getStartPoint obj)))
  (vlax-curve-getClosestPointTo obj (list (car p) (cadr p) z)))

;; signed lateral offset of point c from a curve (+ = left of its direction)
(defun rp:lat (obj c / cp dv)
  (setq cp (rp:cpt obj c)
        dv (vlax-curve-getFirstDeriv obj (vlax-curve-getParamAtPoint obj cp)))
  (- (* (car dv) (- (cadr c) (cadr cp))) (* (cadr dv) (- (car c) (car cp)))))

(defun rp:unitv (v / l) (setq l (distance '(0.0 0.0) (rp:p2 v))) (if (< l 1e-12) '(1.0 0.0) (list (/ (car v) l) (/ (cadr v) l))))

(defun rp:edge-near (p fac excl / ss i e d best bd)
  (setq ss (ssget "_X" '((0 . "LWPOLYLINE") (8 . "ROAD-EDGE"))) i 0 bd 1e99)
  (if ss
    (repeat (sslength ss)
      (setq e (ssname ss i) i (1+ i))
      (if (not (member e excl))
        (progn
          (setq d (distance (rp:p2 (rp:cpt e p)) (rp:p2 p)))
          (if (< d bd) (setq best e bd d))))))
  (if (and best (< bd (* 5.0 fac))) best))

;; Remove barricade units beside a road : side sg, true lateral distance between
;; lo and hi, centre station between sA and sB. Returns (red white)
(defun rp:jbar-band (obj sg lo hi sA sB / ss i e o mn mx c cp d lat nr nw nc nk lay)
  (setq nr 0 nw 0 nc 0 nk 0
        ss (ssget "_X" '((8 . "ROAD-BARRIER-RED,ROAD-BARRIER-WHITE,ROAD-BARRIER-OUTLINE,ROAD-CONE,ROAD-CONE-BAND,ROAD-KERB")))
        i  0)
  (if ss
    (repeat (sslength ss)
      (setq e (ssname ss i) i (1+ i))
      (if (entget e)
        (progn
          (setq o (vlax-ename->vla-object e))
          (vla-GetBoundingBox o 'mn 'mx)
          (setq mn  (vlax-safearray->list mn)
                mx  (vlax-safearray->list mx)
                c   (list (* 0.5 (+ (car mn) (car mx))) (* 0.5 (+ (cadr mn) (cadr mx))))
                cp  (rp:cpt obj c)
                d   (vlax-curve-getDistAtPoint obj cp)
                lat (* (if (> (rp:lat obj c) 0.0) 1.0 -1.0) (distance c (rp:p2 cp))))
          (if (and d (>= d sA) (<= d sB) (> (* sg lat) lo) (< (* sg lat) hi))
            (progn
              (setq lay (vla-get-Layer o))
              (if (= (vla-get-ObjectName o) "AcDbHatch")
                (cond ((= lay "ROAD-BARRIER-RED") (setq nr (1+ nr)))
                      ((= lay "ROAD-BARRIER-WHITE") (setq nw (1+ nw)))
                      ((= lay "ROAD-CONE") (setq nc (1+ nc)))
                      ((= lay "ROAD-KERB") (setq nk (1+ nk)))))
              (vla-Delete o)))))))
  (list nr nw nc nk))

;; Remove barricade units near the junction; counts per owner road and side
(defun rp:jbar-remove (pts rad mobj bobj / ss i e o mn mx c hit lay own key cnt a)
  (setq cnt (list (list "ML" 0 0) (list "MR" 0 0) (list "BL" 0 0) (list "BR" 0 0))
        ss  (ssget "_X" '((8 . "ROAD-BARRIER-RED,ROAD-BARRIER-WHITE,ROAD-BARRIER-OUTLINE,ROAD-CONE,ROAD-CONE-BAND,ROAD-KERB")))
        i   0)
  (if ss
    (repeat (sslength ss)
      (setq e (ssname ss i) o (vlax-ename->vla-object e) i (1+ i) hit nil)
      (vla-GetBoundingBox o 'mn 'mx)
      (setq mn (vlax-safearray->list mn) mx (vlax-safearray->list mx)
            c  (list (* 0.5 (+ (car mn) (car mx))) (* 0.5 (+ (cadr mn) (cadr mx)))))
      (foreach q pts (if (and (not hit) (< (distance c (rp:p2 q)) rad)) (setq hit T)))
      (if hit
        (progn
          (setq lay (vla-get-Layer o))
          (if (/= lay "ROAD-BARRIER-OUTLINE")
            (progn
              (setq own (if (< (distance c (rp:p2 (rp:cpt mobj c))) (distance c (rp:p2 (rp:cpt bobj c)))) mobj bobj)
                    key (strcat (if (eq own mobj) "M" "B") (if (> (rp:lat own c) 0.0) "L" "R"))
                    a   (assoc key cnt))
              (setq cnt (subst (if (= lay "ROAD-BARRIER-RED")
                                 (list key (1+ (cadr a)) (caddr a))
                                 (list key (cadr a) (1+ (caddr a))))
                               a cnt))))
          (vla-Delete o)))))
  cnt)

(defun rp:jsurf (pts elev / bnd h ar)
  (setq bnd (rp:poly pts "ROAD-SURFACE" elev)
        ar  (vla-get-Area bnd))
  (if (> ar 1e-6)
    (progn
      (setq h (rp:newhatch "SOLID" nil elev))
      (vla-put-Layer h "ROAD-SURFACE")
      (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-AppendOuterLoop (list h (rp:objarr (list bnd)))))
        (progn (vla-Delete h) (setq h nil ar 0.0))
        (progn
          (vla-Evaluate h)
          (vl-catch-all-apply 'vla-put-EntityTransparency (list h "50"))))))
  (vla-Delete bnd)
  (list h ar))

;; White road-marking polygon
(defun rp:jmk (pts elev)
  (rp:solidfill (rp:poly pts "ROAD-MARKING" elev) nil "ROAD-MARKING-FILL" elev))

;; Point from a base, x along direction d, y to the left of d
(defun rp:lmap (base d x y)
  (list (+ (car base) (* x (car d)) (* -1.0 y (cadr d)))
        (+ (cadr base) (* x (cadr d)) (* y (car d)))))

;; Radius mark at the middle of a kerb-return arc
(defun rp:jrmark (arc ip rr fac th elev / mid u pt pm tx)
  (setq mid (nth (/ (length arc) 2) arc)
        u   (rp:unitv (list (- (car mid) (car ip)) (- (cadr mid) (cadr ip))))
        pm  (rp:pt+ mid u (* 1.2 fac))
        pt  (rp:pt+ mid u (+ (* 1.2 fac) (* 1.4 th))))
  (rp:mkwpl (list (list pm 0.0 0.0) (list (rp:towards mid pm (* 0.5 th)) (* 0.25 th) 0.0) (list mid 0.0 0.0))
            "ROAD-JUNCTION" elev)
  (setq tx (rp:text (strcat "R=" (rtos (/ rr fac) 2 2)) pt (* 0.8 th) "ROAD-JUNCTION" elev)))

;; Junction rows for the report of the MAIN road : (rows setting-out) or nil
(defun rp:junc-report (obj / recs rows sto)
  (setq recs (vlax-ldata-get obj "ROADPRO_JUNC"))
  (if recs
    (progn
      (setq rows (list '("#" "JUNCTIONS / TIE-INS")))
      (foreach r recs
        (setq rows (append rows
                     (list (list (strcat (car r) " - " (cadr r))
                                 (strcat "at CH " (nth 2 r) " (" (nth 3 r) " side)"))
                           (list (strcat "   " (car r) " angle / corner R")
                                 (strcat (nth 4 r) "  /  R " (nth 5 r) " m"))
                           (list (strcat "   " (car r) " control") (nth 6 r))
                           (if (nth 8 r) (list (strcat "   " (car r) " road markings") (nth 8 r))))))
        (foreach q (nth 7 r) (setq sto (cons q sto))))
      (list rows (reverse sto)))))

(defun rp:junction-run (me / mdata fac mobj mlen st0 hwm bgap bwid blen elev th br bobj bpt dJ fj sg
                          mside medge xs saved res hwb blen2 rr bd e1 e2 corners k be bep ip ub tm
                          oth dl tl arc t1 t2 c ar pts surfs nm bdata bfac bl br2 cnt cntm cntb add
                          ang jid recs rows jct sA sB lbl mid fb rot mt t2d sd ok
                          mbar bbar s1 glo ghi sb st2 bge pg pb path key
                          mkl q1 q2 u12 sl f dv lm tx shp jty jadd jrem jsum
                          hwe waux mh lng sht sto wst wen wtin wtout auxp iv iw il i0 ilo h hl hr pts2 nn d de)
  (setq mdata (rp:xget me)
        *rp:etype* (rp:etype mdata)
        fac   (atof (rp:xv "FAC" mdata)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq mobj (vlax-ename->vla-object me)
        mlen (vlax-curve-getDistAtParam mobj (vlax-curve-getEndParam mobj))
        st0  (atof (rp:xv "CHST" mdata))
        hwm  (* 0.5 fac (atof (rp:xv "W" mdata)))
        bgap (* fac (atof (rp:xv "BGAP" mdata)))
        bwid (* fac (atof (rp:xv "BWID" mdata)))
        blen (* fac (atof (rp:xv "BLEN" mdata)))
        elev (vla-get-Elevation mobj)
        th   (* fac (rp:num "txth"))
        hwb  (* 0.5 fac (rp:num "jwid"))
        rr   (* fac (rp:num "jrad")))
  (if (<= blen 0.0) (setq blen (* 2.0 fac)))
  ;; 1. branch centre line
  (setq saved (rp:val "mode"))
  (rp:set "mode" (rp:val "jmode"))
  (princ "\nBranch centre line : start ON the main road centre line and go outward.")
  (setq br (rp:get-centreline))
  (rp:set "mode" saved)
  (cond
    ((null br) (princ "\nNo branch centre line - junction cancelled."))
    ((eq br me) (alert "The branch cannot be the main road itself."))
    (T
     ;; start of the branch must be the end nearest the main road
     (if (> (distance (rp:p2 (vlax-curve-getStartPoint br)) (rp:p2 (rp:cpt mobj (vlax-curve-getStartPoint br))))
            (distance (rp:p2 (vlax-curve-getEndPoint br)) (rp:p2 (rp:cpt mobj (vlax-curve-getEndPoint br)))))
       (command "_.REVERSE" br ""))
     (setq bobj (vlax-ename->vla-object br)
           bpt  (vlax-curve-getStartPoint br))
     (cond
       ((> (distance (rp:p2 bpt) (rp:p2 (rp:cpt mobj bpt))) (+ hwm (* 2.0 fac)))
        (alert "The branch centre line must start on (or very near) the main road.\n\nJunction cancelled."))
       (T
        ;; 2. which side of the main road, and the junction station
        (setq *rp:len* mlen
              dJ   (vlax-curve-getDistAtPoint mobj (rp:cpt mobj bpt))
              fj   (rp:frame mobj dJ)
              ub   (rp:unitv (vlax-curve-getFirstDeriv br (vlax-curve-getStartParam br)))
              sg   (if (> (+ (* (car ub) (car (cadr fj))) (* (cadr ub) (cadr (cadr fj)))) 0.0) 1.0 -1.0)
              mside (if (> sg 0) "Left" "Right")
              ang  (rp:acos (abs (+ (* (car ub) (car (caddr fj))) (* (cadr ub) (cadr (caddr fj)))))))
        ;; 2b. auxiliary lane on the main road : long taper on the approach side, short on the departure
        (setq hwe hwm waux 0.0 auxp nil
              iv  (* fac (atof (rp:xv "CHINT" mdata))))
        (if (rp:on "jaux")
          (progn
            (setq waux (* fac (rp:num "jauxw"))
                  mh   (+ hwb rr (* 2.0 fac))
                  lng  (* fac (rp:num "jlong"))
                  sht  (* fac (rp:num "jshort"))
                  sto  (* fac (rp:num "jstore")))
            ;; keep right : on the RIGHT side traffic comes from the lower chainage
            (if (< sg 0)
              (setq wst (- dJ mh sto) wen (+ dJ mh) wtin lng wtout sht)
              (setq wst (- dJ mh) wen (+ dJ mh sto) wtin sht wtout lng))
            (if (or (< (- wst wtin) 0.0) (> (+ wen wtout) mlen))
              (progn
                (princ "\nAuxiliary lane skipped : with its tapers it would run outside the main road.")
                (setq waux 0.0))
              (progn
                (setq k (rp:widen-side mobj (strcat "J" (itoa (1+ (length (vlax-ldata-get mobj "ROADPRO_JUNC")))) "-AUX")
                                       sg hwm waux (- wst wtin) wst wen (+ wen wtout) nil
                                       (rp:wrf (* 30.0 fac) waux wst wen (- wst wtin) (+ wen wtout) fac sg)
                                       fac th elev st0 iv
                                       (rp:edge-on mdata sg)
                                       bgap bwid blen (rp:on "twoway")))
                (vlax-ldata-put mobj "ROADPRO_WIDEN" (append (vlax-ldata-get mobj "ROADPRO_WIDEN") (list (car k))))
                (setq key   (if (> sg 0) "BL" "BR")
                      cntm  (rp:pairget (rp:xv key mdata))
                      mdata (append (vl-remove-if '(lambda (x) (= (car x) key)) mdata)
                                    (list (cons key (rp:pair (list (+ (car cntm) (car (cadr k)))
                                                                   (+ (cadr cntm) (cadr (cadr k))))))))
                      surfs (list (caddr k))
                      auxp  (cadddr k)
                      hwe   (+ hwm waux))
                (rp:xput me mdata)
                (setq *rp:len* mlen)))))
        (setq medge (rp:edge-near (list (car (rp:offpt mobj dJ (* sg hwe))) (cadr (rp:offpt mobj dJ (* sg hwe))) elev) fac nil))
        (cond
          ((null medge) (alert "The main road edge was not found at the junction.\n\nJunction cancelled."))
          (T
           ;; 3. cut the branch centre line back to the main road edge
           (setq xs (rp:inters bobj (vlax-ename->vla-object medge) acExtendNone))
           (if xs
             (progn
               (setq k (rp:nearest xs bpt))
               (if (> (distance (rp:p2 k) (rp:p2 bpt)) (* 0.01 fac))
                 (progn
                   (setvar "OSMODE" 0)
                   (rp:break br bpt k)))))
           ;; 4. build the branch with the RDP settings
           (setq saved (mapcar '(lambda (x) (cons x (rp:val x)))
                               '("rname" "width" "endst" "report" "xsec" "chst" "ccarr" "clmode" "cmed" "keep")))
           (rp:set "ccarr" "0")
           (rp:set "clmode" "0")
           (rp:set "cmed" "0")
           (rp:set "keep" "0")
           (rp:set "rname" (rp:val "jname"))
           (rp:set "width" (rp:val "jwid"))
           (rp:set "endst" "3")
           (rp:set "report" "0")
           (rp:set "xsec" "0")
           (rp:set "chst" "0")
           (setq *rp:presetcl* br)
           (setq ok (vl-catch-all-apply 'rp:run nil))
           (setq *rp:presetcl* nil)
           (foreach x saved (rp:set (car x) (cdr x)))
           (cond
             ((or (vl-catch-all-error-p ok) (null (rp:xget br)))
              (alert "The branch road could not be built.\n\nJunction cancelled."))
             (T
              (setq bdata (rp:xget br)
                    *rp:hatches* nil
                    blen2 (vlax-curve-getDistAtParam br (vlax-curve-getEndParam br)))
              ;; 5. branch edges and the corner points IP (edge x main edge)
              (setq *rp:len* blen2
                    e1 (rp:edge-near (append (rp:offpt bobj (* 0.5 fac) hwb) (list elev)) fac (list medge))
                    e2 (rp:edge-near (append (rp:offpt bobj (* 0.5 fac) (- hwb)) (list elev)) fac (list medge)))
              (foreach be (list e1 e2)
                (if be
                  (progn
                    (setq bep (vlax-curve-getStartPoint be)
                          ip  (rp:nearest (rp:inters (vlax-ename->vla-object be) (vlax-ename->vla-object medge)
                                                     acExtendThisEntity)
                                          bep))
                    (if ip (setq corners (cons (list be bep ip) corners))))))
              (setq corners (reverse corners))
              (if (/= (length corners) 2)
                (alert "The kerb returns could not be formed (branch edges do not meet the main road edge).")
                (progn
                  ;; 6. kerb-return arcs
                  (foreach cr corners
                    (setq be  (car cr) bep (cadr cr) ip (caddr cr)
                          oth (caddr (if (eq cr (car corners)) (cadr corners) (car corners)))
                          ub  (rp:unitv (vlax-curve-getFirstDeriv be (vlax-curve-getStartParam be)))
                          tm  (rp:unitv (vlax-curve-getFirstDeriv medge
                                          (vlax-curve-getParamAtPoint medge (rp:cpt medge ip)))))
                    (if (< (+ (* (car tm) (- (car ip) (car oth))) (* (cadr tm) (- (cadr ip) (cadr oth)))) 0.0)
                      (setq tm (list (- (car tm)) (- (cadr tm)))))
                    ;; keep the tangent length inside the branch edge
                    (setq dl (rp:acos (+ (* (- (car tm)) (car ub)) (* (- (cadr tm)) (cadr ub))))
                          tl (* rr (/ (sin (* 0.5 dl)) (cos (* 0.5 dl)))))
                    (setq c rr)
                    (if (> tl (* 0.6 (vlax-curve-getDistAtParam be (vlax-curve-getEndParam be))))
                      (setq c (/ (* 0.6 (vlax-curve-getDistAtParam be (vlax-curve-getEndParam be)))
                                 (/ (sin (* 0.5 dl)) (cos (* 0.5 dl))))))
                    (setq arc (rp:fillet-pts (rp:pt+ (rp:p2 ip) tm (* 4.0 c)) (rp:p2 ip)
                                             (rp:pt+ (rp:p2 ip) ub (* 4.0 c)) c 24))
                    (setq res (cons (list be bep (rp:p2 ip) arc c) res)))
                  (setq res (reverse res))
                  ;; 7. open the main road edge between the two returns
                  (setvar "OSMODE" 0)
                  (setq t1 (rp:cpt medge (append (car (nth 3 (car res))) (list elev)))
                        t2 (rp:cpt medge (append (car (nth 3 (cadr res))) (list elev))))
                  (rp:break medge t1 t2)
                  ;; 8. trim the branch edges back to the end of each return
                  (foreach cr res
                    (setq be (car cr) bep (cadr cr) ip (caddr cr) arc (nth 3 cr)
                          t2d (last arc)
                          ub  (rp:unitv (list (- (car t2d) (car ip)) (- (cadr t2d) (cadr ip)))))
                    (if (> (+ (* (car ub) (- (car t2d) (car bep))) (* (cadr ub) (- (cadr t2d) (cadr bep)))) 0.0)
                      (rp:break be (rp:cpt be bep) (rp:cpt be (append t2d (list elev))))
                      (rp:line t2d (rp:p2 bep) "ROAD-EDGE" elev))
                    ;; the return arc
                    (rp:mkpl (mapcar '(lambda (q) (list q 0.0)) arc) "ROAD-EDGE" elev nil))
                  ;; 9. corner and mouth surface
                  (foreach cr res
                    (setq surfs (cons (car (rp:jsurf (cons (caddr cr) (nth 3 cr)) elev)) surfs)))
                  (setq surfs (cons (car (rp:jsurf (list (caddr (car res)) (caddr (cadr res))
                                                         (rp:p2 (cadr (cadr res))) (rp:p2 (cadr (car res))))
                                                   elev))
                                    surfs))
                  ;; 10. barricades : remove exactly the units that touch the junction
                  ;;     (whole units on the main road and on the branch), then lay ONE
                  ;;     continuous run per corner : main edge > kerb return > branch edge
                  (setq cnt  (list (list "ML" 0 0) (list "MR" 0 0) (list "BL" 0 0) (list "BR" 0 0))
                        add  (list 0 0)
                        mbar (rp:edge-on mdata sg)
                        jty  (if (= (rp:val "jcorner") "0") (rp:etype mdata)
                               (itoa (1- (atoi (rp:val "jcorner")))))
                        *rp:etype* (rp:etype mdata)
                        s1   (mapcar '(lambda (cr) (vlax-curve-getDistAtPoint mobj (rp:cpt mobj (car (nth 3 cr))))) res)
                        glo  (max 0.0 (* blen (fix (/ (apply 'min s1) blen))))
                        ghi  (min mlen (* blen (fix (+ 0.999999 (/ (apply 'max s1) blen))))))
                  (setq jadd (list 0 0.0) jrem nil)
                  (setq k (rp:jbar-band mobj sg hwe (+ hwe bgap bwid (* 0.5 fac)) glo ghi)
                        jrem (list (list "M" (caddr k) (cadddr k)))
                        cnt (subst (cons (if (> sg 0) "ML" "MR") k) (assoc (if (> sg 0) "ML" "MR") cnt) cnt))
                  (foreach cr res
                    (setq arc  (nth 3 cr)
                          sb   (if (> (rp:lat bobj (cadr cr)) 0.0) 1.0 -1.0)
                          bbar (rp:edge-on bdata sb)
                          st2  (vlax-curve-getDistAtPoint bobj (rp:cpt bobj (last arc)))
                          bge  (min blen2 (* blen (fix (+ 0.999999 (/ st2 blen))))))
                    (setq k   (rp:jbar-band bobj sb hwb (+ hwb bgap bwid (* 0.5 fac)) (- blen) bge)
                          key (if (> sb 0) "BL" "BR")
                          jrem (cons (list key (caddr k) (cadddr k)) jrem)
                          cnt (subst (list key (+ (cadr (assoc key cnt)) (car k)) (+ (caddr (assoc key cnt)) (cadr k)))
                                     (assoc key cnt) cnt))
                    (if (rp:on "jbar")
                      (progn
                        ;; path : main edge at the end of the removed units > T1 > arc > T2 > branch edge
                        (setq *rp:len* mlen
                              pg   (if mbar
                                     (rp:offpt mobj (if (< (vlax-curve-getDistAtPoint mobj (rp:cpt mobj (car arc)))
                                                           (* 0.5 (+ glo ghi)))
                                                      glo ghi)
                                               (* sg hwe)))
                              *rp:len* blen2
                              pb   (if bbar (rp:offpt bobj bge (* sb hwb)))
                              path (append (if (and pg (> (distance pg (car arc)) (* 0.05 fac))) (list pg))
                                           arc
                                           (if (and pb (> (distance pb (last arc)) (* 0.05 fac))) (list pb)))
                              path (rp:mkpl (mapcar '(lambda (q) (list q 0.0)) path) "ROAD-JUNCTION" elev nil)
                              *rp:len* (vlax-curve-getDistAtParam path (vlax-curve-getEndParam path))
                              sd   (if (> (rp:lat path (caddr cr)) 0.0) -1.0 1.0)
                              k    (rp:edge-run path *rp:len* (* sd bgap) (* sd (+ bgap bwid)) jty blen fac elev)
                              add  (list (+ (car add) (car k)) (+ (cadr add) (cadr k)))
                              jadd (list (+ (car jadd) (caddr k)) (+ (cadr jadd) (cadddr k))))
                        (vla-Delete path)))
                    (setq *rp:len* blen2))
                  ;; 10a. splitter island on the branch
                  (setq iw 0.0 il 0.0 i0 0.0
                        *rp:len* blen2
                        sl (apply 'max (mapcar '(lambda (cr) (vlax-curve-getDistAtPoint bobj (rp:cpt bobj (last (nth 3 cr))))) res)))
                  (if (and (/= (rp:val "jisl") "0") (< (+ (* 0.3 sl) (* fac (rp:num "jisll"))) (- blen2 (* 5.0 fac))))
                    (progn
                      (setq iw (* fac (rp:num "jislw"))
                            il (* fac (rp:num "jisll"))
                            i0 (max (* 2.0 fac) (* 0.3 sl))
                            nn (max 12 (fix (/ il (* 0.25 fac))))
                            k  0 hl nil hr nil)
                      ;; half width : round nose, parallel middle, tapering tail
                      (repeat (1+ nn)
                        (setq d (* il (/ (float k) nn))
                              h (cond ((< d (* 0.5 iw))
                                       (sqrt (max 0.0 (- (* 0.25 iw iw) (* (- (* 0.5 iw) d) (- (* 0.5 iw) d))))))
                                      ((< d (* 0.6 il)) (* 0.5 iw))
                                      (T (+ (* 0.1 fac) (* (- (* 0.5 iw) (* 0.1 fac)) (/ (- il d) (* 0.4 il))))))
                              hl (cons (rp:offpt bobj (+ i0 d) h) hl)
                              hr (cons (rp:offpt bobj (+ i0 d) (- h)) hr)
                              k  (1+ k)))
                      (setq pts2 (append (reverse hl) hr))
                      (if (= (rp:val "jisl") "1")
                        (progn
                          ;; kerbed island : kerb outline + raised fill
                          (setq h (rp:poly pts2 "ROAD-ISLAND" elev))
                          (vla-put-ConstantWidth h (* 0.15 fac))
                          (rp:solidfill (rp:poly pts2 "ROAD-ISLAND" elev) nil "ROAD-KERB" elev)
                          (setq mkl (cons (strcat "kerbed splitter island " (rtos (/ iw fac) 2 2) " x " (rtos (/ il fac) 2 1) " m") mkl)))
                        (progn
                          ;; painted island : white border + diagonal hatching
                          (setq h (rp:poly pts2 "ROAD-MARKING-FILL" elev))
                          (vla-put-ConstantWidth h (* 0.15 fac))
                          (setq h (rp:newhatch "ANSI31" nil elev))
                          (vla-put-Layer h "ROAD-MARKING-FILL")
                          (setq k (rp:poly pts2 "ROAD-MARKING" elev))
                          (vla-AppendOuterLoop h (rp:objarr (list k)))
                          (vl-catch-all-apply 'vla-put-PatternScale (list h (* 0.35 fac)))
                          (vl-catch-all-apply 'vla-put-PatternAngle
                                              (list h (angle '(0.0 0.0) (caddr (rp:frame bobj (+ i0 (* 0.5 il)))))))
                          (vla-Evaluate h)
                          (vla-Delete k)
                          (setq mkl (cons (strcat "painted splitter island " (rtos (/ iw fac) 2 2) " x " (rtos (/ il fac) 2 1) " m") mkl))))
                      ;; KEEP RIGHT at the tail, facing traffic coming to the junction
                      (if (rp:on "twoway")
                        (rp:icon-keepright (rp:offpt bobj (+ i0 il (* 0.8 (* fac (rp:num "signsz")))) 0.0)
                                           (* 0.8 fac (rp:num "signsz")) elev))
                      (if (< (- hwb (* 0.5 iw)) (* 2.75 fac))
                        (princ "\nNote: lanes beside the island are narrower than 2.75 m - use a wider branch or a narrower island."))))
                  ;; 10b. road markings in the turning area
                  (setq mkl nil)
                  (if (rp:on "jmark")
                    (progn
                      ;; broken edge line across the junction mouth (main road edge continued)
                      (setq q1  (caddr (car res))
                            q2  (caddr (cadr res))
                            u12 (rp:unitv (list (- (car q2) (car q1)) (- (cadr q2) (cadr q1))))
                            k   0.0)
                      (while (< (+ k (* 0.6 fac)) (distance q1 q2))       ; L5/3 : 600 mark / 300 gap
                        (rp:jmk (list (rp:lmap q1 u12 k (* -0.06 fac)) (rp:lmap q1 u12 (+ k (* 0.6 fac)) (* -0.06 fac))
                                      (rp:lmap q1 u12 (+ k (* 0.6 fac)) (* 0.06 fac)) (rp:lmap q1 u12 k (* 0.06 fac)))
                                elev)
                        (setq k (+ k (* 0.9 fac))))
                      (setq mkl (list "broken edge line across the mouth"))
                      ;; approach lane of the branch (two-way : traffic coming to the junction)
                      (setq *rp:len* blen2
                            sl  (+ (apply 'max (mapcar '(lambda (cr) (vlax-curve-getDistAtPoint bobj (rp:cpt bobj (last (nth 3 cr))))) res))
                                   (* 1.0 fac)))
                      (if (and (rp:on "twoway") (< sl (- blen2 (* 20.0 fac))))
                        (progn
                          (setq f  (rp:frame bobj sl)
                                dv (list (- (car (caddr f))) (- (cadr (caddr f))))
                                ilo (+ (* 0.15 fac) (* 0.5 iw))
                                lm (* 0.5 (+ hwb (* 0.5 iw))))
                          (cond
                            ;; STOP : solid stop line + STOP word
                            ((= (rp:val "jctl") "0")
                             (rp:jmk (list (rp:loc f ilo 0.0) (rp:loc f (- hwb (* 0.15 fac)) 0.0)
                                           (rp:loc f (- hwb (* 0.15 fac)) (* 0.3 fac)) (rp:loc f ilo (* 0.3 fac)))
                                     elev)
                             (setq tx (rp:text "STOP" (rp:loc f lm (* 3.1 fac)) (* 1.6 fac) "ROAD-MARKING-FILL" elev))
                             (vl-catch-all-apply 'vla-put-ScaleFactor (list tx 0.4))
                             (vla-put-Rotation tx (- (angle '(0.0 0.0) dv) (* 0.5 pi)))
                             (setq mkl (cons "stop line + STOP word" mkl)))
                            ;; GIVE WAY : broken give-way line + triangle
                            ((= (rp:val "jctl") "1")
                             (foreach u0 (list 0.0 (* 0.4 fac))
                               (setq k ilo)
                               (while (< (+ k (* 0.6 fac)) hwb)
                                 (rp:jmk (list (rp:loc f k u0) (rp:loc f (+ k (* 0.6 fac)) u0)
                                               (rp:loc f (+ k (* 0.6 fac)) (+ u0 (* 0.2 fac))) (rp:loc f k (+ u0 (* 0.2 fac))))
                                         elev)
                                 (setq k (+ k (* 0.9 fac)))))
                             (rp:jmk (list (rp:loc f (- lm (* 0.625 fac)) (* 2.7 fac)) (rp:loc f (+ lm (* 0.625 fac)) (* 2.7 fac))
                                           (rp:loc f lm (* 6.45 fac)))
                                     elev)
                             (setq mkl (cons "give-way line + triangle" mkl))))
                          ;; left / right turn arrow 12 m before the line
                          (setq f  (rp:frame bobj (+ sl (* 12.0 fac)))
                                dv (list (- (car (caddr f))) (- (cadr (caddr f))))
                                q1 (rp:loc f lm 0.0))
                          (foreach shp (list '((0.0 -0.15) (2.85 -0.15) (2.85 0.15) (0.0 0.15))
                                             '((2.55 0.0) (2.85 0.0) (2.85 1.0) (3.15 1.0) (2.7 1.6) (2.25 1.0) (2.55 1.0))
                                             '((2.55 0.0) (2.85 0.0) (2.85 -1.0) (3.15 -1.0) (2.7 -1.6) (2.25 -1.0) (2.55 -1.0)))
                            (rp:jmk (mapcar '(lambda (q) (rp:lmap q1 dv (* fac (car q)) (* fac (cadr q)))) shp) elev))
                          (setq mkl (cons "left / right turn arrow" mkl))))))
                  ;; cone / kerb quantities on the main road side (cones counted, kerb in m)
                  (if (member (rp:etype mdata) '("1" "2"))
                    (progn
                      (setq k    (if (> sg 0) "EQL" "EQR")
                            cntb (atof (rp:xv k mdata))
                            cntb (if (= (rp:etype mdata) "1")
                                   (itoa (max 0 (+ (- (fix cntb) (cadr (assoc "M" jrem)))
                                                   (if (= jty "1") (car jadd) 0))))
                                   (rtos (max 0.0 (+ (- cntb (/ (* blen (caddr (assoc "M" jrem))) fac))
                                                     (if (= jty "2") (/ (cadr jadd) fac) 0.0))) 2 1))
                            mdata (append (vl-remove-if '(lambda (x) (= (car x) k)) mdata) (list (cons k cntb))))))
                  (setq jsum (strcat (cond ((= jty "1") (strcat (itoa (car jadd)) " traffic cones"))
                                           ((= jty "2") (strcat (rtos (/ (cadr jadd) fac) 2 1) " m kerb stone"))
                                           (T (strcat (itoa (+ (car add) (cadr add))) " barricade units")))
                                     " around the corners"))
                  ;; barricade counts : main road side and branch sides
                  (setq cntm (rp:pairget (rp:xv (if (> sg 0) "BL" "BR") mdata))
                        k    (assoc (if (> sg 0) "ML" "MR") cnt)
                        cntm (list (+ (- (car cntm) (cadr k)) (car add)) (+ (- (cadr cntm) (caddr k)) (cadr add))))
                  (setq mdata (vl-remove-if '(lambda (x) (= (car x) (if (> sg 0) "BL" "BR"))) mdata))
                  (rp:xput me (append mdata (list (cons (if (> sg 0) "BL" "BR") (rp:pair cntm)))))
                  (foreach sd '("BL" "BR")
                    (setq k    (assoc sd cnt)
                          cntb (rp:pairget (rp:xv sd bdata))
                          bdata (vl-remove-if '(lambda (x) (= (car x) sd)) bdata)
                          bdata (append bdata (list (cons sd (rp:pair (list (max 0 (- (car cntb) (cadr k)))
                                                                             (max 0 (- (cadr cntb) (caddr k))))))))))
                  (rp:xput br bdata)
                  ;; 11. labels : radius marks + junction label
                  (setq *rp:len* blen2
                        recs (vlax-ldata-get mobj "ROADPRO_JUNC")
                        jid  (strcat "J" (itoa (1+ (length recs))))
                        jct  (cond ((= (rp:val "jctl") "0") "STOP") ((= (rp:val "jctl") "1") "GIVE WAY") (T "None")))
                  (foreach cr res (rp:jrmark (nth 3 cr) (caddr cr) (nth 4 cr) fac th elev))
                  (setq mid (min blen2 (+ (* 4.0 rr) (* 3.0 fac)))
                        fb  (rp:frame bobj mid)
                        ang (* 1.0 ang)
                        rot (angle '(0.0 0.0) (caddr fb))
                        rot (if (and (> rot (* 0.5 pi)) (<= rot (* 1.5 pi))) (+ rot pi) rot)
                        mt  (vla-AddMText *rp:spc*
                              (rp:p3 (rp:offpt bobj mid (+ hwb bgap bwid fac (* 3.0 th))) elev) 0.0
                              (strcat "JUNCTION " jid " : " (rp:val "jname") " joins " (rp:xv "NAME" mdata)
                                      "\\PAT CH " (rp:chfmt (+ st0 (/ dJ fac))) " (" mside " side)"
                                      "\\PANGLE " (vl-string-subst "\\U+00B0" "%%d" (rp:dms ang T))
                                      "   CORNER R=" (rtos (/ rr fac) 2 2) " m"
                                      "\\PCONTROL : " jct)))
                  (vla-put-Height mt (* 0.8 th))
                  (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
                  (vla-put-InsertionPoint mt (rp:p3 (rp:offpt bobj mid (+ hwb bgap bwid fac (* 3.0 th))) elev))
                  (vla-put-Rotation mt rot)
                  (vla-put-Layer mt "ROAD-JUNCTION")
                  ;; 12. setting-out of the kerb returns, stored on the main road
                  (setq *rp:len* mlen sd 0)
                  (foreach cr res
                    (setq sd (1+ sd) arc (nth 3 cr))
                    (foreach q (list (list "TC" (car arc)) (list "IP" (caddr cr)) (list "CT" (last arc)))
                      (setq rows (cons (list (strcat jid "-" (itoa sd)) (car q)
                                             (rp:chfmt (+ st0 (/ (vlax-curve-getDistAtPoint mobj (rp:cpt mobj (cadr q))) fac)))
                                             (rtos (/ (car (cadr q)) fac) 2 3) (rtos (/ (cadr (cadr q)) fac) 2 3))
                                       rows))))
                  (vlax-ldata-put mobj "ROADPRO_JUNC"
                                  (append recs (list (list jid (rp:val "jname") (rp:chfmt (+ st0 (/ dJ fac))) mside
                                                           (rp:dms ang nil) (rtos (/ rr fac) 2 2) jct (reverse rows)
                                                           (if mkl (rp:join (reverse mkl) ", ") "none")))))
                  ;; 13. draw order
                  (if *rp:hatches* (rp:toback *rp:hatches*))
                  (setq surfs (vl-remove nil surfs))
                  (if surfs (rp:toback surfs))
                  (princ (strcat "\n  Junction " jid " : " (rp:val "jname") " joins " (rp:xv "NAME" mdata)
                                 " at CH " (rp:chfmt (+ st0 (/ dJ fac))) ", " mside " side, corner R "
                                 (rtos (/ rr fac) 2 2) " m."))
                  (if (and jsum (rp:on "jbar")) (princ (strcat "\n  Corners : " jsum ".")))
                  ;; 14. road markings : gaps at the junction, then redraw if the roads have markings
                  (setq *rp:len* mlen
                        k    (vlax-ldata-get mobj "ROADPRO_MKGAP"))
                  (vlax-ldata-put mobj "ROADPRO_MKGAP"
                                  (append (list (list "M" sg (apply 'min s1) (apply 'max s1)))
                                          (if auxp (list (list "E" sg (car (car auxp)) (car (last auxp)))
                                                         (list "W" sg auxp)
                                                         (list "A" sg wst wen)))
                                          k))
                  (setq k nil sd 0.0)
                  (foreach cr res
                    (setq sb  (if (> (rp:lat bobj (cadr cr)) 0.0) 1.0 -1.0)
                          st2 (vlax-curve-getDistAtPoint bobj (rp:cpt bobj (last (nth 3 cr))))
                          sd  (max sd st2)
                          k   (cons (list "E" sb 0.0 st2) k)))
                  (vlax-ldata-put bobj "ROADPRO_MKGAP"
                                  (append (list (list "S" 1.0 0.0 (+ sd (* 30.0 fac))))
                                          (if (> iw 0.0) (list (list "C" 0.0 (- i0 (* 2.0 fac)) (+ i0 il (* 2.0 fac)))))
                                          k
                                          (mapcar '(lambda (g) (list "K" (cadr g) 0.0 (nth 3 g))) k)))
                  (if (vlax-ldata-get mobj "ROADPRO_MKMAN") (rp:mark-run me))
                  (if (vlax-ldata-get bobj "ROADPRO_MKMAN") (rp:mark-run br))
                  (rp:refresh-corr me)
                  (rp:refresh-corr br)
                  (rp:track me *rp:mk0*)
                  (princ "\n  Run RDR on either road for the updated report.")))))))))))
  (princ))

;;----------------------------------------------------------------------------
;;  ROAD MARKINGS
;;  White 150 mm lines : edge lines 0.30 m inside each edge (they follow road
;;  tapers), lane line on the centre line - broken 3 m / 6 m, solid on bends
;;  (10 m before and after) and on junction approaches. No lane line with a
;;  centre median. Gaps where junctions open the edge. Every run replaces the
;;  previous markings of that road and stores the paint quantities.
;;----------------------------------------------------------------------------
;; White strip between stations a and b; edge = T follows the edge (side sg)
;; Marking strip between stations a and b on side sg.
;; edge = T : 150 mm line ending "lo" inside the (tapered) edge; else between lo and hi
(defun rp:mk-strip (obj a b sg profs hw fac elev edge fl lo hi / s0 s1 n i d o1 o2 pa pb)
  (setq s0 a)
  (while (< s0 (- b 1e-6))
    (setq s1 (min b (+ s0 (* 50.0 fac)))
          n  (max 1 (fix (+ 0.999999 (/ (- s1 s0) fac))))
          i  0 pa nil pb nil)
    (repeat (1+ n)
      (setq d (+ s0 (* (- s1 s0) (/ (float i) n))))
      (if edge
        (setq o2 (- (rp:soff profs hw d) lo) o1 (- o2 (if *rp:ew* *rp:ew* (* 0.15 fac))))
        (setq o1 lo o2 hi))
      (setq pa (cons (rp:offpt obj d (* sg o1)) pa)
            pb (cons (rp:offpt obj d (* sg o2)) pb)
            i  (1+ i)))
    (rp:solidfill (rp:poly (append (reverse pa) pb) "ROAD-MARKING" elev) nil fl elev)
    (setq s0 s1)))

;; [a b] minus a list of (lo hi) gaps -> list of (a b) pieces
(defun rp:mk-ranges (a b gaps / out cur g)
  (setq cur a)
  (foreach g (vl-sort gaps '(lambda (x y) (< (car x) (car y))))
    (if (> (car g) cur) (setq out (cons (list cur (min b (car g))) out)))
    (setq cur (max cur (cadr g))))
  (if (< cur b) (setq out (cons (list cur b) out)))
  (vl-remove-if '(lambda (r) (< (- (cadr r) (car r)) 1e-6)) (reverse out)))

(defun rp:mk-inside (d ranges / hit)
  (foreach r ranges (if (and (> d (- (car r) 1e-6)) (< d (+ (cadr r) 1e-6))) (setq hit T)))
  hit)

(defun rp:mark-run (e / data fac obj len hw elev ct recs gaps curves en mark new sg rg cgaps
                      qe qc qs sh oth inset two f ang tx d de lm mg cm spdm solid warn pw pl pt ew
                      mo nl nr lw mw lo2 k)
  (setq data (rp:xget e)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        hw       (* 0.5 fac (atof (rp:xv "W" data)))
        elev     (vla-get-Elevation obj)
        ct       (cond ((/= (rp:xv "CTYPE" data) "") (rp:xv "CTYPE" data))
                       ((/= (rp:xv "BC" data) "0,0") "1")
                       (T "0"))
        two      (/= (rp:xv "TWOWAY" data) "0")
        cm       (if (= (rp:xv "CMARK" data) "") (rp:val "cmark") (rp:xv "CMARK" data))
        spdm     (if (> (atof (rp:xv "SPEED" data)) 0.0) (atof (rp:xv "SPEED" data)) 50.0)
        ew       (* fac (if (> spdm 100.0) 0.15 0.12))           ; L4/1 expressway 150, L4/2 others 120 mm
        inset    (if (> (atof (rp:xv "BGAP" data)) 0.0) 0.0 (* 0.3 fac))   ; at the edge when there is a shoulder
        recs     (vlax-ldata-get obj "ROADPRO_TAPERS")
        gaps     (vlax-ldata-get obj "ROADPRO_MKGAP")
        curves   (rp:curves obj)
        mo       (* fac (atof (rp:xv "MO" data)))
        qe 0.0 qc 0.0 qs 0)
  (setq *rp:ew* ew)
  ;; remove the previous markings of this road
  (foreach hd (vlax-ldata-get obj "ROADPRO_MKMAN")
    (if (and (setq en (handent hd)) (entget en)) (entdel en)))
  (setq mark (entlast))
  ;; YELLOW edge lines, both sides, gaps at junction mouths ("M") and auxiliary lanes ("E")
  (foreach sg '(1.0 -1.0)
    (setq mg (mapcar '(lambda (g) (list (nth 2 g) (nth 3 g)))
                     (vl-remove-if-not '(lambda (g) (and (= (car g) "M") (= (cadr g) sg))) gaps)))
    (foreach rg (rp:mk-ranges 0.0 len
                  (append mg (mapcar '(lambda (g) (list (nth 2 g) (nth 3 g)))
                                     (vl-remove-if-not '(lambda (g) (and (= (car g) "E") (= (cadr g) sg))) gaps))))
      (rp:mk-strip obj (car rg) (cadr rg) sg (rp:taper-profs recs sg fac) hw fac elev T
                   "ROAD-MARKING-YELLOW" inset nil)
      (setq qe (+ qe (- (cadr rg) (car rg)))))
    ;; yellow edge line along an auxiliary lane ("W") and broken white lane line beside it ("A")
    (foreach g (vl-remove-if-not '(lambda (g) (and (= (car g) "W") (= (cadr g) sg))) gaps)
      (foreach rg (rp:mk-ranges (car (car (caddr g))) (car (last (caddr g))) mg)
        (rp:mk-strip obj (car rg) (cadr rg) sg (list (caddr g)) hw fac elev T "ROAD-MARKING-YELLOW" inset nil)
        (setq qe (+ qe (- (cadr rg) (car rg))))))
    (foreach g (vl-remove-if-not '(lambda (g) (and (= (car g) "A") (= (cadr g) sg))) gaps)
      (setq d (nth 2 g))
      (while (< d (nth 3 g))
        (setq de (min (nth 3 g) (+ d (* 1.0 fac))))                ; L5 : 1 m mark / 1 m gap
        (if (not (rp:mk-inside (* 0.5 (+ d de)) mg))
          (progn
            (rp:mk-strip obj d de sg nil hw fac elev nil "ROAD-MARKING-FILL" (- hw (* 0.06 fac)) (+ hw (* 0.06 fac)))
            (setq qc (+ qc (- de d)))))
        (setq d (+ d (* 2.0 fac))))))
  ;; WHITE centre line (none under a barricade median, gaps at islands)
  ;;   "0" standard : L1 lane line by speed, L2 warning line (7 marks) before
  ;;       bends and L2A solid through bends and on junction approaches
  ;;   "1" double continuous white   "2" single continuous L2A
  (if (and (/= ct "1") (not (member (rp:xv "MED" data) '("1" "2"))))
    (progn
      (setq cgaps (mapcar '(lambda (g) (list (nth 2 g) (nth 3 g)))
                          (vl-remove-if-not '(lambda (g) (= (car g) "C")) gaps)))
      (cond
        ((= cm "1")
         (foreach rg (rp:mk-ranges 0.0 len cgaps)
           (rp:mk-strip obj (car rg) (cadr rg) 1.0 nil hw fac elev nil "ROAD-MARKING-FILL" (+ mo (* 0.06 fac)) (+ mo (* 0.18 fac)))
           (rp:mk-strip obj (car rg) (cadr rg) -1.0 nil hw fac elev nil "ROAD-MARKING-FILL" (- (* 0.06 fac) mo) (- (* 0.18 fac) mo))
           (setq qc (+ qc (* 2.0 (- (cadr rg) (car rg)))))))
        ((= cm "2")
         (foreach rg (rp:mk-ranges 0.0 len cgaps)
           (rp:mk-strip obj (car rg) (cadr rg) 1.0 nil hw fac elev nil "ROAD-MARKING-FILL" (+ mo (* -0.06 fac)) (+ mo (* 0.06 fac)))
           (setq qc (+ qc (- (cadr rg) (car rg))))))
        (T
         ;; solid L2A parts : bends of 10 deg or more and junction approaches ("S")
         (setq solid nil warn nil
               pw (* fac (+ (car (rp:l2 spdm)) (cadr (rp:l2 spdm))))
               pl (* fac (+ (car (rp:l1 spdm)) (cadr (rp:l1 spdm)))))
         (foreach c curves
           (if (>= (nth 3 c) (/ pi 18.0))
             (setq solid (cons (list (car c) (cadr c)) solid)
                   warn  (cons (list (max 0.0 (- (car c) (* 7.0 pw))) (car c))
                               (cons (list (cadr c) (min len (+ (cadr c) (* 7.0 pw)))) warn)))))
         (foreach g gaps (if (= (car g) "S") (setq solid (cons (list (max 0.0 (nth 2 g)) (min len (nth 3 g))) solid))))
         (setq solid (rp:mk-ranges 0.0 len (append cgaps (rp:mk-ranges 0.0 len solid)))
               solid (rp:mk-ranges 0.0 len (append cgaps (rp:mk-ranges 0.0 len solid))))
         (foreach rg solid
           (rp:mk-strip obj (car rg) (cadr rg) 1.0 nil hw fac elev nil "ROAD-MARKING-FILL" (+ mo (* -0.06 fac)) (+ mo (* 0.06 fac)))
           (setq qc (+ qc (- (cadr rg) (car rg)))))
         ;; broken parts : L2 pattern in the warning zones, L1 elsewhere
         (setq d 0.0)
         (while (< d len)
           (setq pt (if (rp:mk-inside d warn) (rp:l2 spdm) (rp:l1 spdm))
                 de (min len (+ d (* fac (car pt)))))
           (if (and (not (rp:mk-inside d solid)) (not (rp:mk-inside de solid))
                    (not (rp:mk-inside (* 0.5 (+ d de)) cgaps)) (> (- de d) (* 0.5 fac)))
             (progn
               (rp:mk-strip obj d de 1.0 nil hw fac elev nil "ROAD-MARKING-FILL" (+ mo (* -0.06 fac)) (+ mo (* 0.06 fac)))
               (setq qc (+ qc (- de d)))))
           (setq d (+ d (* fac (+ (car pt) (cadr pt))))))))))
  ;; v3.4 : broken lane lines between lanes of the same direction, yellow
  ;; lines along the median
  (setq nl (atoi (rp:xv "NL" data)) nr (atoi (rp:xv "NR" data))
        lw (* fac (atof (rp:xv "LW" data))) mw (* fac (atof (rp:xv "MW" data))))
  (if (and (> nl 0) (> lw 0.0))
    (progn
      (setq lo2 nil k 1)
      (repeat (1- nl) (setq lo2 (cons (+ mo (* 0.5 mw) (* k lw)) lo2) k (1+ k)))
      (setq k 1)
      (repeat (1- nr) (setq lo2 (cons (- mo (* 0.5 mw) (* k lw)) lo2) k (1+ k)))
      (foreach o lo2 (setq qc (+ qc (rp:mk-broken obj len o spdm fac elev))))))
  (if (and (member (rp:xv "MED" data) '("1" "2")) (> mw 0.0))
    (foreach o (list (+ mo (* 0.5 mw) (* 0.3 fac)) (- mo (* 0.5 mw) (* 0.3 fac)))
      (rp:mk-strip obj 0.0 len 1.0 nil hw fac elev nil "ROAD-MARKING-YELLOW" (- o (* 0.5 ew)) (+ o (* 0.5 ew)))
      (setq qe (+ qe len))))
  ;; SLOW before every bend of 10 deg or more, in each approach lane
  (if (rp:on "slow")
    (foreach c curves
      (if (>= (nth 3 c) (/ pi 18.0))
        (foreach dr (if two '(1 -1) '(1))
          (setq d  (if (= dr 1) (- (car c) (* 25.0 fac)) (+ (cadr c) (* 25.0 fac)))
                lm (* 0.5 hw (if (= dr 1) -1.0 1.0)))
          (if (and (> d (* 2.0 fac)) (< d (- len (* 2.0 fac))))
            (progn
              (setq f   (rp:frame obj d)
                    ang (angle '(0.0 0.0) (caddr f))
                    ang (if (= dr 1) ang (+ ang pi))
                    tx  (rp:text "SLOW" (rp:loc f lm 0.0) (* 1.6 fac) "ROAD-MARKING-FILL" elev))
              (vl-catch-all-apply 'vla-put-ScaleFactor (list tx 0.4))
              (vla-put-Rotation tx (- ang (* 0.5 pi)))
              (setq qs (1+ qs))))))))
  ;; bookkeeping and draw order : markings above the surface, below all lines
  (setq new (rp:since mark))
  (vlax-ldata-put obj "ROADPRO_MKMAN" (mapcar '(lambda (x) (cdr (assoc 5 (entget x)))) new))
  (vlax-ldata-put obj "ROADPRO_MKQTY" (list qe qc qs))
  (foreach x new
    (if (= (cdr (assoc 0 (entget x))) "HATCH") (setq sh (cons x sh)) (setq oth (cons x oth))))
  (if sh (rp:order-ss (reverse sh) "_B"))
  (if oth (rp:order-ss (reverse oth) "_B"))
  (setq sh (ssget "_X" '((0 . "HATCH") (8 . "ROAD-SURFACE,ROAD-SHOULDER"))))
  (if sh (command "_.DRAWORDER" sh "" "_B"))
  (princ (strcat "\n  Road markings : yellow edge lines " (rtos (/ qe fac) 2 1) " m, white centre lines "
                 (rtos (/ qc fac) 2 1) " m, SLOW x " (itoa qs) "."))
  (princ))

;;============================================================================
;;  v3.4  CORRIDOR
;;  Lanes (by road width / manual / automatic), single or dual carriageway,
;;  median (flush painted or raised kerbed), sidewalks left / right, walkways,
;;  drainage provision, utility corridor provision, interlocking paver hatch.
;;  Everything is stored on the centre line and can be regenerated (RDU),
;;  edited (RDC) or rebuilt after a radius change (RDER / RDB).
;;  Drainage and utilities are GEOMETRIC PROVISIONS ONLY (no hydraulic or
;;  utility design).  Lane counts from the automatic mode are INDICATIVE.
;;============================================================================
(setq *rp:cdefaults*
  '(("ccarr" . "0")    ("clmode" . "0")   ("clanl" . "1")    ("clanr" . "1")
    ("clw" . "3.65")   ("cvol" . "0")     ("ccap" . "1800")
    ("cmed" . "0")     ("cmedw" . "3.00")
    ("cswl" . "0")     ("cswr" . "0")     ("cswlw" . "2.00") ("cswrw" . "2.00") ("cswo" . "0.00")
    ("cwkl" . "0")     ("cwkr" . "0")     ("cwkw" . "2.50")  ("cwko" . "1.00")
    ("cdrl" . "0")     ("cdrr" . "0")     ("cdrt" . "0")     ("cdrw" . "1.00")  ("cdrd" . "0.60") ("cdro" . "0.50")
    ("cutl" . "0")     ("cutr" . "0")     ("cutw" . "2.00")  ("cuto" . "0.50")
    ("cpav" . "1")     ("cpat" . "0")     ("cpatn" . "AR-B816") ("cpsc" . "1.0") ("cpang" . "0")))
(setq *rp:ckeys*    (mapcar 'car *rp:cdefaults*)
      *rp:defaults* (append *rp:defaults* *rp:cdefaults* '(("keep" . "1")))
      *rp:keys*     (append *rp:keys* '("keep")))

;; Interlocking paver (I-shape / dog-bone) 200 x 165 mm, defined in metres.
;; Lattice (0.20, 0) and (0.10, 0.1155); verified against the true tiling.
(setq *rp:paver-pat*
  '("*RP_PAVER, RoadPro interlocking paver (I-shape) 200 x 165 mm - 1 unit = 1 m"
    "0, -0.05, 0, 0.1, 0.1155, 0.1, -0.1"
    "0, 0.05, 0.0495, 0.1, 0.1155, 0.1, -0.1"
    "90, 0, 0, 0.1155, 0.1, 0.165, -0.066"
    "90, 0.05, 0, 0, 0.1, 0.0495, -0.066"))

;; ---- settings access : road snapshot (*rp:cset*) or overrides (*rp:cov*) first
(defun rp:cv (k / a)
  (cond ((and *rp:cov* (setq a (assoc k *rp:cov*))) (cdr a))
        ((and *rp:cset* (setq a (assoc k *rp:cset*))) (cdr a))
        (T (rp:val k))))
(defun rp:cn (k / v) (if (setq v (rp:dist (rp:cv k))) v (rp:dist (cdr (assoc k *rp:defaults*)))))
(defun rp:con (k) (= (rp:cv k) "1"))
(defun rp:int-p (v) (and v (< (abs (- v (fix (+ v (if (< v 0) -0.5 0.5))))) 1e-9)))

;; Settings snapshot of every RoadPro key (stored on the road)
(defun rp:snapshot () (mapcar '(lambda (k) (cons k (rp:val k))) (mapcar 'car *rp:defaults*)))

;; Run function fn (no arguments) with the settings of alist s, restore afterwards
(defun rp:with-settings (s fn / old r)
  (setq old (mapcar '(lambda (p) (cons (car p) (getenv (strcat "RoadPro_" (car p))))) s))
  (foreach p s (rp:set (car p) (cdr p)))
  (setq r (vl-catch-all-apply fn nil))
  (foreach p old (setenv (strcat "RoadPro_" (car p)) (if (cdr p) (cdr p) "")))
  r)

;;----------------------------------------------------------------------------
;;  Lane plan.  width = RDP road width (m).  Returns
;;   (W nl nr lw mw mo msgs)  W edge-to-edge width, nl / nr lanes left / right
;;   (0 = lane lines not drawn), lw lane width, mw median / separator width,
;;   mo offset of the median or direction line from the CL (+ = left), all m.
;;  Traffic keeps right : the RIGHT side carries traffic towards increasing
;;  chainage, the LEFT side the opposite direction.
;;----------------------------------------------------------------------------
(defun rp:lane-plan (width / carr lm med lw vol cap ct mw nmin n per nl nr ww mo msgs)
  (setq carr (rp:cv "ccarr") lm (rp:cv "clmode") med (rp:cv "cmed") ct (rp:cv "ctype")
        lw   (rp:cn "clw")   vol (rp:cn "cvol")  cap (rp:cn "ccap")
        mw   (cond ((/= med "0") (rp:cn "cmedw"))
                   ((and (= carr "1") (member ct '("1" "2"))) (rp:cn "bwid"))
                   (T 0.0))
        nmin (if (= carr "1") 2 1))
  (cond
    ((= lm "1")
     (setq nl (fix (+ 0.5 (rp:cn "clanl"))) nr (fix (+ 0.5 (rp:cn "clanr")))
           ww (+ (* (+ nl nr) lw) mw)
           msgs (list (strcat "Manual lanes: " (itoa nl) " left + " (itoa nr) " right x "
                              (rtos lw 2 2) " m" (if (> mw 0.0) (strcat " + median " (rtos mw 2 2) " m") "")
                              " = road width " (rtos ww 2 2) " m"))))
    ((= lm "2")
     (if (and vol (> vol 0.0) cap (> cap 0.0))
       (setq n    (max nmin (fix (+ 0.999999 (/ vol cap))))
             msgs (list (strcat "Automatic lanes: design volume " (rtos vol 2 0) " veh/h per direction / capacity "
                                (rtos cap 2 0) " veh/h/lane = " (itoa n) " lane(s) per direction (minimum "
                                (itoa nmin) " for a " (if (= carr "1") "dual" "single") " carriageway)")))
       (setq per  (* 0.5 (- width mw))
             n    (max nmin (fix (+ 1e-6 (/ per lw))))
             msgs (list (strcat "Automatic lanes: no traffic volume given - from the road width " (rtos width 2 2)
                                " m: " (itoa n) " lane(s) of " (rtos lw 2 2) " m per direction (minimum " (itoa nmin) ")"))))
     (setq nl n nr n ww (+ (* 2 n lw) mw))
     (setq msgs (append msgs
                        (list (strcat "Road width becomes " (rtos ww 2 2) " m.")
                              "Indicative only - NOT an engineering approval. Confirm with a traffic study and the project design standard."))))
    (T (setq nl 0 nr 0 ww width)))
  (setq mo (if (and (> nl 0) (> nr 0)) (* 0.5 (- nr nl) lw) 0.0))
  (list ww nl nr lw mw mo msgs))

;;----------------------------------------------------------------------------
;;  Validation of the corridor settings.  Returns (errors warnings)
;;----------------------------------------------------------------------------
(defun rp:corr-check (width / er wa v k pl lw nl nr mw carr med lm per chk)
  (setq carr (rp:cv "ccarr") med (rp:cv "cmed") lm (rp:cv "clmode"))
  ;; numbers that must be valid (key name may-be-zero relevant)
  (setq chk (list (list "clw"   "Lane width"                    nil (/= lm "0"))
                  (list "clanl" "Lanes left"                    nil (= lm "1"))
                  (list "clanr" "Lanes right"                   nil (= lm "1"))
                  (list "cvol"  "Design volume"                 T   (= lm "2"))
                  (list "ccap"  "Lane capacity"                 nil (= lm "2"))
                  (list "cmedw" "Median width"                  nil (/= med "0"))
                  (list "cswlw" "Left sidewalk width"           nil (rp:con "cswl"))
                  (list "cswrw" "Right sidewalk width"          nil (rp:con "cswr"))
                  (list "cswo"  "Sidewalk gap"                  T   (or (rp:con "cswl") (rp:con "cswr")))
                  (list "cwkw"  "Walkway width"                 nil (or (rp:con "cwkl") (rp:con "cwkr")))
                  (list "cwko"  "Walkway verge"                 T   (or (rp:con "cwkl") (rp:con "cwkr")))
                  (list "cdrw"  "Drain width / pipe diameter"   nil (or (rp:con "cdrl") (rp:con "cdrr")))
                  (list "cdrd"  "Drain depth"                   nil (or (rp:con "cdrl") (rp:con "cdrr")))
                  (list "cdro"  "Drain gap"                     T   (or (rp:con "cdrl") (rp:con "cdrr")))
                  (list "cutw"  "Utility corridor width"        nil (or (rp:con "cutl") (rp:con "cutr")))
                  (list "cuto"  "Utility corridor gap"          T   (or (rp:con "cutl") (rp:con "cutr")))
                  (list "cpsc"  "Hatch scale"                   nil (rp:con "cpav"))))
  (foreach c chk
    (if (cadddr c)
      (progn
        (setq v (rp:dist (rp:cv (car c))))
        (cond ((null v) (setq er (cons (strcat (cadr c) " is not a number.") er)))
              ((and (caddr c) (< v 0.0)) (setq er (cons (strcat (cadr c) " must be zero or more.") er)))
              ((and (not (caddr c)) (<= v 0.0)) (setq er (cons (strcat (cadr c) " must be greater than zero.") er)))))))
  (if (and (rp:con "cpav") (= (rp:cv "cpat") "2") (= (vl-string-trim " " (rp:cv "cpatn")) ""))
    (setq er (cons "Enter the hatch pattern name for walkways." er)))
  (if (null (rp:dist (rp:cv "cpang"))) (setq er (cons "Hatch angle is not a number." er)))
  (if (not er)
    (progn
      (setq lw (rp:cn "clw"))
      (if (/= lm "0")
        (cond ((or (< lw 2.5) (> lw 5.0)) (setq er (cons "Lane width must be between 2.50 and 5.00 m." er)))
              ((or (< lw 3.0) (> lw 3.75)) (setq wa (cons (strcat "Lane width " (rtos lw 2 2) " m is outside the usual 3.00 - 3.75 m.") wa)))))
      (if (= lm "1")
        (foreach k '(("clanl" "left") ("clanr" "right"))
          (setq v (rp:cn (car k)))
          (cond ((or (not (rp:int-p v)) (< v 1) (> v 8))
                 (setq er (cons (strcat "Lanes on the " (cadr k) " side must be a whole number from 1 to 8.") er)))
                ((> v 4) (setq wa (cons (strcat (rtos v 2 0) " lanes on the " (cadr k) " side - check the design.") wa))))))
      (if (and (= lm "2") (> (rp:cn "cvol") 0.0) (> (/ (rp:cn "cvol") (rp:cn "ccap")) 6.0))
        (setq wa (cons "Automatic: more than 6 lanes per direction - check volume and capacity." wa)))
      (if (and (= lm "1") (= carr "1")
               (or (< (rp:cn "clanl") 2) (< (rp:cn "clanr") 2)))
        (setq wa (cons "Dual carriageway with a single lane in one direction - check the design." wa)))
      (if (/= med "0")
        (progn
          (setq mw (rp:cn "cmedw"))
          (cond ((< mw 0.3) (setq er (cons "Median width must be at least 0.30 m." er)))
                ((and (= med "2") (< mw 1.2)) (setq wa (cons "Raised median narrower than 1.20 m." wa))))))
      (if (and (= carr "1") (= med "0") (not (member (rp:cv "ctype") '("1" "2"))))
        (setq er (cons "Dual carriageway needs a separation: choose a median, or Centre = barricades / cones (RDP)." er)))
      (setq pl (rp:lane-plan width) mw (nth 4 pl))
      (if (= lm "0")
        (progn
          (setq per (if (= carr "1") (* 0.5 (- width mw)) (if (> mw 0.0) (* 0.5 (- width mw)) (* 0.5 width))))
          (cond ((< per 2.5) (setq er (cons (strcat "Each carriageway would be only " (rtos per 2 2) " m wide - increase the road width or reduce the median.") er)))
                ((< per 3.0) (setq wa (cons (strcat "Each carriageway is only " (rtos per 2 2) " m wide.") wa))))))
      (foreach k '(("cswl" "cswlw" "Left sidewalk") ("cswr" "cswrw" "Right sidewalk"))
        (if (and (rp:con (car k)) (< (rp:cn (cadr k)) 1.5))
          (setq wa (cons (strcat (caddr k) " narrower than 1.50 m.") wa))))
      (if (and (or (rp:con "cwkl") (rp:con "cwkr")) (< (rp:cn "cwkw") 1.5))
        (setq wa (cons "Walkway narrower than 1.50 m." wa)))))
  (list (reverse er) (reverse wa)))

;;----------------------------------------------------------------------------
;;  Components beyond the road edges (all in drawing units).
;;  Returns list of (code sg o1 o2 width) : o1 / o2 = inner / outer distance
;;  beyond the carriageway edge line.  Order outwards : shoulder, edge
;;  treatment, sidewalk, walkway, drain, utility corridor.
;;----------------------------------------------------------------------------
(defun rp:corr-layout (bgap bwid el er fac / out sg base w g)
  (foreach sg '(1.0 -1.0)
    (setq base (+ bgap (if (if (> sg 0) el er) bwid 0.0)))
    (foreach c (list (list "SW" (if (> sg 0) "cswl" "cswr") (if (> sg 0) "cswlw" "cswrw") "cswo")
                     (list "WK" (if (> sg 0) "cwkl" "cwkr") "cwkw" "cwko")
                     (list "DR" (if (> sg 0) "cdrl" "cdrr") "cdrw" "cdro")
                     (list "UT" (if (> sg 0) "cutl" "cutr") "cutw" "cuto"))
      (if (rp:con (cadr c))
        (setq g    (* fac (rp:cn (cadddr c)))
              w    (* fac (rp:cn (caddr c)))
              out  (cons (list (car c) sg (+ base g) (+ base g w) w) out)
              base (+ base g w)))))
  (reverse out))

(defun rp:corr-any ()
  (or (/= (rp:cv "cmed") "0")
      (vl-some 'rp:con '("cswl" "cswr" "cwkl" "cwkr" "cdrl" "cdrr" "cutl" "cutr"))))

(defun rp:corr-summary (/ s)
  (setq s (strcat (if (= (rp:cv "ccarr") "1") "Dual" "Single") " carriageway, "
                  (cond ((= (rp:cv "clmode") "1") (strcat (rp:cv "clanl") "+" (rp:cv "clanr") " lanes"))
                        ((= (rp:cv "clmode") "2") "automatic lanes")
                        (T "lanes from road width"))
                  (cond ((= (rp:cv "cmed") "1") ", flush median") ((= (rp:cv "cmed") "2") ", raised median") (T ""))
                  (if (or (rp:con "cswl") (rp:con "cswr"))
                    (strcat ", sidewalk " (cond ((and (rp:con "cswl") (rp:con "cswr")) "both sides") ((rp:con "cswl") "left") (T "right"))) "")
                  (if (or (rp:con "cwkl") (rp:con "cwkr")) ", walkway" "")
                  (if (or (rp:con "cdrl") (rp:con "cdrr")) ", drain" "")
                  (if (or (rp:con "cutl") (rp:con "cutr")) ", utilities" "")))
  s)

;;----------------------------------------------------------------------------
;;  Hatches
;;----------------------------------------------------------------------------
;; Make sure RP_PAVER.pat can be found (written once to the roaming Support folder)
(defun rp:paver-file (/ fn f)
  (cond
    ((findfile "RP_PAVER.pat"))
    (T
     (setq fn (strcat (getvar "ROAMABLEROOTPREFIX") "Support\\RP_PAVER.pat"))
     (if (setq f (open fn "w"))
       (progn (foreach l *rp:paver-pat* (write-line l f)) (close f)))
     (findfile "RP_PAVER.pat"))))

;; New hatch for a corridor surface. kind : "PAV" walkway / sidewalk surface,
;; "MEDF" flush median, "SOLID", or a pattern name. ang = road direction.
(defun rp:chatch (kind elev fac ang / h nm typ sc iso)
  (setq iso (= (getvar "MEASUREMENT") 1)
        typ acHatchPatternTypePreDefined
        sc  1.0)
  (cond
    ((= kind "PAV")
     (cond ((not (rp:con "cpav")) (setq nm "SOLID"))
           ((and (= (rp:cv "cpat") "0") (rp:paver-file))
            (setq nm "RP_PAVER" typ acHatchPatternTypeCustomDefined sc fac))
           ((member (rp:cv "cpat") '("0" "1"))
            (setq nm "AR-HBONE" sc (* fac (if iso 0.001 0.0254))))
           (T (setq nm (strcase (vl-string-trim " " (rp:cv "cpatn"))) sc fac)))
     (setq sc  (* sc (rp:cn "cpsc"))
           ang (+ ang (* pi (/ (rp:cn "cpang") 180.0)))))
    ((= kind "MEDF") (setq nm "ANSI31" sc (* fac (if iso 0.315 8.0)) ang (+ ang (* 0.25 pi))))
    (T (setq nm kind)))
  (setq h (vl-catch-all-apply 'vla-AddHatch (list *rp:spc* typ nm :vlax-false)))
  (if (and (vl-catch-all-error-p h) (= kind "PAV"))
    (progn
      (princ (strcat "\n  Hatch pattern " nm " not available - using AR-HBONE herringbone."))
      (setq nm "AR-HBONE" sc (* fac (if iso 0.001 0.0254) (rp:cn "cpsc"))
            h  (vl-catch-all-apply 'vla-AddHatch (list *rp:spc* acHatchPatternTypePreDefined nm :vlax-false)))))
  (if (vl-catch-all-error-p h)
    (setq nm "SOLID" h (vla-AddHatch *rp:spc* acHatchPatternTypePreDefined "SOLID" :vlax-false)))
  (vla-put-Elevation h elev)
  (if (/= nm "SOLID")
    (progn
      (vl-catch-all-apply 'vla-put-PatternAngle (list h ang))
      (vl-catch-all-apply 'vla-put-PatternScale (list h sc))))
  h)

;;----------------------------------------------------------------------------
;;  Plan drawing helpers
;;----------------------------------------------------------------------------
;; Edge distance from the CL on one side at station d : tapers tp + widenings wp
(defun rp:edge-at (tp wp hw d / o)
  (setq o (rp:soff tp hw d))
  (foreach w wp (setq o (+ o (rp:prof-o w d))))
  o)

;; Strip on side sg between stations a and b, from r1 to r2 beyond the edge
;; (tapers tp / widenings wp; hw = 0 and sg = 1 gives plain CL offsets).
;; kind = hatch kind or nil. lines = T draws both boundary lines on lay.
;; Returns (length area)
(defun rp:cband (cl a b sg r1 r2 tp wp hw lay kind elev fac lines / s0 s1 n i d ed pa pb bnd h ar ang)
  (setq s0 a ar 0.0)
  (while (< s0 (- b 1e-6))
    (setq s1 (min b (+ s0 (* 25.0 fac)))
          n  (max 1 (fix (+ 0.999999 (/ (- s1 s0) fac))))
          i  0 pa nil pb nil)
    (repeat (1+ n)
      (setq d  (+ s0 (* (- s1 s0) (/ (float i) n)))
            ed (rp:edge-at tp wp hw d)
            pa (cons (rp:offpt cl d (* sg (+ ed r1))) pa)
            pb (cons (rp:offpt cl d (* sg (+ ed r2))) pb)
            i  (1+ i)))
    (setq bnd (rp:poly (append (reverse pa) pb) lay elev)
          ar  (+ ar (vla-get-Area bnd)))
    (if kind
      (progn
        (setq ang (angle '(0.0 0.0) (caddr (rp:frame cl (* 0.5 (+ s0 s1)))))
              h   (rp:chatch kind elev fac ang))
        (vla-put-Layer h lay)
        (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-AppendOuterLoop (list h (rp:objarr (list bnd)))))
          (vla-Delete h)
          (progn (vl-catch-all-apply 'vla-Evaluate (list h)) (setq *rp:hatches* (cons h *rp:hatches*))))))
    (vla-Delete bnd)
    (setq s0 s1))
  (if lines
    (foreach r (list r1 r2)
      (setq i 0 pa nil n (max 1 (fix (+ 0.999999 (/ (- b a) fac)))))
      (repeat (1+ n)
        (setq d  (+ a (* (- b a) (/ (float i) n)))
              pa (cons (list (rp:offpt cl d (* sg (+ (rp:edge-at tp wp hw d) r))) 0.0) pa)
              i  (1+ i)))
      (rp:mkpl (reverse pa) lay elev nil)))
  (list (- b a) ar))

;; Line along the road at distance r beyond the edge (one polyline)
(defun rp:cline (cl a b sg r tp wp hw lay elev fac / i n d pa)
  (setq i 0 n (max 1 (fix (+ 0.999999 (/ (- b a) fac)))))
  (repeat (1+ n)
    (setq d  (+ a (* (- b a) (/ (float i) n)))
          pa (cons (list (rp:offpt cl d (* sg (+ (rp:edge-at tp wp hw d) r))) 0.0) pa)
          i  (1+ i)))
  (rp:mkpl (reverse pa) lay elev nil))

;; Label along the road every 100 m (at least once) at side offset off
(defun rp:clabels (cl a b sg r tp wp hw txt th elev fac lay / d f ang tx s step)
  (setq step (* 100.0 fac)
        d    (+ a (min (* 0.5 (- b a)) (* 15.0 fac))))
  (while (< d b)
    (setq f   (rp:frame cl d)
          ang (angle '(0.0 0.0) (caddr f))
          tx  (rp:text txt (rp:offpt cl d (* sg (+ (rp:edge-at tp wp hw d) r))) th lay elev))
    (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (setq ang (+ ang pi)))
    (vla-put-Rotation tx ang)
    (setq d (+ d step)))
  (princ))

;; Ticks across a strip every sp (covered drains : grating marks)
(defun rp:cticks (cl a b sg r1 r2 tp wp hw sp lay elev / d ed)
  (setq d (+ a (* 0.5 sp)))
  (while (< d b)
    (setq ed (rp:edge-at tp wp hw d))
    (rp:line (rp:offpt cl d (* sg (+ ed r1))) (rp:offpt cl d (* sg (+ ed r2))) lay elev)
    (setq d (+ d sp)))
  (princ))

;;----------------------------------------------------------------------------
;;  Draw (or redraw) the corridor of a road : median + components.
;;  Uses the road's own stored settings. Removes the previous corridor.
;;----------------------------------------------------------------------------
(defun rp:corr-run (e / data fac obj len hw elev bgap bwid el er mw mo med gaps recs th q warn
                        mark new hd en lo hi kw r c sg tp wp kg mg pcs code o1 o2 w ln ar curves
                        nm lay kind dt ds dd hsh oth i rg)
  (setq data (rp:xget e)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq obj   (vlax-ename->vla-object e)
        *rp:cset* (vlax-ldata-get obj "ROADPRO_SET")
        len   (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        hw    (* 0.5 fac (atof (rp:xv "W" data)))
        elev  (vla-get-Elevation obj)
        bgap  (* fac (atof (rp:xv "BGAP" data)))
        bwid  (* fac (atof (rp:xv "BWID" data)))
        el    (rp:edge-on data 1.0)
        er    (rp:edge-on data -1.0)
        mw    (* fac (atof (rp:xv "MW" data)))
        mo    (* fac (atof (rp:xv "MO" data)))
        med   (rp:xv "MED" data)
        gaps  (vlax-ldata-get obj "ROADPRO_MKGAP")
        recs  (vlax-ldata-get obj "ROADPRO_TAPERS")
        curves (rp:curves obj)
        th    (* 0.6 fac (rp:cn "txth"))
        *rp:hatches* nil
        q nil warn nil)
  ;; remove the previous corridor of this road
  (foreach hd (vlax-ldata-get obj "ROADPRO_CORR")
    (if (and (setq en (handent hd)) (entget en)) (entdel en)))
  (setq mark (entlast))
  ;; ---- median ----
  (if (and (member med '("1" "2")) (> mw 0.0))
    (progn
      (setq lo (- mo (* 0.5 mw)) hi (+ mo (* 0.5 mw)) kw (min (* 0.15 fac) (* 0.25 mw)))
      (if (= med "2")
        (progn
          (rp:cband obj 0.0 len 1.0 lo (+ lo kw) nil nil 0.0 "ROAD-MEDIAN-KERB" "SOLID" elev fac T)
          (rp:cband obj 0.0 len 1.0 (- hi kw) hi nil nil 0.0 "ROAD-MEDIAN-KERB" "SOLID" elev fac T)
          (setq r (rp:cband obj 0.0 len 1.0 (+ lo kw) (- hi kw) nil nil 0.0 "ROAD-MEDIAN" "SOLID" elev fac nil)))
        (setq r (rp:cband obj 0.0 len 1.0 lo hi nil nil 0.0 "ROAD-MEDIAN" "MEDF" elev fac T)))
      (setq q (cons (list "MED" 0.0 (if (= med "2") "Median - raised (kerbed)" "Median - flush (painted)")
                          (/ mw fac) (/ len fac) (/ (* mw len) fac fac))
                    q))
      (rp:clabels obj 0.0 len 1.0 mo nil nil 0.0
                  (strcat (if (= med "2") "RAISED MEDIAN " "FLUSH MEDIAN ") (rtos (/ mw fac) 2 2) " m")
                  th elev fac "ROAD-MEDIAN")))
  ;; ---- sidewalks, walkways, drains, utility corridor ----
  (foreach c (rp:corr-layout bgap bwid el er fac)
    (setq code (car c) sg (cadr c) o1 (caddr c) o2 (cadddr c) w (nth 4 c)
          tp   (rp:taper-profs recs sg fac)
          wp   (mapcar 'caddr (vl-remove-if-not '(lambda (g) (and (= (car g) "W") (= (cadr g) sg))) gaps))
          kg   (mapcar '(lambda (g) (list (nth 2 g) (nth 3 g)))
                       (vl-remove-if-not '(lambda (g) (and (= (car g) "K") (= (cadr g) sg))) gaps))
          mg   (mapcar '(lambda (g) (list (nth 2 g) (nth 3 g)))
                       (vl-remove-if-not '(lambda (g) (and (= (car g) "M") (= (cadr g) sg))) gaps))
          pcs  (rp:mk-ranges 0.0 len
                 (append kg (if (or (member code '("SW" "WK")) (and (= code "DR") (/= (rp:cv "cdrt") "2"))) mg)))
          ln 0.0 ar 0.0)
    ;; inside of tight bends
    (foreach cv curves
      (if (and (= (nth 4 cv) (fix sg)) (>= (+ hw o2) (nth 2 cv)))
        (setq warn (cons (strcat (rp:cname code sg) " is wider than the radius on the inside of the bend at CH "
                                 (rp:chfmt (+ (atof (rp:xv "CHST" data)) (/ (car cv) fac)))
                                 " (R " (rtos (/ (nth 2 cv) fac) 2 2) " m) - it will overlap itself.")
                         warn))))
    (foreach rg pcs
      (cond
        ((member code '("SW" "WK"))
         (setq lay (if (= code "SW") "ROAD-SIDEWALK" "ROAD-WALKWAY")
               r   (rp:cband obj (car rg) (cadr rg) sg o1 o2 tp wp hw lay "PAV" elev fac T)))
        ((= code "DR")
         (setq lay "ROAD-DRAIN" dt (rp:cv "cdrt"))
         (cond
           ((= dt "2")      ; stormwater pipe : centre line + pipe walls
            (rp:cline obj (car rg) (cadr rg) sg (* 0.5 (+ o1 o2)) tp wp hw lay elev fac)
            (setq r (rp:cband obj (car rg) (cadr rg) sg o1 o2 tp wp hw lay nil elev fac T)))
           ((= dt "1")      ; covered U-channel : walls + grating ticks
            (setq r (rp:cband obj (car rg) (cadr rg) sg o1 o2 tp wp hw lay nil elev fac T))
            (rp:cticks obj (car rg) (cadr rg) sg o1 o2 tp wp hw (* 2.0 fac) lay elev))
           (T               ; open channel : top of banks + invert line, light fill
            (setq r (rp:cband obj (car rg) (cadr rg) sg o1 o2 tp wp hw lay "ANSI37" elev fac T))
            (rp:cline obj (car rg) (cadr rg) sg (* 0.5 (+ o1 o2)) tp wp hw lay elev fac))))
        ((= code "UT")
         (setq r (rp:cband obj (car rg) (cadr rg) sg o1 o2 tp wp hw "ROAD-UTILITY" nil elev fac T))))
      (setq ln (+ ln (car r)) ar (+ ar (cadr r)))
      (rp:clabels obj (car rg) (cadr rg) sg (* 0.5 (+ o1 o2)) tp wp hw (rp:clabel-txt code w fac) th elev fac
                  (cdr (assoc code '(("SW" . "ROAD-SIDEWALK") ("WK" . "ROAD-WALKWAY") ("DR" . "ROAD-DRAIN") ("UT" . "ROAD-UTILITY"))))))
    (setq q (cons (list code sg (rp:cname code sg) (/ w fac) (/ ln fac) (/ ar fac fac)) q)))
  ;; ---- bookkeeping, draw order : surfaces under everything, road surface lowest ----
  (setq new (rp:since mark))
  (vlax-ldata-put obj "ROADPRO_CORR" (mapcar '(lambda (x) (cdr (assoc 5 (entget x)))) new))
  (vlax-ldata-put obj "ROADPRO_CQTY" (reverse q))
  (foreach x new (if (= (cdr (assoc 0 (entget x))) "HATCH") (setq hsh (cons x hsh)) (setq oth (cons x oth))))
  (if hsh (rp:order-ss (reverse hsh) "_B"))
  (setq hsh (ssget "_X" '((0 . "HATCH") (8 . "ROAD-SURFACE,ROAD-SHOULDER"))))
  (if hsh (command "_.DRAWORDER" hsh "" "_B"))
  (rp:track e mark)
  (foreach x (reverse warn) (princ (strcat "\n  Warning: " x)))
  (setq *rp:cset* nil)
  (length q))

(defun rp:cname (code sg)
  (strcat (cdr (assoc code '(("SW" . "Sidewalk") ("WK" . "Walkway") ("DR" . "Drain") ("UT" . "Utility corridor") ("MED" . "Median"))))
          (cond ((= sg 1.0) " - left") ((= sg -1.0) " - right") (T ""))))

(defun rp:clabel-txt (code w fac / dt)
  (setq dt (rp:cv "cdrt"))
  (cond ((= code "SW") (strcat "SIDEWALK " (rtos (/ w fac) 2 2) " m"))
        ((= code "WK") (strcat "WALKWAY " (rtos (/ w fac) 2 2) " m"))
        ((= code "DR")
         (cond ((= dt "2") (strcat "SW PIPE DN" (rtos (* 1000.0 (/ w fac)) 2 0) " (PROVISION)"))
               ((= dt "1") (strcat "COVERED U-CHANNEL " (rtos (/ w fac) 2 2) " x " (rtos (rp:cn "cdrd") 2 2) " m (PROVISION)"))
               (T (strcat "OPEN DRAIN " (rtos (/ w fac) 2 2) " x " (rtos (rp:cn "cdrd") 2 2) " m (PROVISION)"))))
        (T (strcat "UTILITY CORRIDOR " (rtos (/ w fac) 2 2) " m (PROVISION)"))))

;; Report rows for the corridor of a road
(defun rp:corr-rows (obj data / q rows sn lm nl nr lw)
  (setq sn  (vlax-ldata-get obj "ROADPRO_SET")
        q   (vlax-ldata-get obj "ROADPRO_CQTY")
        lm  (rp:xv "LMODE" data)
        nl  (rp:xv "NL" data) nr (rp:xv "NR" data))
  (if (or q (member lm '("1" "2")) (= (rp:xv "CARR" data) "1"))
    (progn
      (setq *rp:cset* sn)
      (setq rows
        (append
          (list '("#" "CROSS SECTION / CORRIDOR")
                (list "Carriageway" (if (= (rp:xv "CARR" data) "1") "Dual (two carriageways)" "Single"))
                (list "Lanes"
                      (if (and (/= nl "") (> (atoi nl) 0))
                        (strcat nl " left + " nr " right  x  " (rp:xv "LW" data) " m")
                        "From road width (no lane lines)"))
                (list "Lane selection"
                      (cond ((= lm "1") "Manual")
                            ((= lm "2") (strcat "Automatic - indicative only, not engineering approved"
                                                (if (> (rp:cn "cvol") 0.0)
                                                  (strcat " (V " (rp:cv "cvol") " veh/h/dir, C " (rp:cv "ccap") " veh/h/lane)")
                                                  " (from road width)")))
                            (T "By road width"))))
          (mapcar '(lambda (x)
                     (list (nth 2 x)
                           (strcat (rtos (nth 3 x) 2 2) " m wide,  length " (rtos (nth 4 x) 2 1) " m,  area "
                                   (rtos (nth 5 x) 2 2) " m2"
                                   (if (member (car x) '("SW" "WK"))
                                     (if (rp:con "cpav")
                                       (cond ((= (rp:cv "cpat") "0") "  (interlocking paver)")
                                             ((= (rp:cv "cpat") "1") "  (herringbone paver)")
                                             (T (strcat "  (" (rp:cv "cpatn") ")")))
                                       "")
                                     ""))))
                  q)
          (if (vl-some '(lambda (x) (member (car x) '("DR" "UT"))) q)
            (list (list "Drainage / utilities" "Geometric provision only - no hydraulic or utility design")))))))
  (setq *rp:cset* nil)
  rows)

;; Track every object created since mark as part of road e (for rebuilds)
(defun rp:track (e mark / obj)
  (setq obj (vlax-ename->vla-object e))
  (vlax-ldata-put obj "ROADPRO_ALL"
                  (append (vlax-ldata-get obj "ROADPRO_ALL")
                          (mapcar '(lambda (x) (cdr (assoc 5 (entget x)))) (rp:since mark))))
  (princ))

;;----------------------------------------------------------------------------
;;  v3.4 helpers : lane lines, label offsets, cross-section corridor
;;----------------------------------------------------------------------------
;; Broken white lane line (L1 by speed) at side offset o along the whole road.
;; Returns the painted length.
(defun rp:mk-broken (obj len o spdm fac elev / d de pt q)
  (setq d 0.0 q 0.0 pt (rp:l1 spdm))
  (while (< d len)
    (setq de (min len (+ d (* fac (car pt)))))
    (if (> (- de d) (* 0.5 fac))
      (progn
        (rp:mk-strip obj d de 1.0 nil 0.0 fac elev nil "ROAD-MARKING-FILL" (- o (* 0.05 fac)) (+ o (* 0.05 fac)))
        (setq q (+ q (- de d)))))
    (setq d (+ d (* fac (+ (car pt) (cadr pt))))))
  q)

;; Extra room taken by corridor items on side sg beyond the edge treatment
;; (current settings), drawing units
(defun rp:corr-extra (sg fac bgap bwid / m base)
  (setq base (+ bgap (if (rp:con (if (> sg 0) "bl" "br")) bwid 0.0)) m base)
  (foreach c (rp:corr-layout bgap bwid (rp:con "bl") (rp:con "br") fac)
    (if (= (cadr c) sg) (setq m (max m (cadddr c)))))
  (- m base))

;; ---- cross section ----
;; outer extent of corridor items on side sg (beyond the carriageway edge)
(defun rp:xc-ext2 (sg / m)
  (setq m 0.0)
  (if *rp:xc* (foreach c (nth 6 *rp:xc*) (if (= (cadr c) sg) (setq m (max m (cadddr c))))))
  m)

(defun rp:xc-ext () (max (rp:xc-ext2 1.0) (rp:xc-ext2 -1.0)))

;; add lane, median and corridor boundaries to the dimension chain xs
(defun rp:xc-dims (xs hw / mw mo nl nr lw k out prev)
  (if *rp:xc*
    (progn
      (setq mw (nth 0 *rp:xc*) mo (nth 1 *rp:xc*) nl (nth 3 *rp:xc*) nr (nth 4 *rp:xc*) lw (nth 5 *rp:xc*))
      (if (> mw 0.0) (setq xs (append xs (list (- mo (* 0.5 mw)) (+ mo (* 0.5 mw))))))
      (if (> nl 0)
        (progn
          (setq k 1)
          (repeat (1- nl) (setq xs (cons (- mo (* 0.5 mw) (* k lw)) xs) k (1+ k)))
          (setq k 1)
          (repeat (1- nr) (setq xs (cons (+ mo (* 0.5 mw) (* k lw)) xs) k (1+ k)))))
      (foreach c (nth 6 *rp:xc*)
        (setq xs (append xs (list (* (- (cadr c)) (+ hw (caddr c))) (* (- (cadr c)) (+ hw (cadddr c)))))))))
  (foreach x (vl-sort xs '<)
    (if (or (null prev) (> (- x prev) 1e-6)) (setq out (cons x out) prev x)))
  (reverse out))

;; rectangle (x1 x2 y1 y2) filled on layer lay
(defun rp:xrect (x1 x2 y1 y2 lay)
  (rp:solidfill (rp:xpl (list (list x1 y1) (list x2 y1) (list x2 y2) (list x1 y2)) "ROAD-XSEC" T) nil lay 0.0))

;; Median, sidewalks, walkways, drains and utility corridor in a section.
;; Section coordinates : the road's LEFT side is on the LEFT (negative x);
;; *rp:xc* holds the median offset already in section coordinates.
(defun rp:xcorr (hw yL yR fac th / mw mo med comps lo hi kw c sg x1 x2 ye w d top tx k ny dt cy)
  (setq mw (nth 0 *rp:xc*) mo (nth 1 *rp:xc*) med (nth 2 *rp:xc*) comps (nth 6 *rp:xc*)
        kw (* 0.15 fac) ny 0)
  ;; ---- median ----
  (if (and (member med '("1" "2")) (> mw 0.0))
    (progn
      (setq lo (- mo (* 0.5 mw)) hi (+ mo (* 0.5 mw)))
      (if (= med "2")
        (progn
          (rp:xrect lo (+ lo kw) 0.0 (* 0.15 fac) "ROAD-XSEC-CONC")
          (rp:xrect (- hi kw) hi 0.0 (* 0.15 fac) "ROAD-XSEC-CONC")
          (if (> (- hi lo) (* 2.0 kw)) (rp:xrect (+ lo kw) (- hi kw) 0.0 (* 0.12 fac) "ROAD-MEDIAN"))
          (rp:xmtext (strcat "RAISED MEDIAN " (rtos (/ mw fac) 2 2) " m\\PKERBS 150 mm UPSTAND") (list mo (+ (* 0.15 fac) (* 2.6 th))) th))
        (progn
          (rp:xrect lo hi 0.0 (* 0.02 fac) "ROAD-MARKING-YELLOW")
          (rp:xmtext (strcat "FLUSH MEDIAN " (rtos (/ mw fac) 2 2) " m (PAINTED, HATCHED)") (list mo (* 2.2 th)) th)))))
  ;; ---- items beyond the edges ----
  (foreach c comps
    (setq sg (cadr c) w (nth 4 c)
          x1 (* (- sg) (+ hw (caddr c))) x2 (* (- sg) (+ hw (cadddr c)))
          ye (if (> sg 0) yL yR))
    (if (< x2 x1) (setq k x1 x1 x2 x2 k))
    (setq tx (* 0.5 (+ x1 x2)))
    (cond
      ((member (car c) '("SW" "WK"))
       (setq top (+ ye (if (= (car c) "SW") (* 0.15 fac) (* 0.05 fac))))
       (rp:xrect x1 x2 (- top (* 0.08 fac)) top (if (= (car c) "SW") "ROAD-SIDEWALK" "ROAD-WALKWAY"))
       (rp:xrect x1 x2 (- top (* 0.11 fac)) (- top (* 0.08 fac)) "ROAD-XSEC-L3")
       (rp:xrect x1 x2 (- top (* 0.26 fac)) (- top (* 0.11 fac)) "ROAD-XSEC-L2")
       (if (= (car c) "SW")
         (rp:xrect (if (> sg 0) (- x2 (* 0.12 fac)) x1) (if (> sg 0) x2 (+ x1 (* 0.12 fac))) (- top (* 0.40 fac)) top "ROAD-XSEC-CONC"))  ; kerb on the road side
       (rp:xmtext (strcat (if (= (car c) "SW") "SIDEWALK " "WALKWAY ") (rtos (/ w fac) 2 2) " m"
                          "\\PINTERLOCKING PAVERS 80 mm\\PON 30 mm SAND + 150 mm BASE")
                  (list tx (+ top (* (+ 2.2 (* 3.4 ny)) th))) (* 0.9 th)))
      ((= (car c) "DR")
       (setq d (* fac (rp:cn "cdrd")) dt (rp:cv "cdrt"))
       (cond
         ((= dt "2")
          (setq cy (- ye d (* -0.5 w)))
          (vla-put-Layer (vla-AddCircle *rp:spc* (rp:p3 (rp:xp tx cy) 0.0) (* 0.5 w)) "ROAD-DRAIN")
          (rp:xmtext (strcat "SW PIPE DN" (rtos (* 1000.0 (/ w fac)) 2 0) "\\PINVERT -" (rtos (/ d fac) 2 2) " m\\P(PROVISION)")
                     (list tx (+ ye (* 2.6 th))) (* 0.9 th)))
         ((= dt "1")
          (rp:solidfill (rp:xpl (list (list x1 (+ ye 0.0)) (list x2 ye) (list x2 (- ye d (* 0.1 fac))) (list x1 (- ye d (* 0.1 fac)))) "ROAD-XSEC" T)
                        (rp:xpl (list (list (+ x1 (* 0.1 fac)) ye) (list (- x2 (* 0.1 fac)) ye) (list (- x2 (* 0.1 fac)) (- ye d)) (list (+ x1 (* 0.1 fac)) (- ye d))) "ROAD-DRAIN" T)
                        "ROAD-XSEC-CONC" 0.0)
          (rp:xline (list x1 (+ ye (* 0.02 fac))) (list x2 (+ ye (* 0.02 fac))) "ROAD-DRAIN")
          (rp:xmtext (strcat "COVERED U-CHANNEL " (rtos (/ w fac) 2 2) " x " (rtos (/ d fac) 2 2) " m\\P(PROVISION)")
                     (list tx (+ ye (* 2.6 th))) (* 0.9 th)))
         (T
          (setq k (rp:xpl (list (list x1 ye) (list (+ x1 (/ w 3.0)) (- ye d)) (list (- x2 (/ w 3.0)) (- ye d)) (list x2 ye)) "ROAD-DRAIN" nil))
          (vla-put-ConstantWidth k (* 0.03 fac))
          (rp:xmtext (strcat "OPEN DRAIN " (rtos (/ w fac) 2 2) " x " (rtos (/ d fac) 2 2) " m\\P(PROVISION)")
                     (list tx (+ ye (* 2.6 th))) (* 0.9 th)))))
      ((= (car c) "UT")
       (setq k (rp:xpl (list (list x1 (- ye (* 0.6 fac))) (list x2 (- ye (* 0.6 fac))) (list x2 (- ye (* 1.2 fac))) (list x1 (- ye (* 1.2 fac)))) "ROAD-UTILITY" T))
       (rp:xmtext (strcat "UTILITY CORRIDOR " (rtos (/ w fac) 2 2) " m\\P(PROVISION)") (list tx (- ye (* 0.9 fac))) (* 0.8 th))))
    (setq ny (- 1 ny)))
  (princ))

;; extra room of corridor items on side dir (+1 left / -1 right) for labels
(defun rp:cin (dir) (if *rp:cinx* (if (> dir 0) (car *rp:cinx*) (cadr *rp:cinx*)) 0.0))

;;----------------------------------------------------------------------------
;;  Corridor dialog (used by RDP "Lanes, median ..." button and by RDC)
;;----------------------------------------------------------------------------
(setq *rp:cdcl*
 (list
  "roadcorr : dialog {"
  "  label = \"ROAD PRO  -  Lanes, Median, Sidewalks, Drains and Utilities\";"
  "  : text { key = \"info\"; width = 90; }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Carriageway and lanes\";"
  "      : popup_list { key = \"ccarr\";  label = \"Carriageway:\";     edit_width = 26; }"
  "      : popup_list { key = \"clmode\"; label = \"Number of lanes:\"; edit_width = 26; }"
  "      : edit_box { key = \"clanl\"; label = \"Lanes, left side (opposite direction):\";   edit_width = 5; }"
  "      : edit_box { key = \"clanr\"; label = \"Lanes, right side (chainage direction):\";  edit_width = 5; }"
  "      : edit_box { key = \"clw\";   label = \"Lane width (m):\";                           edit_width = 5; }"
  "      : edit_box { key = \"cvol\";  label = \"Design volume per direction (veh/h, 0 = unknown):\"; edit_width = 6; }"
  "      : edit_box { key = \"ccap\";  label = \"Lane capacity assumed (veh/h/lane):\";       edit_width = 6; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Median\";"
  "      : popup_list { key = \"cmed\";  label = \"Median:\";          edit_width = 24; }"
  "      : edit_box   { key = \"cmedw\"; label = \"Median width (m):\"; edit_width = 6; }"
  "      : text { label = \"A dual carriageway needs a median or a\"; }"
  "      : text { label = \"centre barrier (RDP dialog : Centre).\"; }"
  "    }"
  "  }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Sidewalks and walkways\";"
  "      : row { : toggle { key = \"cswl\"; label = \"Sidewalk left\"; }"
  "              : edit_box { key = \"cswlw\"; label = \"width (m):\"; edit_width = 5; } }"
  "      : row { : toggle { key = \"cswr\"; label = \"Sidewalk right\"; }"
  "              : edit_box { key = \"cswrw\"; label = \"width (m):\"; edit_width = 5; } }"
  "      : edit_box { key = \"cswo\"; label = \"Gap behind the edge treatment (m):\"; edit_width = 5; }"
  "      : row { : toggle { key = \"cwkl\"; label = \"Walkway left\"; }"
  "              : toggle { key = \"cwkr\"; label = \"Walkway right\"; } }"
  "      : edit_box { key = \"cwkw\"; label = \"Walkway width (m):\";             edit_width = 5; }"
  "      : edit_box { key = \"cwko\"; label = \"Verge before the walkway (m):\";  edit_width = 5; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Drainage and utilities (geometric provision only)\";"
  "      : row { : toggle { key = \"cdrl\"; label = \"Drain left\"; }"
  "              : toggle { key = \"cdrr\"; label = \"Drain right\"; } }"
  "      : popup_list { key = \"cdrt\"; label = \"Drain type:\"; edit_width = 24; }"
  "      : edit_box { key = \"cdrw\"; label = \"Width / pipe diameter (m):\";  edit_width = 5; }"
  "      : edit_box { key = \"cdrd\"; label = \"Depth (m):\";                  edit_width = 5; }"
  "      : edit_box { key = \"cdro\"; label = \"Gap before the drain (m):\";   edit_width = 5; }"
  "      : row { : toggle { key = \"cutl\"; label = \"Utility corridor left\"; }"
  "              : toggle { key = \"cutr\"; label = \"right\"; } }"
  "      : edit_box { key = \"cutw\"; label = \"Corridor width (m):\";         edit_width = 5; }"
  "      : edit_box { key = \"cuto\"; label = \"Gap before the corridor (m):\"; edit_width = 5; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Sidewalk / walkway surface\";"
  "      : toggle     { key = \"cpav\";  label = \"Paver hatch\"; }"
  "      : popup_list { key = \"cpat\";  label = \"Pattern:\"; edit_width = 26; }"
  "      : edit_box   { key = \"cpatn\"; label = \"Other pattern name:\";     edit_width = 10; }"
  "      : edit_box   { key = \"cpsc\";  label = \"Scale (1 = real size):\";  edit_width = 6; }"
  "      : edit_box   { key = \"cpang\"; label = \"Extra angle (deg):\";      edit_width = 6; }"
  "    }"
  "  }"
  "  : boxed_column {"
  "    label = \"Check\";"
  "    : text { key = \"m1\"; width = 110; }"
  "    : text { key = \"m2\"; width = 110; }"
  "    : text { key = \"m3\"; width = 110; }"
  "  }"
  "  : row { : button { key = \"check\"; label = \"Check layout\"; width = 16; fixed_width = true; }"
  "          : text { label = \"Lane counts are indicative, not an engineering approval.\"; } }"
  "  : text { label = \"Developed by https://www.exceltokml.com/\"; alignment = right; }"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:cdlg-modes (/ lm any)
  (setq lm (get_tile "clmode"))
  (foreach k '("clanl" "clanr") (mode_tile k (if (= lm "1") 0 1)))
  (foreach k '("cvol" "ccap") (mode_tile k (if (= lm "2") 0 1)))
  (mode_tile "clw" (if (= lm "0") 1 0))
  (mode_tile "cmedw" (if (= (get_tile "cmed") "0") 1 0))
  (mode_tile "cswlw" (if (= (get_tile "cswl") "1") 0 1))
  (mode_tile "cswrw" (if (= (get_tile "cswr") "1") 0 1))
  (mode_tile "cswo" (if (or (= (get_tile "cswl") "1") (= (get_tile "cswr") "1")) 0 1))
  (setq any (or (= (get_tile "cwkl") "1") (= (get_tile "cwkr") "1")))
  (foreach k '("cwkw" "cwko") (mode_tile k (if any 0 1)))
  (setq any (or (= (get_tile "cdrl") "1") (= (get_tile "cdrr") "1")))
  (foreach k '("cdrt" "cdrw" "cdrd" "cdro") (mode_tile k (if any 0 1)))
  (setq any (or (= (get_tile "cutl") "1") (= (get_tile "cutr") "1")))
  (foreach k '("cutw" "cuto") (mode_tile k (if any 0 1)))
  (setq any (= (get_tile "cpav") "1"))
  (foreach k '("cpat" "cpsc" "cpang") (mode_tile k (if any 0 1)))
  (mode_tile "cpatn" (if (and any (= (get_tile "cpat") "2")) 0 1))
  (setq *rp:cwarned* nil))

;; Tile values as an override list (+ values handed over by the RDP dialog)
(defun rp:cdlg-ov () (append (mapcar '(lambda (k) (cons k (get_tile k))) *rp:ckeys*) *rp:cpar*))

(defun rp:cdlg-width (/ v)
  (if (and *rp:cpar* (setq v (assoc "width" *rp:cpar*)) (rp:dist (cdr v))) (rp:dist (cdr v)) (rp:cn "width")))

(defun rp:join2 (lst sep / s) (setq s "") (foreach x lst (setq s (if (= s "") x (strcat s sep x)))) s)

(defun rp:cdlg-check (/ chk pl)
  (setq *rp:cov* (rp:cdlg-ov)
        chk (rp:corr-check (rp:cdlg-width)))
  (if (not (car chk))
    (progn
      (setq pl (rp:lane-plan (rp:cdlg-width)))
      (set_tile "m1" (if (nth 6 pl) (car (nth 6 pl))
                       (strcat "Road width from the RDP dialog : " (rtos (car pl) 2 2) " m (no lane lines).")))
      (set_tile "m2" (if (cadr chk) (strcat "Warnings: " (rp:join2 (cadr chk) " | ")) "No warnings."))
      (set_tile "m3" (strcat "Result: " (rp:corr-summary) ",  road width " (rtos (car pl) 2 2) " m.")))
    (progn
      (set_tile "m1" (strcat "Errors: " (rp:join2 (car chk) " | ")))
      (set_tile "m2" "") (set_tile "m3" "")))
  (setq *rp:cov* nil)
  chk)

(defun rp:cdlg-accept (/ chk)
  (setq chk (rp:cdlg-check))
  (cond
    ((car chk) (set_tile "error" (car (car chk))))
    ((and (cadr chk) (not *rp:cwarned*))
     (setq *rp:cwarned* T)
     (set_tile "error" (strcat (car (cadr chk)) (if (cdr (cadr chk)) " (more above)" "") "  -  press OK again to accept.")))
    (T
     (foreach k *rp:ckeys* (rp:set k (get_tile k)))
     (foreach w (cadr chk) (princ (strcat "\n  Corridor warning: " w)))
     (done_dialog 1))))

;; info = first line of the dialog. Returns 'ok / 'cancel / 'fail
(defun rp:cdialog (info / fn f id res)
  (setq fn (vl-filename-mktemp "roadcorr.dcl") *rp:cwarned* nil)
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:cdcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadcorr" id))
        (progn
          (set_tile "info" info)
          (rp:fill "ccarr"  '("Single carriageway" "Dual carriageway"))
          (rp:fill "clmode" '("From road width (no lane lines)" "Manual lane count" "Automatic lane count"))
          (rp:fill "cmed"   '("No median" "Flush median (painted, hatched)" "Raised median (kerbed)"))
          (rp:fill "cdrt"   '("Open channel (trapezoidal)" "Covered U-channel" "Stormwater pipe"))
          (rp:fill "cpat"   '("Interlocking paver (I-shape)" "Herringbone paver (AR-HBONE)" "Other pattern"))
          (foreach k *rp:ckeys* (set_tile k (rp:cv k)))
          (rp:cdlg-modes)
          (rp:cdlg-check)
          (foreach k '("ccarr" "clmode" "cmed" "cswl" "cswr" "cwkl" "cwkr" "cdrl" "cdrr" "cutl" "cutr" "cpav" "cpat")
            (action_tile k "(rp:cdlg-modes)"))
          (action_tile "check"  "(rp:cdlg-check)")
          (action_tile "accept" "(rp:cdlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; Button in the RDP dialog
(defun rp:main-corr (/ r)
  (setq *rp:cpar* (list (cons "width" (get_tile "width")) (cons "ctype" (get_tile "ctype")) (cons "bwid" (get_tile "bwid"))))
  (setq r (rp:cdialog "Settings for new roads built with RDP (left / right seen looking along the centre line)."))
  (setq *rp:cpar* nil)
  (rp:main-corr-tiles)
  r)

(defun rp:main-corr-tiles (/ pl)
  (setq pl (rp:lane-plan (if (rp:dist (get_tile "width")) (rp:dist (get_tile "width")) (rp:num "width"))))
  (set_tile "csum" (strcat (rp:corr-summary)
                           (if (= (rp:val "clmode") "0") "" (strcat "  ->  road width " (rtos (car pl) 2 2) " m"))))
  (mode_tile "width" (if (= (rp:val "clmode") "1") 1 0)))

;;----------------------------------------------------------------------------
;;  Alignment checks : short segments, sharp bends without a curve, radius
;;  smaller than half the road, self-intersection.  Returns a list of texts.
;;----------------------------------------------------------------------------
(defun rp:seg-list (pts bul closed / n i out p0 p1 b th c ch r ln)
  (setq n (length pts) i 0)
  (repeat (if closed n (1- n))
    (setq p0 (nth i pts) p1 (nth (rem (1+ i) n) pts) b (nth i bul)
          ch (distance p0 p1) c (angle p0 p1))
    (if (> (abs b) 1e-9)
      (setq th (* 4.0 (atan b))
            r  (if (> ch 1e-12) (/ ch (* 2.0 (sin (* 0.5 (abs th))))) 0.0)
            ln (* r (abs th))
            out (cons (list p0 p1 b ln (- c (* 0.5 th)) (+ c (* 0.5 th)) r) out))
      (setq out (cons (list p0 p1 0.0 ch c c 0.0) out)))
    (setq i (1+ i)))
  (reverse out))

;; chords of a segment (arcs as 8 chords)
(defun rp:seg-chords (s / p0 p1 b th c r ctr a0 k out)
  (setq p0 (car s) p1 (cadr s) b (caddr s))
  (if (< (abs b) 1e-9)
    (list (list p0 p1))
    (progn
      (setq th  (* 4.0 (atan b)) r (nth 6 s)
            c   (angle p0 p1)
            ctr (polar p0 (+ (- c (* 0.5 th)) (if (> b 0) (* 0.5 pi) (* -0.5 pi))) r)
            a0  (angle ctr p0) k 1 out nil)
      (repeat 8
        (setq out (cons (list (polar ctr (+ a0 (* th (/ (float (1- k)) 8.0))) r)
                              (polar ctr (+ a0 (* th (/ (float k) 8.0))) r))
                        out)
              k (1+ k)))
      (reverse out))))

(defun rp:angdiff (a b / d)
  (setq d (rem (- b a) (* 2.0 pi)))
  (if (> d pi) (setq d (- d (* 2.0 pi))))
  (if (< d (- pi)) (setq d (+ d (* 2.0 pi))))
  d)

(defun rp:bbox-hit (ca cb / ax1 ax2 ay1 ay2 bx1 bx2 by1 by2)
  (setq ax1 (min (car (car ca)) (car (cadr ca))) ax2 (max (car (car ca)) (car (cadr ca)))
        ay1 (min (cadr (car ca)) (cadr (cadr ca))) ay2 (max (cadr (car ca)) (cadr (cadr ca)))
        bx1 (min (car (car cb)) (car (cadr cb))) bx2 (max (car (car cb)) (car (cadr cb)))
        by1 (min (cadr (car cb)) (cadr (cadr cb))) by2 (max (cadr (car cb)) (cadr (cadr cb))))
  (and (<= bx1 (+ ax2 1e-9)) (<= ax1 (+ bx2 1e-9)) (<= by1 (+ ay2 1e-9)) (<= ay1 (+ by2 1e-9))))

;; pts / bul = vertex list, closed flag, fac, hw (drawing units), st start chainage
(defun rp:cl-check (pts bul closed fac hw st / segs n i j s s2 out d dv ch ca cb hit ip ns)
  (setq segs (rp:seg-list pts bul closed) n (length segs) d 0.0 i 0)
  (foreach s segs
    (if (< (nth 3 s) (* 1.0 fac))
      (setq out (cons (strcat "very short segment (" (rtos (/ (nth 3 s) fac) 2 3) " m) at CH " (rp:chfmt (+ st (/ d fac)))) out)))
    (if (and (> (abs (caddr s)) 1e-9) (< (nth 6 s) hw))
      (setq out (cons (strcat "curve at CH " (rp:chfmt (+ st (/ d fac))) " has R " (rtos (/ (nth 6 s) fac) 2 2)
                              " m, smaller than half the road width") out)))
    (setq d (+ d (nth 3 s)))
    (if (or (< (1+ i) n) closed)
      (progn
        (setq s2 (nth (rem (1+ i) n) segs)
              dv (abs (rp:angdiff (nth 5 s) (nth 4 s2))))
        (if (and (> dv (/ pi 360.0)) (or (< (1+ i) n) closed))
          (setq out (cons (strcat "sharp bend of " (rtos (* 180.0 (/ dv pi)) 2 1) " deg at CH "
                                  (rp:chfmt (+ st (/ d fac))) " with no curve") out)))))
    (setq i (1+ i)))
  ;; self-intersection (non-adjacent segments)
  (setq i 0 ns nil)
  (while (and (< i n) (not hit))
    (setq j (+ i 2))
    (while (and (< j n) (not hit))
      (if (not (and closed (= i 0) (= j (1- n))))
        (foreach ca (rp:seg-chords (nth i segs))
          (foreach cb (rp:seg-chords (nth j segs))
            (if (and (not hit) (rp:bbox-hit ca cb) (setq ip (inters (car ca) (cadr ca) (car cb) (cadr cb) T)))
              (setq hit ip)))))
      (setq j (1+ j)))
    (setq i (1+ i)))
  (if hit
    (setq out (cons (strcat "SELF-INTERSECTION: the centre line crosses itself near E " (rtos (/ (car hit) fac) 2 3)
                            "  N " (rtos (/ (cadr hit) fac) 2 3)) out)))
  (reverse out))

;; Checks on the centre line before a build. Manual radius is filleted here.
;; Returns T to go on, nil to stop.
(defun rp:cl-ok (cl rc fac hw / obj pd msgs go)
  (if (> rc 0.0)
    (progn (setvar "FILLETRAD" rc) (command "_.FILLET" "_P" cl)))
  (setq obj  (vlax-ename->vla-object cl)
        pd   (rp:pldata obj)
        msgs (rp:cl-check (car pd) (cadr pd) (vlax-curve-isClosed obj) fac hw (rp:num "chst"))
        go   T)
  (foreach m msgs (princ (strcat "\n  Alignment check: " m)))
  (if (and (> rc 0.0) (vl-some '(lambda (m) (wcmatch m "sharp bend*")) msgs))
    (princ "\n  (the manual radius did not fit at those bends - segments too short for the radius)"))
  (if (vl-some '(lambda (m) (wcmatch m "SELF-INTERSECTION*")) msgs)
    (progn
      (initget "Yes No")
      (setq go (= (getkword "\nThe centre line crosses itself. Build the road anyway? [Yes/No] <No>: ") "Yes"))))
  go)

;;----------------------------------------------------------------------------
;;  Civil 3D alignment -> LWPOLYLINE.  Explodes a COPY of the alignment and
;;  joins its lines / arcs; falls back to sampling by station (PointLocation).
;;  *rp:c3dsta* = start station when it can be read.  NOT verified in
;;  Civil 3D in the development environment - see the user guide.
;;----------------------------------------------------------------------------
(defun rp:c3d-align (e / o cp mark new ss pl sta sta2 x pts ee nn r)
  (setq o (vlax-ename->vla-object e) *rp:c3dsta* nil)
  (setq sta (vl-catch-all-apply 'vlax-get-property (list o 'StartingStation)))
  (if (and (not (vl-catch-all-error-p sta)) (numberp sta)) (setq *rp:c3dsta* sta))
  (setq mark (entlast)
        cp   (vl-catch-all-apply 'vla-Copy (list o)))
  (if (and cp (not (vl-catch-all-error-p cp)))
    (progn
      (command "_.EXPLODE" (vlax-vla-object->ename cp))
      (while (> (getvar "CMDACTIVE") 0) (command ""))
      (setq new (rp:since mark) ss (ssadd))
      (foreach x new
        (if (entget x)
          (if (wcmatch (cdr (assoc 0 (entget x))) "LINE,ARC,LWPOLYLINE")
            (ssadd x ss)
            (entdel x))))
      (cond
        ((= (sslength ss) 0))
        ((and (= (sslength ss) 1) (= (cdr (assoc 0 (entget (ssname ss 0)))) "LWPOLYLINE"))
         (setq pl (ssname ss 0)))
        (T
         (setvar "PEDITACCEPT" 1)
         (command "_.PEDIT" "_M" ss "" "_J" "0.001" "")
         (setq pl (entlast))
         (if (/= (cdr (assoc 0 (entget pl))) "LWPOLYLINE") (setq pl nil))))))
  (if (and (null pl) *rp:c3dsta*)
    (progn
      (setq sta2 (vl-catch-all-apply 'vlax-get-property (list o 'EndingStation)) x *rp:c3dsta*)
      (if (and (not (vl-catch-all-error-p sta2)) (numberp sta2))
        (progn
          (while (<= x sta2)
            (setq ee nil nn nil
                  r  (vl-catch-all-apply 'vlax-invoke-method (list o 'PointLocation x 0.0 'ee 'nn)))
            (if (and (not (vl-catch-all-error-p r)) (numberp ee) (numberp nn)) (setq pts (cons (list ee nn) pts)))
            (setq x (if (and (< x sta2) (> (+ x 1.0) sta2)) sta2 (+ x 1.0))))
          (if (cdr pts)
            (progn
              (setq pl (vlax-vla-object->ename (rp:mkpl (mapcar '(lambda (p) (list p 0.0)) (reverse pts)) "0" 0.0 nil)))
              (princ "\n  Alignment sampled every 1 m - curves become short straights (use LandXML, RDLXI, for exact arcs).")))))))
  (if pl
    (princ (strcat "\n  Civil 3D alignment converted to a polyline"
                   (if *rp:c3dsta* (strcat ", start station " (rtos *rp:c3dsta* 2 3)) "") "."))
    (princ "\n  The Civil 3D alignment could not be converted. Export it as LandXML and use RDLXI, or explode it to a polyline."))
  pl)

;;----------------------------------------------------------------------------
;;  LandXML 1.2 alignment export / import
;;----------------------------------------------------------------------------
(defun rp:xml-esc (s)
  (foreach p '(("&" . "&amp;") ("<" . "&lt;") (">" . "&gt;") ("\"" . "&quot;"))
    (setq s (rp:str-replace s (car p) (cdr p))))
  s)

(defun rp:str-replace (s old new / i out)
  (setq out "")
  (while (setq i (vl-string-search old s))
    (setq out (strcat out (substr s 1 i) new) s (substr s (+ i 1 (strlen old)))))
  (strcat out s))

(defun rp:lx-pt (p fac) (strcat (rtos (/ (cadr p) fac) 2 4) " " (rtos (/ (car p) fac) 2 4)))

(defun rp:lx-date (/ cd s)
  (setq s (rtos (getvar "CDATE") 2 6))
  (list (strcat (substr s 1 4) "-" (substr s 5 2) "-" (substr s 7 2))
        (strcat (substr s 10 2) ":" (substr s 12 2) ":" (substr s 14 2))))

;; Write the centre line e as a LandXML 1.2 alignment. Returns the path or nil
(defun rp:lx-export (e path / data fac obj pd pts bul n i p0 p1 b d0 d1 st nm f th ch r ctr dt seg)
  (setq data (rp:xget e)
        fac  (if (> (atof (rp:xv "FAC" data)) 0.0) (atof (rp:xv "FAC" data)) (if (= (rp:val "units") "1") 1000.0 1.0))
        obj  (vlax-ename->vla-object e)
        pd   (rp:pldata obj) pts (car pd) bul (cadr pd) n (length pts)
        st   (if data (atof (rp:xv "CHST" data)) 0.0)
        nm   (if (and data (/= (rp:xv "NAME" data) "")) (rp:xv "NAME" data) "ALIGNMENT")
        dt   (rp:lx-date))
  (if (setq f (open path "w"))
    (progn
      (foreach l (list "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                       (strcat "<LandXML xmlns=\"http://www.landxml.org/schema/LandXML-1.2\" "
                               "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
                               "xsi:schemaLocation=\"http://www.landxml.org/schema/LandXML-1.2 http://www.landxml.org/schema/LandXML-1.2/LandXML-1.2.xsd\" "
                               "version=\"1.2\" date=\"" (car dt) "\" time=\"" (cadr dt) "\" readOnly=\"false\" language=\"English\">")
                       "  <Units>"
                       "    <Metric areaUnit=\"squareMeter\" linearUnit=\"meter\" volumeUnit=\"cubicMeter\" temperatureUnit=\"celsius\" pressureUnit=\"milliBars\" angularUnit=\"decimal degrees\" directionUnit=\"decimal degrees\"/>"
                       "  </Units>"
                       (strcat "  <Project name=\"" (rp:xml-esc (vl-filename-base (getvar "DWGNAME"))) "\"/>")
                       (strcat "  <Application name=\"RoadPro\" desc=\"Road builder for AutoCAD - Developed by https://www.exceltokml.com/\" manufacturer=\"exceltokml.com\" version=\"" *rp:ver* "\"/>")
                       "  <Alignments name=\"RoadPro\">"
                       (strcat "    <Alignment name=\"" (rp:xml-esc nm) "\" length=\""
                               (rtos (/ (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)) fac) 2 4)
                               "\" staStart=\"" (rtos st 2 4) "\" desc=\"RoadPro centre line\">")
                       "      <CoordGeom>")
        (write-line l f))
      (setq i 0)
      (repeat (if (vlax-curve-isClosed obj) n (1- n))
        (setq p0 (nth i pts) p1 (nth (rem (1+ i) n) pts) b (nth i bul)
              d0 (vlax-curve-getDistAtParam obj i) d1 (vlax-curve-getDistAtParam obj (1+ i)))
        (if (> (distance p0 p1) 1e-9)
          (if (< (abs b) 1e-9)
            (write-line (strcat "        <Line staStart=\"" (rtos (+ st (/ d0 fac)) 2 4) "\" length=\"" (rtos (/ (- d1 d0) fac) 2 4)
                                "\"><Start>" (rp:lx-pt p0 fac) "</Start><End>" (rp:lx-pt p1 fac) "</End></Line>") f)
            (progn
              (setq th  (* 4.0 (atan b))
                    ch  (distance p0 p1)
                    r   (/ ch (* 2.0 (sin (* 0.5 (abs th)))))
                    ctr (polar p0 (+ (- (angle p0 p1) (* 0.5 th)) (if (> b 0) (* 0.5 pi) (* -0.5 pi))) r))
              (write-line (strcat "        <Curve rot=\"" (if (> b 0) "ccw" "cw") "\" crvType=\"arc\" radius=\"" (rtos (/ r fac) 2 4)
                                  "\" length=\"" (rtos (/ (- d1 d0) fac) 2 4) "\" delta=\"" (rtos (* 180.0 (/ (abs th) pi)) 2 6)
                                  "\" staStart=\"" (rtos (+ st (/ d0 fac)) 2 4) "\"><Start>" (rp:lx-pt p0 fac)
                                  "</Start><Center>" (rp:lx-pt ctr fac) "</Center><End>" (rp:lx-pt p1 fac) "</End></Curve>") f))))
        (setq i (1+ i)))
      (foreach l '("      </CoordGeom>" "    </Alignment>" "  </Alignments>" "</LandXML>") (write-line l f))
      (close f)
      path)))

;; ---- tiny XML helpers (enough for LandXML alignments) ----
(defun rp:xml-attr (el nm / i j)
  (if (setq i (vl-string-search (strcat " " nm "=\"") el))
    (progn (setq i (+ i (strlen nm) 3) j (vl-string-search "\"" el i)) (substr el (1+ i) (- j i)))))

(defun rp:xml-child (el nm / i j k)
  (if (setq i (vl-string-search (strcat "<" nm) el))
    (progn
      (setq j (vl-string-search ">" el i)
            k (vl-string-search (strcat "</" nm ">") el j))
      (if (and j k) (substr el (+ j 2) (- k j 1))))))

(defun rp:xml-nums (s / out v)
  (while (and s (/= (setq s (vl-string-trim " \t\n" s)) ""))
    (setq v (vl-string-search " " s))
    (setq out (cons (atof (if v (substr s 1 v) s)) out) s (if v (substr s (+ v 2)) nil)))
  (reverse out))

(defun rp:lx-xy (s fac / v) (setq v (rp:xml-nums s)) (if (cadr v) (list (* fac (cadr v)) (* fac (car v)))))

;; next element of the CoordGeom string g from position p : (tag start end) or nil
(defun rp:lx-next (g p / best tag i j)
  (foreach tg '("Line" "Curve" "Spiral")
    (if (and (setq i (vl-string-search (strcat "<" tg) g p)) (or (null best) (< i (car best))))
      (setq best (list i tg))))
  (if best
    (progn
      (setq tag (cadr best) i (car best)
            j   (vl-string-search (strcat "</" tag ">") g i))
      (if (null j) (setq j (vl-string-search "/>" g i)))
      (list tag i (+ j (strlen tag) 3)))))

;; Read all alignments of a LandXML file as polylines. Returns ((ename name sta) ...)
(defun rp:lx-import (path / f s l fac a i j al nm sta g p el tg pts bul st en c rot a0 a1 sw warn out lay o)
  (setq fac (if (= (rp:val "units") "1") 1000.0 1.0) s "")
  (if (setq f (open path "r"))
    (progn
      (while (setq l (read-line f)) (setq s (strcat s l " ")))
      (close f)
      (if (and (vl-string-search "linearUnit=\"foot\"" s) (not (vl-string-search "linearUnit=\"meter\"" s)))
        (setq warn (cons "the file is in feet - coordinates are read as they are" warn)))
      (rp:mklayer "ROAD-LANDXML" 140 nil 35)
      (setq p 0)
      (while (setq i (vl-string-search "<Alignment " s p))
        (setq j  (vl-string-search "</Alignment>" s i)
              al (substr s (1+ i) (- (+ j 12) i))
              p  (+ j 12)
              nm (rp:xml-attr al "name")
              sta (atof (if (rp:xml-attr al "staStart") (rp:xml-attr al "staStart") "0"))
              g  (rp:xml-child al "CoordGeom")
              pts nil bul nil a 0)
        (while (and g (setq el (rp:lx-next g a)))
          (setq tg (car el) a (caddr el)
                el (substr g (1+ (cadr el)) (- (caddr el) (cadr el)))
                st (rp:lx-xy (rp:xml-child el "Start") fac)
                en (rp:lx-xy (rp:xml-child el "End") fac))
          (if (and st en)
            (progn
              (if (null pts)
                (setq pts (list st) bul (list 0.0))
                (if (> (distance (car pts) st) (* 0.001 fac))
                  (setq warn (cons (strcat nm ": gap of " (rtos (/ (distance (car pts) st) fac) 2 3) " m between elements - joined") warn)
                        pts (cons st pts) bul (cons 0.0 bul))))
              (cond
                ((= tg "Curve")
                 (setq c   (rp:lx-xy (rp:xml-child el "Center") fac)
                       rot (rp:xml-attr el "rot"))
                 (if c
                   (progn
                     (setq a0 (angle c st) a1 (angle c en)
                           sw (if (= rot "cw")
                                (- (rem (+ (- a0 a1) (* 4.0 pi)) (* 2.0 pi)))
                                (rem (+ (- a1 a0) (* 4.0 pi)) (* 2.0 pi))))
                     (setq bul (cons (/ (sin (* 0.25 sw)) (cos (* 0.25 sw))) (cdr bul))))))
                ((= tg "Spiral")
                 (setq warn (cons (strcat nm ": spiral replaced by a straight chord") warn))))
              (setq pts (cons en pts) bul (cons 0.0 bul)))))
        (if (cdr pts)
          (progn
            (setq o (rp:mkpl (mapcar 'list (reverse pts) (reverse bul)) "ROAD-LANDXML" 0.0 nil))
            (setq out (cons (list (vlax-vla-object->ename o) nm sta) out))))))
    (setq warn (cons (strcat "cannot open " path) warn)))
  (foreach w (reverse warn) (princ (strcat "\n  LandXML: " w)))
  (reverse out))

;;----------------------------------------------------------------------------
;;  Radius edit and rebuild
;;----------------------------------------------------------------------------
(defun rp:subst-nth (i v lst / k out)
  (setq k 0)
  (foreach x lst (setq out (cons (if (= k i) v x) out) k (1+ k)))
  (reverse out))

;; Remove zero-length segments : vertex k+1 equal to vertex k
(defun rp:pl-clean (pts bul / out ob k p q)
  (setq k 0)
  (while pts
    (setq p (car pts) q (cadr pts))
    (if (and q (< (distance p q) 1e-7))
      (setq pts (cdr pts) bul (cons (cadr bul) (cddr bul)))   ; drop vertex k+1, keep the following bulge
      (setq out (cons p out) ob (cons (car bul) ob) pts (cdr pts) bul (cdr bul))))
  (list (reverse out) (reverse ob)))

;; Re-fit arc segment i of a vertex list to radius r between its two tangents.
;; Returns (pts bul) or an error text.
(defun rp:fit-radius (pts bul closed i r / n ia ic id pa pb pc pd ip th tl la lb u1 u2 tn crs)
  (setq n (length pts) ia (1- i) ic (1+ i) id (+ i 2))
  (if closed (setq ia (rem (+ ia n) n) ic (rem ic n) id (rem id n)))
  (cond
    ((or (< i 0) (>= i (length bul)) (< (abs (nth i bul)) 1e-9)) "This segment is a straight line, not a curve.")
    ((or (< ia 0) (>= id n))
     "The curve is at the start or end of the centre line - it needs a straight on both sides.")
    ((> (abs (nth ia bul)) 1e-9) "The curve joins the curve before it directly (compound / reverse curve) - not supported.")
    ((> (abs (nth ic bul)) 1e-9) "The curve joins the curve after it directly (compound / reverse curve) - not supported.")
    ((<= r 0.0) "The radius must be greater than zero.")
    (T
     (setq pa (nth ia pts) pb (nth i pts) pc (nth ic pts) pd (nth id pts)
           ip (inters pa pb pc pd nil)
           th (* 4.0 (atan (abs (nth i bul)))))
     (if (null ip)
       "The two tangents are parallel - the curve cannot be fitted."
       (progn
         ;; the deflection is taken from the two tangents, so the new curve is
         ;; always tangent to both straights (even if the old one was not)
         (setq u1 (rp:unitv (list (- (car ip) (car pa)) (- (cadr ip) (cadr pa))))
               u2 (rp:unitv (list (- (car pd) (car ip)) (- (cadr pd) (cadr ip))))
               crs (- (* (car u1) (cadr u2)) (* (cadr u1) (car u2)))
               th (abs (rp:angdiff (angle '(0.0 0.0) u1) (angle '(0.0 0.0) u2)))
               tn (/ (sin (* 0.5 th)) (cos (* 0.5 th)))
               tl (* r tn)
               la (distance pa ip)
               lb (distance ip pd))
         (cond
           ((< th 1e-6) "The straights on both sides are in line - there is no bend to fit a curve to.")
           ((/= (if (> crs 0.0) 1 -1) (if (> (nth i bul) 0.0) 1 -1))
            "The curve does not turn the same way as its tangents - edit the centre line by hand.")
           ((> tl (+ la 1e-6))
            (strcat "Radius too large: the curve would run back past the previous point. Largest radius here: "
                    (rtos (/ la tn) 2 3) " (drawing units)."))
           ((> tl (+ lb 1e-6))
            (strcat "Radius too large: the curve would run past the next point. Largest radius here: "
                    (rtos (/ lb tn) 2 3) " (drawing units)."))
           (T
            (setq pts (rp:subst-nth i  (list (- (car ip) (* tl (car u1))) (- (cadr ip) (* tl (cadr u1)))) pts)
                  pts (rp:subst-nth ic (list (+ (car ip) (* tl (car u2))) (+ (cadr ip) (* tl (cadr u2)))) pts)
                  bul (rp:subst-nth i (* (if (> crs 0.0) 1.0 -1.0) (/ (sin (* 0.25 th)) (cos (* 0.25 th)))) bul))
            (rp:pl-clean pts bul))))))))

;; Write vertices and bulges back to a polyline object
(defun rp:pl-set (obj pts bul / fl i)
  (foreach p pts (setq fl (append fl (list (float (car p)) (float (cadr p))))))
  (vla-put-Coordinates obj
    (vlax-make-variant (vlax-safearray-fill (vlax-make-safearray vlax-vbDouble (cons 0 (1- (length fl)))) fl)))
  (setq i 0)
  (foreach b bul (vla-SetBulge obj i b) (setq i (1+ i)))
  (princ))

(defun rp:keep-layer-p (en / ly)
  (setq ly (strcase (cdr (assoc 8 (entget en)))))
  (or (= ly "ROAD-REPORT") (wcmatch ly "ROAD-XSEC*") (and (= ly "ROAD-CL") (rp:xget en))))

;; Objects of road e (not its CL, not report tables / sections, not other CLs)
(defun rp:road-objects (e / obj hs en out data fac hw dmax ss i p q ly bb mn mx)
  (setq obj (vlax-ename->vla-object e)
        hs  (append (vlax-ldata-get obj "ROADPRO_ALL") (vlax-ldata-get obj "ROADPRO_MKMAN") (vlax-ldata-get obj "ROADPRO_CORR")))
  (if hs
    (foreach h hs
      (if (and (setq en (handent h)) (entget en) (not (eq en e)) (not (rp:keep-layer-p en)) (not (member en out)))
        (setq out (cons en out))))
    (progn
      ;; road built before v3.4 : objects on ROAD-* layers close to the centre line
      (setq data (rp:xget e)
            fac  (if (> (atof (rp:xv "FAC" data)) 0.0) (atof (rp:xv "FAC" data)) 1.0)
            hw   (* 0.5 fac (atof (rp:xv "W" data)))
            dmax (+ hw (* fac (+ (atof (rp:xv "BGAP" data)) (atof (rp:xv "BWID" data)) 20.0)))
            ss   (ssget "_X" '((8 . "ROAD-*")))
            i    0)
      (if ss
        (repeat (sslength ss)
          (setq en (ssname ss i) i (1+ i))
          (if (and (not (eq en e)) (not (rp:keep-layer-p en)))
            (progn
              (setq bb (vl-catch-all-apply 'vla-GetBoundingBox (list (vlax-ename->vla-object en) 'mn 'mx)))
              (if (not (vl-catch-all-error-p bb))
                (progn
                  (setq mn (vlax-safearray->list mn) mx (vlax-safearray->list mx)
                        p  (list (* 0.5 (+ (car mn) (car mx))) (* 0.5 (+ (cadr mn) (cadr mx))) (vla-get-Elevation obj))
                        q  (vlax-curve-getClosestPointTo e p))
                  (if (< (distance (rp:p2 p) (rp:p2 q)) dmax) (setq out (cons en out)))))))))
      (if out
        (progn
          (initget "Yes Select No")
          (setq p (getkword (strcat "\nRoad built before v3.4: " (itoa (length out)) " objects within "
                                    (rtos (/ dmax fac) 2 1) " m of the centre line will be replaced. [Yes/Select/No] <Yes>: ")))
          (cond ((= p "No") (setq out nil))
                ((= p "Select")
                 (setq out nil ss (ssget '((8 . "ROAD-*"))) i 0)
                 (if ss (repeat (sslength ss) (setq en (ssname ss i) i (1+ i))
                          (if (and (not (eq en e)) (not (rp:keep-layer-p en))) (setq out (cons en out)))))))))))
  out)

;; Settings of an older road (no stored snapshot) : current settings + road data
(defun rp:snapshot-from-xdata (data / s fac)
  (setq s (rp:snapshot) fac (atof (rp:xv "FAC" data)))
  (foreach p (list (cons "rname" (rp:xv "NAME" data)) (cons "width" (rp:xv "W" data))
                   (cons "chst" (rp:xv "CHST" data)) (cons "chint" (rp:xv "CHINT" data))
                   (cons "blen" (rp:xv "BLEN" data)) (cons "bwid" (rp:xv "BWID" data)) (cons "bgap" (rp:xv "BGAP" data))
                   (cons "bl" (rp:xv "EL" data)) (cons "br" (rp:xv "ER" data)) (cons "etype" (rp:xv "ETYPE" data))
                   (cons "ctype" (rp:xv "CTYPE" data)) (cons "speed" (rp:xv "SPEED" data)) (cons "twoway" (rp:xv "TWOWAY" data))
                   (cons "cmark" (rp:xv "CMARK" data)) (cons "sset" (rp:xv "SSET" data))
                   (cons "endst" (cond ((= (rp:xv "ENDS" data) "-") "2") ((/= (rp:xv "ENDS" data) "") (rp:xv "ENDS" data)) (T "0")))
                   (cons "endfn" (cond ((= (rp:xv "ENDF" data) "-") "2") ((/= (rp:xv "ENDF" data) "") (rp:xv "ENDF" data)) (T "0")))
                   (cons "units" (if (= fac 1000.0) "1" "0"))
                   '("ccarr" . "0") '("clmode" . "0") '("cmed" . "0")
                   '("cswl" . "0") '("cswr" . "0") '("cwkl" . "0") '("cwkr" . "0")
                   '("cdrl" . "0") '("cdrr" . "0") '("cutl" . "0") '("cutr" . "0"))
    (if (/= (cdr p) "") (setq s (cons p (vl-remove-if '(lambda (x) (= (car x) (car p))) s)))))
  s)

;; Rebuild road e from its centre line as it is now, with snapshot snap
;; (nil = the road's stored settings). Returns T when rebuilt.
(defun rp:rebuild (e snap / obj data nw nt nj go lst res k)
  (setq obj  (vlax-ename->vla-object e)
        data (rp:xget e))
  (if (null snap) (setq snap (vlax-ldata-get obj "ROADPRO_SET")))
  (if (null snap) (setq snap (rp:snapshot-from-xdata data)))
  (setq nw (length (vlax-ldata-get obj "ROADPRO_WIDEN"))
        nt (length (vlax-ldata-get obj "ROADPRO_TAPERS"))
        nj (length (vlax-ldata-get obj "ROADPRO_JUNC"))
        go T)
  (if (> (+ nw nt nj) 0)
    (progn
      (princ (strcat "\n  This road has " (itoa nw) " lane widening(s), " (itoa nt) " taper(s) and " (itoa nj) " junction(s)."
                     "\n  The rebuild draws the road again without them - apply them again afterwards with RDW / RDT / RDJ"
                     "\n  (chainages along the centre line may have moved). Junction branch roads are removed with the junction;"
                     "\n  their centre lines stay - run RDJ again and select them."))
      (initget "Yes No")
      (setq go (= (getkword "\nRebuild the road now? [Yes/No] <No>: ") "Yes"))))
  (if go
    (progn
      (setq lst (rp:road-objects e))
      (foreach x lst (if (entget x) (entdel x)))
      (foreach k (vlax-ldata-list obj)
        (if (and (wcmatch (strcase (car k)) "ROADPRO_*") (/= (strcase (car k)) "ROADPRO_SET"))
          (vlax-ldata-delete obj (car k))))
      (setq *rp:presetcl* e
            res (rp:with-settings (append snap '(("rmode" . "0") ("report" . "0") ("xsec" . "0") ("keep" . "0"))) 'rp:run)
            *rp:presetcl* nil)
      (if (vl-catch-all-error-p res)
        (progn (princ (strcat "\n** Rebuild failed: " (vl-catch-all-error-message res) " - type U to undo.")) nil)
        (progn
          (princ (strcat "\n  Road rebuilt (" (itoa (length lst)) " old objects replaced)."
                         " Report tables and cross sections drawn earlier are out of date - run RDR / RDX again."))
          T)))))

(defun rp:pick-road (msg / sel)
  (while (and (setq sel (entsel msg)) (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  sel)

;;----------------------------------------------------------------------------
;;  Commands (v3.4)
;;----------------------------------------------------------------------------
;; Edit the radius of a curve after the road is built, then rebuild the road
(defun c:ROADEDITRADIUS (/ sel e obj data fac hw st curves cp d k i bd dd c r all tg pd pts bul res bad cv ix)
  (rp:start) (rp:space) (rp:world) (rp:linetypes) (rp:layers)
  (if (setq sel (rp:pick-road "\nSelect the road centre line ON the curve to change (layer ROAD-CL): "))
    (progn
      (setq e    (car sel)
            obj  (vlax-ename->vla-object e)
            data (rp:xget e)
            fac  (if (> (atof (rp:xv "FAC" data)) 0.0) (atof (rp:xv "FAC" data)) 1.0)
            hw   (* 0.5 fac (atof (rp:xv "W" data)))
            st   (atof (rp:xv "CHST" data))
            *rp:len* (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
            curves (rp:curves obj))
      (if (null curves)
        (princ "\n  This road has no curves (arc segments) to edit.")
        (progn
          (setq cp (vlax-curve-getClosestPointTo obj (trans (cadr sel) 1 0))
                d  (vlax-curve-getDistAtPoint obj cp)
                i  0 k 1 bd 1e99)
          (foreach c curves
            (setq i  (1+ i)
                  dd (cond ((< d (car c)) (- (car c) d)) ((> d (cadr c)) (- d (cadr c))) (T 0.0)))
            (if (< dd bd) (setq bd dd k i)))
          (setq c (nth (1- k) curves))
          (princ (strcat "\n  Curve C" (itoa k) " : R (CL) = " (rtos (/ (nth 2 c) fac) 2 3) " m,  deflection "
                         (rp:dms (nth 3 c) T) ",  CH " (rp:chfmt (+ st (/ (car c) fac))) " - " (rp:chfmt (+ st (/ (cadr c) fac)))))
          (initget 6 "Inner All")
          (setq r (getdist (strcat "\nNew radius at the CENTRE LINE for C" (itoa k) " [Inner edge/All curves] <"
                                   (rtos (/ (nth 2 c) fac) 2 3) ">: ")))
          (setq tg (list k))
          (cond
            ((= r "All")
             (setq tg nil i 0)
             (foreach c curves (setq i (1+ i) tg (cons i tg)))
             (initget 7)
             (setq r (getdist "\nNew radius at the CENTRE LINE for ALL curves: ")))
            ((= r "Inner")
             (initget 7)
             (if (setq r (getdist (strcat "\nNew radius at the INNER EDGE (kerb line) for C" (itoa k) ": ")))
               (setq r (+ r (/ hw fac)))))
            ((null r) (setq r (/ (nth 2 c) fac))))
          (cond
            ((null r) (princ "\n  Nothing changed."))
            ((<= (* r fac) hw)
             (alert (strcat "The radius must be larger than half the road width (" (rtos (/ hw fac) 2 2) " m).\n\nNothing changed.")))
            (T
             (setq pd (rp:pldata obj) pts (car pd) bul (cadr pd))
             ;; last curve first so vertex numbers stay valid
             (foreach ix (vl-sort tg '>)
               (if (not bad)
                 (progn
                   (setq cv (nth (1- ix) curves)
                         i  (fix (vlax-curve-getParamAtDist obj (* 0.5 (+ (car cv) (cadr cv)))))
                         res (rp:fit-radius pts bul (vlax-curve-isClosed obj) i (* r fac)))
                   (if (= (type res) 'STR)
                     (setq bad (strcat "Curve C" (itoa ix) ": " res))
                     (setq pts (car res) bul (cadr res))))))
             (if bad
               (alert (strcat bad "\n\nNothing changed."))
               (progn
                 (if (< (* r fac) (+ hw (* fac (+ (atof (rp:xv "BGAP" data)) (atof (rp:xv "BWID" data))))))
                   (princ "\n  Warning: the edge treatment on the inside of the bend is tighter than the radius."))
                 (rp:pl-set obj pts bul)
                 (princ (strcat "\n  Radius set to " (rtos r 2 3) " m at the centre line for "
                                (if (cdr tg) (strcat (itoa (length tg)) " curves") (strcat "C" (itoa k))) "."))
                 (if (not (rp:rebuild e nil))
                   (princ "\n  The centre line was changed but the road was not rebuilt - run RDB (ROADREBUILD) when ready."))))))))))
  (rp:finish))

;; Rebuild a road after its centre line was edited (grips, Properties, PEDIT ...)
(defun c:ROADREBUILD (/ sel)
  (rp:start) (rp:space) (rp:world) (rp:linetypes) (rp:layers)
  (if (setq sel (rp:pick-road "\nSelect the edited road centre line (layer ROAD-CL): "))
    (rp:rebuild (car sel) nil))
  (rp:finish))

;; Change lanes / median / sidewalks / drains / utilities of an existing road
(defun c:ROADCORRIDOR (/ sel e obj data snap old new pl0 pl1 fac res w)
  (rp:start) (rp:space) (rp:world) (rp:linetypes) (rp:layers)
  (if (setq sel (rp:pick-road "\nSelect the road centre line (layer ROAD-CL): "))
    (progn
      (setq e (car sel) obj (vlax-ename->vla-object e) data (rp:xget e)
            snap (vlax-ldata-get obj "ROADPRO_SET"))
      (if (null snap) (setq snap (rp:snapshot-from-xdata data)))
      (setq w (atof (cdr (assoc "width" snap))))
      (setq *rp:cset* snap *rp:cpar* (list (cons "width" (cdr (assoc "width" snap)))))
      (setq pl0 (rp:lane-plan w))
      (setq res (rp:cdialog (strcat "Road " (rp:xv "NAME" data) " - changes apply to this road (and become the defaults for new roads).")))
      (setq *rp:cpar* nil)
      (if (= res 'ok)
        (progn
          ;; new snapshot = road settings with the corridor keys from the dialog
          (setq new (append (mapcar '(lambda (k) (cons k (rp:val k))) *rp:ckeys*)
                            (vl-remove-if '(lambda (p) (member (car p) *rp:ckeys*)) snap)))
          (setq *rp:cset* new pl1 (rp:lane-plan w) *rp:cset* nil)
          (if (and (equal (car pl0) (car pl1) 1e-6) (equal (cdr (reverse pl0)) (cdr (reverse pl1)) 1e-6)
                   (= (cdr (assoc "cmed" snap)) (cdr (assoc "cmed" new))))
            (progn
              ;; same road width and lanes : targeted update of the corridor only
              (vlax-ldata-put obj "ROADPRO_SET" new)
              (rp:corr-run e)
              (if (vlax-ldata-get obj "ROADPRO_MKMAN") (rp:mark-run e))
              (princ "\n  Corridor updated (sidewalks, walkways, drains, utilities, hatch). Run RDR / RDX to refresh the report and sections."))
            (progn
              (princ (strcat "\n  Lanes / median changed: road width " (rtos (car pl0) 2 2) " m -> " (rtos (car pl1) 2 2) " m."))
              (rp:rebuild e new))))
        (setq *rp:cset* nil))))
  (rp:finish))

;; Regenerate corridor + markings of a road (after edits made outside RoadPro)
(defun c:ROADUPDATE (/ sel e obj)
  (rp:start) (rp:space) (rp:world) (rp:linetypes) (rp:layers)
  (if (setq sel (rp:pick-road "\nSelect the road centre line (layer ROAD-CL): "))
    (progn
      (setq e (car sel) obj (vlax-ename->vla-object e))
      (setq *rp:cset* (vlax-ldata-get obj "ROADPRO_SET"))
      (if (and (vlax-ldata-get obj "ROADPRO_SET") (rp:corr-any))
        (progn (rp:corr-run e) (princ "\n  Corridor regenerated."))
        (princ "\n  This road has no corridor items (median / sidewalks / walkways / drains / utilities) - use RDC to add them."))
      (setq *rp:cset* nil)
      (if (vlax-ldata-get obj "ROADPRO_MKMAN") (progn (rp:mark-run e) (princ "\n  Road markings regenerated.")))))
  (rp:finish))

;; LandXML export of a road centre line (Civil 3D : Insert > LandXML)
(defun c:ROADLANDXML (/ sel e data path nm)
  (rp:start)
  (while (and (setq sel (entsel "\nSelect the road centre line or a polyline to export: "))
              (/= (cdr (assoc 0 (entget (car sel)))) "LWPOLYLINE"))
    (princ "\n  Select a 2D polyline (a RoadPro centre line is a polyline)."))
  (if sel
    (progn
      (setq e (car sel) data (rp:xget e)
            nm (if (and data (/= (rp:xv "NAME" data) "")) (rp:xv "NAME" data) "ALIGNMENT")
            path (strcat (getvar "DWGPREFIX") (vl-string-translate "\\/:*?\"<>| " "__________" nm) "_Alignment.xml"))
      (if (rp:lx-export e path)
        (princ (strcat "\n  LandXML 1.2 alignment saved : " path
                       "\n  In Civil 3D : Insert > LandXML (or LANDXMLIN), tick the alignment."))
        (princ (strcat "\n  Could not write " path " - is the file open?")))))
  (rp:finish))

;; LandXML import : every alignment of the file becomes a polyline (layer ROAD-LANDXML)
(defun c:ROADLANDXMLIN (/ path res)
  (rp:start) (rp:space) (rp:world) (rp:layers)
  (if (setq path (getfiled "Select a LandXML file" (getvar "DWGPREFIX") "xml" 0))
    (progn
      (setq res (rp:lx-import path))
      (foreach r res
        (princ (strcat "\n  Alignment " (cadr r) " imported, start station " (rtos (caddr r) 2 3)
                       " - build it with RDP (Centre line input: Select existing) and Start chainage " (rtos (caddr r) 2 3) ".")))
      (if (null res) (princ "\n  No alignment found in the file."))))
  (rp:finish))

(defun c:RDC   () (c:ROADCORRIDOR))
(defun c:RDU   () (c:ROADUPDATE))
(defun c:RDER  () (c:ROADEDITRADIUS))
(defun c:RDB   () (c:ROADREBUILD))
(defun c:RDLX  () (c:ROADLANDXML))
(defun c:RDLXI () (c:ROADLANDXMLIN))

;; Refresh markings + corridor of a road after RDW / RDT changed its edges
(defun rp:refresh (e / obj)
  (setq obj (vlax-ename->vla-object e))
  (if (vlax-ldata-get obj "ROADPRO_MKMAN") (rp:mark-run e))
  (rp:refresh-corr e)
  (rp:track e *rp:mk0*))

(defun rp:refresh-corr (e / obj)
  (setq obj (vlax-ename->vla-object e) *rp:cset* (vlax-ldata-get obj "ROADPRO_SET"))
  (if (and *rp:cset* (rp:corr-any)) (rp:corr-run e))
  (setq *rp:cset* nil))

;;----------------------------------------------------------------------------
;;  SINGLE LINE (RDL) : barricades, traffic cones or kerb stone along any
;;  line, polyline, arc or spline - on the line, offset left / right, or both
;;----------------------------------------------------------------------------
(setq *rp:ldefaults*
  '(("ltype" . "0") ("lside" . "0") ("loff" . "0.50") ("llen" . "2.00") ("lwid" . "0.50")
    ("lfrom" . "0") ("lto" . "0") ("llab" . "1")))
(setq *rp:lkeys*    (mapcar 'car *rp:ldefaults*)
      *rp:defaults* (append *rp:defaults* *rp:ldefaults*))

(setq *rp:ldcl*
 (list
  "roadline : dialog {"
  "  label = \"ROAD PRO  -  Single Line (barricades / cones / kerb stone)\";"
  "  : text { key = \"info\"; width = 60; }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"What to place\";"
  "      : popup_list { key = \"ltype\"; label = \"Type:\";      edit_width = 24; }"
  "      : popup_list { key = \"lside\"; label = \"Placement:\"; edit_width = 24; }"
  "      : edit_box   { key = \"loff\";  label = \"Offset from the line (m):\";        edit_width = 7; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Size and range\";"
  "      : edit_box { key = \"llen\";  label = \"Unit length / cone spacing (m):\"; edit_width = 7; }"
  "      : edit_box { key = \"lwid\";  label = \"Unit / cone / kerb width (m):\";   edit_width = 7; }"
  "      : edit_box { key = \"lfrom\"; label = \"From distance along line (m):\";  edit_width = 7; }"
  "      : edit_box { key = \"lto\";   label = \"To distance (m, 0 = line end):\"; edit_width = 7; }"
  "      : toggle   { key = \"llab\";  label = \"Quantity label on the drawing\"; }"
  "    }"
  "  }"
  "  : text { label = \"Left / right are seen looking along the line from its start point.\"; }"
  "  : text { label = \"Developed by https://www.exceltokml.com/\"; alignment = right; }"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:ldlg-modes ()
  (mode_tile "loff" (if (= (get_tile "lside") "0") 1 0)))

(defun rp:ldlg-accept (/ bad v)
  (foreach k '(("llen" "Unit length / spacing" 0) ("lwid" "Width" 0) ("loff" "Offset" 1)
               ("lfrom" "From distance" 1) ("lto" "To distance" 1))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (if (= (caddr k) 1) (< v 0.0) (<= v 0.0))) (setq bad k)))))
  (cond
    (bad
     (set_tile "error" (strcat (cadr bad) (if (= (caddr bad) 1) " must be zero or a positive number."
                                             " must be a number greater than zero.")))
     (mode_tile (car bad) 2))
    ((and (> (rp:dist (get_tile "lto")) 0.0) (<= (rp:dist (get_tile "lto")) (rp:dist (get_tile "lfrom"))))
     (set_tile "error" "To distance must be greater than From distance, or 0 for the line end.")
     (mode_tile "lto" 2))
    (T (foreach k *rp:lkeys* (rp:set k (get_tile k))) (done_dialog 1))))

(defun rp:ldialog (info / fn f id res)
  (setq fn (vl-filename-mktemp "roadline.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:ldcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadline" id))
        (progn
          (rp:fill "ltype" '("Barricades (red / white)" "Traffic cones" "Kerb stone"))
          (rp:fill "lside" '("On the line (centred)" "Offset to the left" "Offset to the right" "Both sides"))
          (foreach k *rp:lkeys* (set_tile k (rp:val k)))
          (set_tile "info" info)
          (rp:ldlg-modes)
          (action_tile "lside" "(rp:ldlg-modes)")
          (action_tile "accept" "(rp:ldlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; Place the run on one curve, returns (red white cones kerb-m)
(defun rp:line-run (o fac elev / len a b w off sides tot r sub ip mt txt an)
  (setq len  (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o))
        a    (* fac (rp:num "lfrom"))
        b    (if (> (rp:num "lto") 0.0) (min len (* fac (rp:num "lto"))) len)
        w    (* fac (rp:num "lwid"))
        off  (* fac (rp:num "loff"))
        tot  (list 0 0 0 0.0))
  (if (>= a b)
    (progn (princ "\n  Range is outside this line - skipped.") tot)
    (progn
      ;; work on a copy trimmed to the range, so units start at the From distance
      (setq sub (if (or (> a 1e-6) (< b (- len 1e-6))) (rp:subcurve o a b elev) o)
            len (vlax-curve-getDistAtParam sub (vlax-curve-getEndParam sub))
            *rp:len* len)
      (foreach sd (cond ((= (rp:val "lside") "1") '(1.0)) ((= (rp:val "lside") "2") '(-1.0))
                        ((= (rp:val "lside") "3") '(1.0 -1.0)) (T '(0.0)))
        (setq r (if (= sd 0.0)
                  (rp:edge-run sub len (* -0.5 w) (* 0.5 w) (rp:val "ltype") (* fac (rp:num "llen")) fac elev)
                  (rp:edge-run sub len (* sd off) (* sd (+ off w)) (rp:val "ltype") (* fac (rp:num "llen")) fac elev))
              tot (list (+ (car tot) (car r)) (+ (cadr tot) (cadr r)) (+ (caddr tot) (caddr r)) (+ (cadddr tot) (cadddr r)))))
      (if (rp:on "llab")
        (progn
          (setq txt (cond ((= (rp:val "ltype") "1") (strcat (itoa (caddr tot)) " TRAFFIC CONES"))
                          ((= (rp:val "ltype") "2") (strcat (rtos (/ (cadddr tot) fac) 2 1) " m KERB STONE"))
                          (T (strcat (itoa (+ (car tot) (cadr tot))) " BARRICADES (" (itoa (car tot)) " R / "
                                     (itoa (cadr tot)) " W)")))
                ip  (rp:offpt sub (* 0.5 len) (+ (if (= (rp:val "lside") "2") (- (+ off w)) (+ off w)) (* 1.5 fac)))
                mt  (rp:text txt ip (* 0.8 fac (rp:num "txth")) "ROAD-JUNCTION" elev))
          (setq an (angle '(0.0 0.0) (caddr (rp:frame sub (* 0.5 len)))))
          (vla-put-Rotation mt (if (and (> an (* 0.5 pi)) (<= an (* 1.5 pi))) (+ an pi) an))))
      (if (not (eq sub o)) (vla-Delete sub))
      tot)))

;; Copy of curve o between distances a and b (as a lightweight polyline)
(defun rp:subcurve (o a b elev / n i pts d)
  (setq n (max 2 (fix (+ 1.0 (/ (- b a) (* 0.25 *rp:lfac*)))))
        n (min n 4000) i 0)
  (repeat (1+ n)
    (setq d (+ a (* (- b a) (/ (float i) n)))
          pts (cons (list (rp:p2 (vlax-curve-getPointAtDist o (min d (vlax-curve-getDistAtParam o (vlax-curve-getEndParam o))))) 0.0) pts)
          i (1+ i)))
  (rp:mkpl (reverse pts) "ROAD-JUNCTION" elev nil))

(defun c:ROADLINE (/ ss res fac i o tot r elev)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (setq fac (if (= (rp:val "units") "1") 1000.0 1.0)
        *rp:lfac* fac
        *rp:hatches* nil
        tot (list 0 0 0 0.0))
  (princ "\nSelect lines, polylines, arcs or splines for the single line run: ")
  (if (setq ss (ssget '((0 . "LINE,LWPOLYLINE,POLYLINE,ARC,SPLINE,CIRCLE,ELLIPSE"))))
    (progn
      (setq res (rp:ldialog (strcat (itoa (sslength ss)) " object(s) selected   |   drawing units : "
                                    (if (= fac 1.0) "metres" "millimetres") " (set in RDP)")))
      (if (= res 'fail) (princ "\nDialog not available - using saved single line settings."))
      (if (/= res 'cancel)
        (progn
          (setq i 0)
          (repeat (sslength ss)
            (setq o    (vlax-ename->vla-object (ssname ss i))
                  elev (if (vlax-property-available-p o 'Elevation) (vla-get-Elevation o) 0.0)
                  r    (rp:line-run o fac elev)
                  tot  (list (+ (car tot) (car r)) (+ (cadr tot) (cadr r)) (+ (caddr tot) (caddr r)) (+ (cadddr tot) (cadddr r)))
                  i    (1+ i)))
          (if *rp:hatches* (rp:toback *rp:hatches*))
          (princ "\n================ ROAD PRO - SINGLE LINE ================")
          (if (> (+ (car tot) (cadr tot)) 0)
            (princ (strcat "\n  Barricade units : " (itoa (+ (car tot) (cadr tot))) "  (" (itoa (car tot)) " red / "
                           (itoa (cadr tot)) " white)")))
          (if (> (caddr tot) 0) (princ (strcat "\n  Traffic cones   : " (itoa (caddr tot)))))
          (if (> (cadddr tot) 0.0) (princ (strcat "\n  Kerb stone      : " (rtos (/ (cadddr tot) fac) 2 1) " m")))
          (princ "\n  Type U to undo this run in one step.")
          (princ "\n======================================================="))
        (princ "\nSingle line cancelled.")))
    (princ "\nNothing selected."))
  (rp:finish))

(defun c:RDL () (c:ROADLINE))

;;----------------------------------------------------------------------------
;;  Commands
;;----------------------------------------------------------------------------
(defun c:ROADPRO (/ res)
  (rp:start)
  (setq res (rp:dialog))
  (if (= res 'fail)
    (progn
      (princ "\nDialog not available - using command line.")
      (rp:cmdline)
      (setq res 'ok)))
  (if (= res 'ok) (rp:run) (princ "\nRoad Pro cancelled."))
  (rp:finish))

(defun c:RDP () (c:ROADPRO))

(defun c:ROADREPORT (/ sel)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel (rp:report-make (car sel) T))
  (rp:finish))

(defun c:RDR () (c:ROADREPORT))

;; Add radius / TC / CT / curve data labels to an existing RoadPro road
(defun c:ROADRADIUS (/ sel e data fac obj hw n)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (setq *rp:hatches* nil)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq e    (car sel)
            data (rp:xget e)
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq obj      (vlax-ename->vla-object e)
            *rp:cset* (vlax-ldata-get obj "ROADPRO_SET")
            *rp:cinx* (if *rp:cset* (list (rp:corr-extra 1.0 fac (* fac (atof (rp:xv "BGAP" data))) (* fac (atof (rp:xv "BWID" data))))
                                          (rp:corr-extra -1.0 fac (* fac (atof (rp:xv "BGAP" data))) (* fac (atof (rp:xv "BWID" data))))))
            hw       (* 0.5 fac (atof (rp:xv "W" data)))
            *rp:len* (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
            n        (rp:curve-labels obj (rp:curves obj) hw fac (* fac (rp:num "txth"))
                                      (atof (rp:xv "CHST" data)) (vla-get-Elevation obj)
                                      (/= (rp:xv "BL" data) "0,0") (/= (rp:xv "BR" data) "0,0")
                                      (/= (atoi (rp:xv "NCHM" data)) 0)
                                      (* fac (atof (rp:xv "BGAP" data)))
                                      (* fac (atof (rp:xv "BWID" data)))
                                      (= (rp:xv "RREF" data) "1")))
      (rp:track e *rp:mk0*)
      (princ (strcat "\n  Radius labels added to " (itoa n) " curve(s) on layer ROAD-CURVE."))))
  (rp:finish))

(defun c:RDRAD () (c:ROADRADIUS))

;; Add straight-section labels to an existing RoadPro road
(defun c:ROADSECTIONS (/ sel e data fac obj hw n)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq e    (car sel)
            data (rp:xget e)
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq obj      (vlax-ename->vla-object e)
            hw       (* 0.5 fac (atof (rp:xv "W" data)))
            *rp:len* (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
            n        (rp:straight-labels
                       obj (rp:straights obj) hw fac (* fac (rp:num "txth"))
                       (atof (rp:xv "CHST" data)) (vla-get-Elevation obj)
                       (+ hw
                          (if (/= (rp:xv "BR" data) "0,0")
                            (* fac (+ (atof (rp:xv "BGAP" data)) (atof (rp:xv "BWID" data))))
                            0.0)
                          (* 0.5 fac) (* 0.6 fac) (* 1.5 fac (rp:num "signsz")))))
      (rp:track e *rp:mk0*)
      (princ (strcat "\n  " (itoa n) " straight section(s) labelled on layer ROAD-SECTION."))))
  (rp:finish))

(defun c:RDSEC () (c:ROADSECTIONS))

;; Cross section drawings of a RoadPro road
(defun c:ROADXSEC (/ sel res)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq res (rp:xdialog))
      (if (= res 'fail) (princ "\nDialog not available - using saved cross-section settings."))
      (if (/= res 'cancel)
        (rp:xsec-run (car sel) (rp:val "xmode"))
        (princ "\nCross section cancelled."))))
  (rp:finish))

(defun c:RDX () (c:ROADXSEC))

;; Lane widening on a RoadPro road
(defun c:ROADWIDEN (/ sel data fac len res)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq data (rp:xget (car sel))
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq len (vlax-curve-getDistAtParam (car sel) (vlax-curve-getEndParam (car sel))))
      (setq res (rp:wdialog (strcat "Road " (rp:xv "NAME" data) " :  CH "
                                    (rp:chfmt (atof (rp:xv "CHST" data))) "  to  "
                                    (rp:chfmt (+ (atof (rp:xv "CHST" data)) (/ len fac)))
                                    "   |   width " (rp:xv "W" data) " m")))
      (if (= res 'fail) (princ "\nDialog not available - using saved widening settings."))
      (if (/= res 'cancel)
        (rp:widen-run (car sel))
        (princ "\nLane widening cancelled."))))
  (rp:finish))

(defun c:RDW () (c:ROADWIDEN))

;; Road taper anywhere on a RoadPro road
(defun c:ROADTAPER (/ sel data fac len res)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq data (rp:xget (car sel))
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq len (vlax-curve-getDistAtParam (car sel) (vlax-curve-getEndParam (car sel))))
      (setq res (rp:tdialog (strcat "Road " (rp:xv "NAME" data) " :  CH "
                                    (rp:chfmt (atof (rp:xv "CHST" data))) "  to  "
                                    (rp:chfmt (+ (atof (rp:xv "CHST" data)) (/ len fac)))
                                    "   |   design width " (rp:xv "W" data) " m")))
      (if (= res 'fail) (princ "\nDialog not available - using saved taper settings."))
      (if (/= res 'cancel)
        (rp:taper-run (car sel))
        (princ "\nRoad taper cancelled."))))
  (rp:finish))

(defun c:RDT () (c:ROADTAPER))

;; Join a new road to an existing RoadPro road
(defun c:ROADJUNCTION (/ sel data fac len res)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (setq *rp:presetcl* nil)
  (while (and (setq sel (entsel "\nSelect the MAIN road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq data (rp:xget (car sel))
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq len (vlax-curve-getDistAtParam (car sel) (vlax-curve-getEndParam (car sel))))
      (setq res (rp:jdialog (strcat "Main road " (rp:xv "NAME" data) " :  CH "
                                    (rp:chfmt (atof (rp:xv "CHST" data))) "  to  "
                                    (rp:chfmt (+ (atof (rp:xv "CHST" data)) (/ len fac)))
                                    "   |   width " (rp:xv "W" data) " m")))
      (if (= res 'fail) (princ "\nDialog not available - using saved junction settings."))
      (if (/= res 'cancel)
        (rp:junction-run (car sel))
        (princ "\nRoad junction cancelled."))))
  (setq *rp:presetcl* nil)
  (rp:finish))

(defun c:RDJ () (c:ROADJUNCTION))

;; Road markings on any RoadPro road (draw again = refresh, or remove)
(defun c:ROADMARK (/ sel opt obj en)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (initget "Draw Remove")
      (setq opt (getkword "\nRoad markings [Draw/Remove] <Draw>: "))
      (if (= opt "Remove")
        (progn
          (setq obj (vlax-ename->vla-object (car sel)))
          (foreach hd (vlax-ldata-get obj "ROADPRO_MKMAN")
            (if (and (setq en (handent hd)) (entget en)) (entdel en)))
          (vlax-ldata-delete obj "ROADPRO_MKMAN")
          (vlax-ldata-delete obj "ROADPRO_MKQTY")
          (princ "\n  Road markings removed."))
        (rp:mark-run (car sel)))))
  (rp:finish))

(defun c:RDM () (c:ROADMARK))

(defun c:ROADPRORESET ()
  (foreach p *rp:defaults* (rp:set (car p) (cdr p)))
  (princ "\nRoad Pro settings restored to defaults (width 7.30 m, radius 10 m).")
  (princ))

(princ (strcat "\nRoad Pro v" *rp:ver* " loaded.  ROADPRO (RDP) = build road   |   ROADREPORT (RDR) = report   |   ROADRADIUS (RDRAD) = radius   |   ROADSECTIONS (RDSEC) = straights   |   ROADXSEC (RDX) = cross sections   |   ROADWIDEN (RDW) = lane widening   |   ROADTAPER (RDT) = road taper   |   ROADJUNCTION (RDJ) = junction / tie-in   |   ROADMARK (RDM) = road markings   |   ROADLINE (RDL) = single line   |   ROADCORRIDOR (RDC) = lanes / median / sidewalks / drains / utilities   |   ROADUPDATE (RDU) = regenerate corridor   |   ROADEDITRADIUS (RDER) = edit a curve radius   |   ROADREBUILD (RDB) = rebuild from edited CL   |   ROADLANDXML (RDLX) / ROADLANDXMLIN (RDLXI) = LandXML / Civil 3D"))
(princ "\nDeveloped by https://www.exceltokml.com/")
(princ)
