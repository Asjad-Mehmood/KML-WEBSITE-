;;;============================================================================
;;;  RoadPro.lsp  -  Professional Road Builder for AutoCAD
;;;  Version : 3.0                                   Date : 07-Oct-2026
;;;  Developed by https://www.exceltokml.com/
;;;  Chainage inputs accept plain metres (100) or chainage format (0+100).
;;;  RDW / RDT with Both sides : left and right can use different chainages
;;;  and a different fillet radius. Every fillet / taper radius is marked on plan.
;;;----------------------------------------------------------------------------
;;;  COMMANDS
;;;    ROADPRO    (or RDP) ..... build a complete road from a centre line
;;;    ROADREPORT (or RDR) ..... full report of any road built by RoadPro
;;;    ROADRADIUS (or RDRAD) ... add radius / TC / CT labels to a RoadPro road
;;;    ROADSECTIONS (or RDSEC) . add straight-section labels to a RoadPro road
;;;    ROADXSEC (or RDX) ....... CROSS SECTION drawings : typical, at one
;;;                              chainage, or at every chainage interval
;;;    ROADWIDEN (or RDW) ...... LANE WIDENING : extra lane from a start to
;;;                              an end chainage, with taper in / out,
;;;                              straight or curve (reverse-curve) taper,
;;;                              fillet at match points or direct link
;;;    ROADJUNCTION (or RDJ) ... ROAD JUNCTION / TIE-IN : join a new road to an
;;;                              existing RoadPro road, with kerb-return radii,
;;;                              opened edge, corner surface, barricades and
;;;                              turning-area road markings (stop / give way
;;;                              line, STOP word or triangle, turn arrow,
;;;                              broken edge line across the mouth)
;;;    ROADMARK (or RDM) ....... ROAD MARKINGS : white edge lines + lane line
;;;                              (broken 3 m / 6 m, solid on bends and at
;;;                              junction approaches), gaps at junctions,
;;;                              paint quantities in the report
;;;    ROADTAPER (or RDT) ...... ROAD TAPER : widen or narrow the road edge
;;;                              from any start to any end chainage; the
;;;                              new width continues to the road end. Add
;;;                              as many tapers as needed, anywhere.
;;;    ROADPRORESET ............ restore all settings to factory defaults
;;;
;;;  WHAT IT BUILDS
;;;    - Centre line (ROAD-CL) with a custom "-- CL --" linetype
;;;    - Left and right road edges at +/- half the road width (ROAD-EDGE)
;;;    - Automatic turning radius at every bend (default 10 m, asked first),
;;;      measured at the CENTRE LINE (default) or at the inner edge
;;;    - Road surface hatch (ROAD-SURFACE)
;;;    - Red / white barricades Left / Right / Centre, black outline
;;;    - Chainage ticks and labels, e.g. CH 0+020 (ROAD-CHAINAGE)
;;;    - RADIUS ON PLAN: radius line with arrow + R value at every bend,
;;;      centre mark, TC / CT ticks with chainage, curve data label
;;;      (R inner, R CL, arc length, deflection, area) (ROAD-CURVE)
;;;    - STRAIGHT SECTIONS ON PLAN: S1, S2 ... extent bar with end ticks,
;;;      length, area, bearing, from / to chainage (ROAD-SECTION)
;;;    - Report includes a ROAD SECTIONS table: every straight and curve
;;;      with chainage, length, edge lengths, area, bearing / radius
;;;    - SIGNAGE (traffic keeps right), each sign with post, plate facing
;;;      traffic, leader, symbol and ID tag SG-01, SG-02 ... :
;;;        Road works ahead (+ plate), speed limit, bend ahead left/right,
;;;        STOP or GIVE WAY at tie-ins, NO ENTRY (one-way), KEEP RIGHT at
;;;        the median, chevron boards on bends, ROAD CLOSED boards,
;;;        lane direction arrows on the carriageway (ROAD-MARKING)
;;;    - CROSS SECTIONS: crossfall / camber, pavement layers with
;;;      thickness, shoulders, subgrade, barricade profiles WITH HEIGHT
;;;      (water-filled or New Jersey), sign post with clearance height
;;;      and footing, centre line, crossfall arrows, full dimensions
;;;    - SIGN SCHEDULE (ID, sign, chainage, side, facing, E, N) and a
;;;      SIGN LEGEND with symbols in the report
;;;    - ROAD ENDS: tie-in line with existing road + coordinates, or
;;;      road-closed barricade + ROAD CLOSED sign (ROAD-TIEIN)
;;;    - REPORT: tables in the drawing + Excel (CSV) file next to the DWG
;;;        * General, geometry, barricades, signs, road ends, chainage
;;;        * Curve data   : TC / CT chainage, radius, arc, deflection, E/N
;;;        * Setting-out  : E/N of centre line, left & right edge at every
;;;                         chainage, TC, CT, start and end
;;;    - Whole road = ONE undo step. Settings are remembered.
;;;
;;;  INSTALL : APPLOAD -> select RoadPro.lsp -> Load
;;;            (add it to "Startup Suite" to load automatically)
;;;  NEEDS   : Full AutoCAD / Civil 3D / Map 3D 2013 or newer (not LT)
;;;  INPUT   : All sizes are typed in METERS. For mm drawings choose
;;;            "Millimeters" in the dialog - RoadPro scales everything.
;;;============================================================================
(vl-load-com)

(setq *rp:ver* "3.0")

(setq *rp:defaults*
  '(("rname"  . "ROAD-01") ("width"  . "7.30")  ("radius" . "10.0")  ("rref"   . "0")
    ("units"  . "0")       ("mode"   . "0")
    ("bl"     . "1")       ("br"     . "1")     ("bc"     . "0")
    ("blen"   . "2.00")    ("bwid"   . "0.50")  ("bgap"   . "0.50")
    ("sspeed" . "1")       ("speed"  . "30")    ("swarn"  . "1")     ("warnd"  . "30")
    ("schev"  . "1")       ("twoway" . "1")     ("signsz" . "2.0")
    ("hatch"  . "1")       ("hpat"   . "SOLID") ("hscl"   . "1.0")   ("cltext" . "1")
    ("ch"     . "1")       ("chint"  . "20")    ("chst"   . "0")     ("txth"   . "1.0")
    ("endst"  . "0")       ("endfn"  . "0")     ("report" . "1")
    ("rlab"   . "1")       ("slab"   . "1")
    ("srw"    . "1")       ("skr"    . "1")     ("sarr"   . "1")     ("jctl"   . "0")
    ("ssp"    . "15")      ("xsec"   . "1")     ("mark"   . "1")))

(setq *rp:keys* (mapcar 'car *rp:defaults*))

;; Cross-section settings (own dialog)
(setq *rp:xdefaults*
  '(("xmode"  . "0")    ("xch"    . "0")     ("xint"   . "20")
    ("xcf"    . "2.5")  ("xcamb"  . "0")     ("xverge" . "1.0")
    ("xl1n"   . "ASPHALT WEARING COURSE")    ("xl1t"   . "0.05")
    ("xl2n"   . "AGGREGATE BASE COURSE")     ("xl2t"   . "0.20")
    ("xl3n"   . "GRANULAR SUB-BASE")         ("xl3t"   . "0.15")
    ("xbtype" . "0")    ("xbh"    . "1.00")
    ("xsign"  . "1")    ("xsclr"  . "2.10")  ("xsplate" . "0.90")))
(setq *rp:xkeys*    (mapcar 'car *rp:xdefaults*)
      *rp:defaults* (append *rp:defaults* *rp:xdefaults*))

;; Lane widening settings (own dialog)
(setq *rp:wdefaults*
  '(("wside"  . "1")    ("wwid"   . "3.65")  ("wst"    . "100")   ("wen"   . "200")
    ("wtin"   . "30")   ("wtout"  . "30")    ("wtype"  . "0")     ("wmatch" . "0")
    ("wrad"   . "30")   ("wbar"   . "1")     ("warr"   . "1")     ("wlab"   . "1")
    ("wdiff"  . "0")    ("wwid2"  . "3.65")  ("wst2"   . "100")   ("wen2"  . "200")
    ("wtin2"  . "30")   ("wtout2" . "30")    ("wrad2"  . "30")))
(setq *rp:wkeys*    (mapcar 'car *rp:wdefaults*)
      *rp:defaults* (append *rp:defaults* *rp:wdefaults*))

;; Road taper settings (own dialog)
(setq *rp:tdefaults*
  '(("tside"  . "2")    ("tst"    . "100")   ("ten"    . "130")   ("tshift" . "1.00")
    ("ttype"  . "0")    ("tmatch" . "0")     ("trad"   . "30")    ("tbar"   . "1")
    ("tlab"   . "1")    ("tdiff"  . "0")     ("tst2"   . "100")   ("ten2"   . "130")
    ("tshift2" . "1.00") ("trad2"  . "30")))
(setq *rp:tkeys*    (mapcar 'car *rp:tdefaults*)
      *rp:defaults* (append *rp:defaults* *rp:tdefaults*))

;; Road junction settings (own dialog)
(setq *rp:jdefaults*
  '(("jname" . "ROAD-02") ("jwid" . "7.30") ("jmode" . "0") ("jrad" . "10.0") ("jbar" . "1")
    ("jmark" . "1")))
(setq *rp:jkeys*    (append (mapcar 'car *rp:jdefaults*) '("jctl"))
      *rp:defaults* (append *rp:defaults* *rp:jdefaults*))

;;----------------------------------------------------------------------------
;;  Dialog definition (written to a temp file at run time - single file plugin)
;;----------------------------------------------------------------------------
(setq *rp:dcl*
 (list
  "roadpro : dialog {"
  "  label = \"ROAD PRO  -  Road Builder for AutoCAD  v3.0\";"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Road Geometry\";"
  "      : edit_box   { key = \"rname\";  label = \"Road name / ID:\";      edit_width = 14; }"
  "      : edit_box   { key = \"width\";  label = \"Road width (m):\";      edit_width = 14; }"
  "      : edit_box   { key = \"radius\"; label = \"Turning radius (m):\";  edit_width = 14; }"
  "      : popup_list { key = \"rref\";   label = \"Radius measured at:\";  edit_width = 24; }"
  "      : popup_list { key = \"units\";  label = \"Drawing units:\";       edit_width = 24; }"
  "      : popup_list { key = \"mode\";   label = \"Centre line input:\";   edit_width = 24; }"
  "      : toggle     { key = \"rlab\";   label = \"Show radius, TC / CT and curve data on plan\"; }"
  "      : toggle     { key = \"slab\";   label = \"Show straight sections (S1, S2...) on plan\"; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Barricades (Red / White, black outline)\";"
  "      : row {"
  "        : toggle { key = \"bl\"; label = \"Left\"; }"
  "        : toggle { key = \"bc\"; label = \"Centre\"; }"
  "        : toggle { key = \"br\"; label = \"Right\"; }"
  "      }"
  "      : edit_box { key = \"blen\"; label = \"Unit length (m):\";        edit_width = 8; }"
  "      : edit_box { key = \"bwid\"; label = \"Unit width (m):\";         edit_width = 8; }"
  "      : edit_box { key = \"bgap\"; label = \"Gap from road edge (m):\"; edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Signs and Markings\";"
  "      : row { : toggle { key = \"sspeed\"; label = \"Speed limit\"; }"
  "              : edit_box { key = \"speed\"; label = \"km/h:\"; edit_width = 5; } }"
  "      : row { : toggle { key = \"swarn\"; label = \"Bend ahead\"; }"
  "              : edit_box { key = \"warnd\"; label = \"before (m):\"; edit_width = 5; } }"
  "      : toggle     { key = \"srw\";    label = \"Road works ahead (with plate)\"; }"
  "      : toggle     { key = \"schev\";  label = \"Chevron boards on bends\"; }"
  "      : toggle     { key = \"skr\";    label = \"Keep right at median\"; }"
  "      : toggle     { key = \"sarr\";   label = \"Lane direction arrows\"; }"
  "      : popup_list { key = \"jctl\";   label = \"At tie-in:\"; edit_width = 16; }"
  "      : toggle     { key = \"twoway\"; label = \"Two-way traffic (signs both ways)\"; }"
  "      : row { : edit_box { key = \"signsz\"; label = \"Symbol (m):\"; edit_width = 5; }"
  "              : edit_box { key = \"ssp\"; label = \"Spacing (m):\"; edit_width = 5; } }"
  "    }"
  "  }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Surface and Centre Line\";"
  "      : toggle   { key = \"hatch\";  label = \"Hatch road surface\"; }"
  "      : edit_box { key = \"hpat\";   label = \"Hatch pattern:\";             edit_width = 10; }"
  "      : edit_box { key = \"hscl\";   label = \"Pattern scale (not SOLID):\"; edit_width = 10; }"
  "      : toggle   { key = \"cltext\"; label = \"Show CL text in centre line\"; }"
  "      : toggle   { key = \"mark\";   label = \"Road markings (lane line, edge lines)\"; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Chainage\";"
  "      : toggle   { key = \"ch\";    label = \"Add chainage ticks and labels\"; }"
  "      : edit_box { key = \"chint\"; label = \"Interval (m):\";        edit_width = 8; }"
  "      : edit_box { key = \"chst\";  label = \"Start chainage (m):\";  edit_width = 8; }"
  "      : edit_box { key = \"txth\";  label = \"Text height (m):\";     edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Road Ends and Report\";"
  "      : popup_list { key = \"endst\"; label = \"Start end:\";  edit_width = 26; }"
  "      : popup_list { key = \"endfn\"; label = \"Finish end:\"; edit_width = 26; }"
  "      : toggle     { key = \"report\"; label = \"Report tables + Excel (CSV) file\"; }"
  "      : toggle     { key = \"xsec\";   label = \"Typical cross section drawing\"; }"
  "    }"
  "  }"
  "  : text { label = \"Developed by https://www.exceltokml.com/\"; alignment = right; }"
  "  ok_cancel;"
  "  errtile;"
  "}"))

;;----------------------------------------------------------------------------
;;  Settings (remembered between sessions)
;;----------------------------------------------------------------------------
(defun rp:val (k / v)
  (setq v (getenv (strcat "RoadPro_" k)))
  (if (and v (/= v "")) v (cdr (assoc k *rp:defaults*))))

(defun rp:set (k v) (setenv (strcat "RoadPro_" k) v))

;; Number from text : plain metres "100" or chainage format "0+100" / "1+250.5"
(defun rp:dist (s / p a b)
  (if s (setq s (vl-string-trim " " s)))
  (if (and s (= (substr s 1 1) "+")) (setq s (substr s 2)))
  (if (and s (setq p (vl-string-search "+" s)) (> p 0))
    (if (and (setq a (distof (vl-string-trim " " (substr s 1 p)) 2))
             (setq b (distof (vl-string-trim " " (substr s (+ p 2))) 2)))
      (+ (* a 1000.0) b))
    (if s (distof (vl-string-trim " " s) 2))))

(defun rp:num (k / v)
  (if (setq v (rp:dist (rp:val k))) v (rp:dist (cdr (assoc k *rp:defaults*)))))

(defun rp:on (k) (= (rp:val k) "1"))

;;----------------------------------------------------------------------------
;;  Start / finish / error handling
;;----------------------------------------------------------------------------
(defun rp:start ()
  (setq *rp:doc*    (vla-get-ActiveDocument (vlax-get-acad-object))
        *rp:olderr* *error*
        *error*     rp:error
        *rp:ucs*    nil
        *rp:sv*     (mapcar '(lambda (v) (cons v (getvar v)))
                            '("CMDECHO" "PLINETYPE" "PLINEWID" "FILLETRAD" "PEDITACCEPT" "OSMODE")))
  (vla-StartUndoMark *rp:doc*)
  (setvar "CMDECHO" 0))

(defun rp:finish ()
  (if *rp:ucs*
    (progn
      (setq *rp:ucs* nil)
      (if command-s (command-s "_.UCS" "_P") (vl-cmdf "_.UCS" "_P"))))
  (foreach p *rp:sv* (vl-catch-all-apply 'setvar (list (car p) (cdr p))))
  (setq *rp:sv* nil)
  (if *rp:doc* (vl-catch-all-apply 'vla-EndUndoMark (list *rp:doc*)))
  (setq *error* *rp:olderr*)
  (princ))

(defun rp:error (msg)
  (if (and msg (not (wcmatch (strcase msg T) "*break*,*cancel*,*exit*,*quit*")))
    (princ (strcat "\n** RoadPro error: " msg " **  (type U to undo)")))
  (rp:finish))

(defun rp:space ()
  (setq *rp:spc* (if (and (= (getvar "TILEMODE") 0) (= (getvar "CVPORT") 1))
                   (vla-get-PaperSpace *rp:doc*)
                   (vla-get-ModelSpace *rp:doc*))))

(defun rp:world ()
  (if (= (getvar "WORLDUCS") 0) (progn (command "_.UCS" "_W") (setq *rp:ucs* T))))

;;----------------------------------------------------------------------------
;;  Dialog
;;----------------------------------------------------------------------------
(defun rp:fill (k lst) (start_list k) (mapcar 'add_list lst) (end_list))

(defun rp:dlg-modes (/ b)
  (setq b (if (or (= (get_tile "bl") "1") (= (get_tile "br") "1") (= (get_tile "bc") "1")) 0 1))
  (foreach k '("blen" "bwid" "bgap") (mode_tile k b))
  (foreach k '("hpat" "hscl") (mode_tile k (if (= (get_tile "hatch") "1") 0 1)))
  (foreach k '("chint" "chst" "txth") (mode_tile k (if (= (get_tile "ch") "1") 0 1)))
  (mode_tile "speed" (if (= (get_tile "sspeed") "1") 0 1))
  (mode_tile "warnd" (if (= (get_tile "swarn") "1") 0 1)))

(defun rp:dlg-accept (/ bad v)
  ;; (key  name  0=must be > 0 / 1=may be zero)
  (foreach k '(("width"  "Road width"        0) ("radius" "Turning radius"    1)
               ("blen"   "Unit length"       0) ("bwid"   "Unit width"        0)
               ("bgap"   "Gap from edge"     1) ("speed"  "Speed limit"       0)
               ("warnd"  "Warning distance"  1) ("signsz" "Sign symbol size"  0)
               ("ssp"    "Sign spacing"      0)
               ("hscl"   "Pattern scale"     0) ("chint"  "Chainage interval" 0)
               ("chst"   "Start chainage"    1) ("txth"   "Text height"       0))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (if (= (caddr k) 1) (< v 0.0) (<= v 0.0)))
          (setq bad k)))))
  (if bad
    (progn
      (set_tile "error" (strcat (cadr bad)
                                (if (= (caddr bad) 1)
                                  " must be zero or a positive number."
                                  " must be a number greater than zero.")))
      (mode_tile (car bad) 2))
    (progn
      (if (= (vl-string-trim " " (get_tile "hpat")) "") (set_tile "hpat" "SOLID"))
      (if (= (vl-string-trim " " (get_tile "rname")) "") (set_tile "rname" "ROAD-01"))
      (foreach k *rp:keys* (rp:set k (get_tile k)))
      (done_dialog 1))))

(defun rp:dialog (/ fn f id res)
  (setq fn (vl-filename-mktemp "roadpro.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:dcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadpro" id))
        (progn
          (rp:fill "rref"   '("Centre line (CL)" "Inner edge (kerb line)"))
          (rp:fill "units"  '("Meters  (1 unit = 1 m)" "Millimeters  (1 unit = 1 mm)"))
          (rp:fill "mode"   '("Pick points (draw new)" "Select existing Line/Pline/Arc"))
          (rp:fill "endst"  '("Tie-in line (existing road)" "Road closed (barricade+sign)" "None"))
          (rp:fill "endfn"  '("Tie-in line (existing road)" "Road closed (barricade+sign)" "None"))
          (rp:fill "jctl"   '("STOP sign" "GIVE WAY sign" "No sign"))
          (foreach k *rp:keys* (set_tile k (rp:val k)))
          (rp:dlg-modes)
          (foreach k '("bl" "br" "bc" "hatch" "ch" "sspeed" "swarn")
            (action_tile k "(rp:dlg-modes)"))
          (action_tile "accept" "(rp:dlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; Command-line fallback (only if the dialog cannot be shown)
(defun rp:cmdline (/ v)
  (initget 6)
  (if (setq v (getdist (strcat "\nRoad width in meters <" (rp:val "width") ">: ")))
    (rp:set "width" (rtos v 2 3)))
  (initget 4)
  (if (setq v (getdist (strcat "\nTurning radius in meters, 0 = none <" (rp:val "radius") ">: ")))
    (rp:set "radius" (rtos v 2 3))))

;;----------------------------------------------------------------------------
;;  Layers and linetypes
;;----------------------------------------------------------------------------
(defun rp:mklayer (name col lt lw / lay clr new)
  (setq new (not (tblsearch "LAYER" name))
        lay (vla-Add (vla-get-Layers *rp:doc*) name))
  (if new
    (progn
      (setq clr (vla-get-TrueColor lay))
      (if (listp col)
        (vla-SetRGB clr (car col) (cadr col) (caddr col))
        (vla-put-ColorIndex clr col))
      (vla-put-TrueColor lay clr)
      (if (and lt (tblsearch "LTYPE" lt)) (vla-put-Linetype lay lt))
      (if lw (vla-put-Lineweight lay lw))))
  (vl-catch-all-apply 'vla-put-Lock    (list lay :vlax-false))
  (vl-catch-all-apply 'vla-put-LayerOn (list lay :vlax-true))
  (vl-catch-all-apply 'vla-put-Freeze  (list lay :vlax-false))
  lay)

(defun rp:layers ()
  (rp:mklayer "ROAD-CL"              '(255 0 0)     "ROAD_CL2" 18)
  (rp:mklayer "ROAD-EDGE"            7              nil        35)
  (rp:mklayer "ROAD-SURFACE"         8              nil        0)
  (rp:mklayer "ROAD-BARRIER-RED"     '(255 0 0)     nil        0)
  (rp:mklayer "ROAD-BARRIER-WHITE"   '(255 255 255) nil        0)
  (rp:mklayer "ROAD-BARRIER-OUTLINE" '(0 0 0)       nil        25)
  (rp:mklayer "ROAD-CHAINAGE"        3              nil        18)
  (rp:mklayer "ROAD-SIGN"            '(0 0 0)       nil        25)
  (rp:mklayer "ROAD-SIGN-RED"        '(255 0 0)     nil        0)
  (rp:mklayer "ROAD-SIGN-WHITE"      '(255 255 255) nil        0)
  (rp:mklayer "ROAD-TIEIN"           6              "ROAD_TIE" 35)
  (rp:mklayer "ROAD-REPORT"          7              nil        18)
  (rp:mklayer "ROAD-CURVE"           5              nil        18)
  (rp:mklayer "ROAD-SECTION"         30             nil        18)
  (rp:mklayer "ROAD-SIGN-BLUE"       '(0 82 164)    nil        0)
  (rp:mklayer "ROAD-MARKING"         8              nil        0)
  (rp:mklayer "ROAD-MARKING-FILL"    '(255 255 255) nil        0)
  (rp:mklayer "ROAD-XSEC"            7              nil        35)
  (rp:mklayer "ROAD-XSEC-THIN"       8              nil        13)
  (rp:mklayer "ROAD-XSEC-DIM"        3              nil        13)
  (rp:mklayer "ROAD-XSEC-TEXT"       7              nil        18)
  (rp:mklayer "ROAD-XSEC-L1"         '(64 64 64)    nil        0)
  (rp:mklayer "ROAD-XSEC-L2"         '(181 140 90)  nil        0)
  (rp:mklayer "ROAD-XSEC-L3"         '(214 196 150) nil        0)
  (rp:mklayer "ROAD-XSEC-SHLD"       '(228 218 196) nil        0)
  (rp:mklayer "ROAD-XSEC-CONC"       '(170 170 170) nil        0)
  (rp:mklayer "ROAD-WIDENING"        40             nil        18)
  (rp:mklayer "ROAD-JUNCTION"        4              nil        18))

;; Custom linetypes, defined in meters (scaled automatically for mm drawings)
(defun rp:linetypes (/ lts fn f)
  (setq lts (vla-get-Linetypes *rp:doc*))
  (if (not (and (tblsearch "LTYPE" "ROAD_CL") (tblsearch "LTYPE" "ROAD_CL2")
                (tblsearch "LTYPE" "ROAD_TIE")))
    (progn
      (setq fn (strcat (getvar "TEMPPREFIX") "roadpro.lin"))
      (if (setq f (open fn "w"))
        (progn
          (foreach l '("*ROAD_CL,Road centre line ---- CL ---- CL ----"
                       "A,10,-1.2,[\"CL\",STANDARD,S=0.8,U=0.0,X=-0.7,Y=-0.4],-1.0"
                       "*ROAD_CL2,Road centre line ____ . ____ . ____"
                       "A,6,-1,1,-1"
                       "*ROAD_TIE,Tie-in line __ __ __ __"
                       "A,1.5,-0.75")
            (write-line l f))
          (close f)
          (foreach n '("ROAD_CL" "ROAD_CL2" "ROAD_TIE")
            (if (not (tblsearch "LTYPE" n))
              (vl-catch-all-apply 'vla-Load (list lts n fn)))))))))

(defun rp:cl-ltype (/ n fn)
  (setq n (if (rp:on "cltext") "ROAD_CL" "ROAD_CL2"))
  (cond
    ((tblsearch "LTYPE" n) n)
    ((tblsearch "LTYPE" "ROAD_CL2") "ROAD_CL2")
    (T
     (if (and (not (tblsearch "LTYPE" "CENTER")) (setq fn (findfile "acadiso.lin")))
       (vl-catch-all-apply 'vla-Load (list (vla-get-Linetypes *rp:doc*) "CENTER" fn)))
     (if (tblsearch "LTYPE" "CENTER") "CENTER" "Continuous"))))

;;----------------------------------------------------------------------------
;;  Geometry helpers
;;----------------------------------------------------------------------------
;; Point at distance d along the curve, shifted sideways by off (+ = left)
(defun rp:offpt (cl d off / par p dv l)
  (setq d   (max 0.0 (min d *rp:len*))
        par (vlax-curve-getParamAtDist cl d))
  (if (null par)
    (setq par (if (< d (* 0.5 *rp:len*))
                (vlax-curve-getStartParam cl)
                (vlax-curve-getEndParam cl))))
  (setq p  (vlax-curve-getPointAtParam cl par)
        dv (vlax-curve-getFirstDeriv cl par)
        l  (distance '(0.0 0.0) (list (car dv) (cadr dv))))
  (if (< l 1e-12) (setq l 1.0))
  (list (- (car p)  (* off (/ (cadr dv) l)))
        (+ (cadr p) (* off (/ (car dv) l)))))

;; Local frame at distance d : (point  left-normal  tangent)
(defun rp:frame (cl d / p q n)
  (setq p (rp:offpt cl d 0.0)
        q (rp:offpt cl d 1.0)
        n (list (- (car q) (car p)) (- (cadr q) (cadr p))))
  (list p n (list (cadr n) (- (car n)))))

;; Point in a frame: s along the left normal, u along the tangent
(defun rp:loc (f s u)
  (list (+ (car (car f))  (* s (car (cadr f)))  (* u (car (caddr f))))
        (+ (cadr (car f)) (* s (cadr (cadr f))) (* u (cadr (caddr f))))))

;; Scale, rotate and move a list of 2D points
(defun rp:xf (pts c a s)
  (mapcar '(lambda (p)
             (list (+ (car c)  (* s (- (* (car p) (cos a)) (* (cadr p) (sin a)))))
                   (+ (cadr c) (* s (+ (* (car p) (sin a)) (* (cadr p) (cos a)))))))
          pts))

(defun rp:xf1 (p c s) (car (rp:xf (list p) c 0.0 s)))

(defun rp:p3 (p z) (vlax-3d-point (list (car p) (cadr p) z)))

(defun rp:objarr (lst)
  (vlax-make-variant
    (vlax-safearray-fill
      (vlax-make-safearray vlax-vbObject (cons 0 (1- (length lst))))
      lst)))

;; vl = list of (point bulge)
(defun rp:mkpl (vl lay elev closed / e)
  (setq e (entmakex
            (append
              (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 lay)
                    '(100 . "AcDbPolyline") (cons 90 (length vl))
                    (cons 70 (if closed 1 0)) (cons 38 elev))
              (apply 'append
                     (mapcar '(lambda (v) (list (cons 10 (car v)) (cons 42 (cadr v)))) vl)))))
  (if e (vlax-ename->vla-object e)))

(defun rp:poly (pts lay elev) (rp:mkpl (mapcar '(lambda (p) (list p 0.0)) pts) lay elev T))

;; Open polyline with widths : vl = list of (point start-width end-width)
(defun rp:mkwpl (vl lay elev)
  (entmakex
    (append
      (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 lay)
            '(100 . "AcDbPolyline") (cons 90 (length vl)) '(70 . 0) (cons 38 elev))
      (apply 'append
             (mapcar '(lambda (v) (list (cons 10 (car v)) (cons 40 (cadr v))
                                        (cons 41 (caddr v)) '(42 . 0.0)))
                     vl)))))

(defun rp:pldata (o / co pts bl i)
  (setq co (vlax-safearray->list (vlax-variant-value (vla-get-Coordinates o))) i 0)
  (while co (setq pts (cons (list (car co) (cadr co)) pts) co (cddr co)))
  (setq pts (reverse pts))
  (repeat (length pts) (setq bl (cons (vla-GetBulge o i) bl) i (1+ i)))
  (list pts (reverse bl)))

;; Closed boundary = edge 1 forward + edge 2 backward (arcs kept exact)
(defun rp:bnd-verts (o1 o2 / d1 d2)
  (setq d1 (rp:pldata o1) d2 (rp:pldata o2))
  (mapcar 'list
          (append (car d1) (reverse (car d2)))
          (append (reverse (cons 0.0 (cdr (reverse (cadr d1)))))
                  (mapcar '- (cdr (reverse (cadr d2))))
                  '(0.0))))

(defun rp:offset (o d / r)
  (setq r (vl-catch-all-apply 'vla-Offset (list o d)))
  (if (vl-catch-all-error-p r) nil (vlax-safearray->list (vlax-variant-value r))))

(defun rp:props (o lay lt lts / c)
  (vla-put-Layer o lay)
  (setq c (vla-get-TrueColor o))
  (vla-put-ColorMethod c acColorMethodByLayer)
  (vla-put-TrueColor o c)
  (vla-put-Linetype o lt)
  (vla-put-LinetypeScale o lts)
  (vla-put-Lineweight o acLnWtByLayer)
  (vl-catch-all-apply 'vla-put-ConstantWidth (list o 0.0)))

(defun rp:newhatch (pat asc elev / a h)
  (setq a (if asc :vlax-true :vlax-false)
        h (vl-catch-all-apply 'vla-AddHatch
            (list *rp:spc* acHatchPatternTypePreDefined pat a)))
  (if (vl-catch-all-error-p h)
    (progn
      (princ (strcat "\nHatch pattern \"" pat "\" not found - using SOLID."))
      (setq h (vla-AddHatch *rp:spc* acHatchPatternTypePreDefined "SOLID" a))))
  (vla-put-Elevation h elev)
  h)

;; Solid fill inside outer object (optionally minus inner object)
(defun rp:solidfill (outer inner lay elev / h)
  (setq h (rp:newhatch "SOLID" T elev))
  (vla-put-Layer h lay)
  (vla-AppendOuterLoop h (rp:objarr (list outer)))
  (if inner (vla-AppendInnerLoop h (rp:objarr (list inner))))
  (vla-Evaluate h)
  (setq *rp:hatches* (cons h *rp:hatches*))
  h)

(defun rp:text (str pt h lay elev / tx)
  (setq tx (vla-AddText *rp:spc* str (rp:p3 pt elev) h))
  (vla-put-Alignment tx acAlignmentMiddleCenter)
  (vla-put-TextAlignmentPoint tx (rp:p3 pt elev))
  (vla-put-Layer tx lay)
  tx)

(defun rp:toback (objs / ss)
  (setq ss (ssadd))
  (foreach o objs (ssadd (vlax-vla-object->ename o) ss))
  (if (> (sslength ss) 0) (command "_.DRAWORDER" ss "" "_B")))

;; Curves (arc segments) of a polyline : list of
;; (dist-start dist-end radius deflection direction(+1 left/-1 right) TC-point CT-point)
(defun rp:curves (o / n i b p1 p2 a ch rr lst)
  (setq n (fix (+ 0.5 (vlax-curve-getEndParam o))) i 0)
  (repeat n
    (setq b (vla-GetBulge o i))
    (if (> (abs b) 1e-9)
      (progn
        (setq p1 (vlax-curve-getPointAtParam o i)
              p2 (vlax-curve-getPointAtParam o (1+ i))
              a  (* 4.0 (atan (abs b)))
              ch (distance p1 p2)
              rr (/ ch (* 2.0 (sin (/ a 2.0)))))
        (setq lst (cons (list (vlax-curve-getDistAtParam o i)
                              (vlax-curve-getDistAtParam o (1+ i))
                              rr a (if (> b 0) 1 -1) p1 p2)
                        lst))))
    (setq i (1+ i)))
  (reverse lst))

;;----------------------------------------------------------------------------
;;  Centre line input
;;----------------------------------------------------------------------------
(defun rp:get-centreline (/ prev e sel typ)
  (cond
    (*rp:presetcl* (setq e *rp:presetcl*))
    ((= (rp:val "mode") "0")
     (setvar "PLINETYPE" 2)
     (setvar "PLINEWID" 0.0)
     (setq prev (entlast))
     (princ "\nDraw the road centre line (Arc option allowed, Enter to finish):")
     (setvar "CMDECHO" 1)
     (command "_.PLINE")
     (while (> (getvar "CMDACTIVE") 0) (command pause))
     (setvar "CMDECHO" 0)
     (setq e (entlast))
     (if (equal e prev) (setq e nil)))
    (T
     (while
       (and (setq sel (entsel "\nSelect road centre line (Line / 2D Polyline / Arc): "))
            (not (wcmatch (cdr (assoc 0 (entget (car sel)))) "LINE,ARC,LWPOLYLINE")))
       (princ "\n  Not supported - pick a Line, Arc or 2D (LW) Polyline."))
     (if sel
       (progn
         (setq e (car sel) typ (cdr (assoc 0 (entget e))))
         (if (/= typ "LWPOLYLINE")
           (progn
             (setvar "PEDITACCEPT" 1)
             (command "_.PEDIT" e "")
             (setq e (entlast))))))))
  (if (and e
           (= (cdr (assoc 0 (entget e))) "LWPOLYLINE")
           (> (vlax-curve-getDistAtParam e (vlax-curve-getEndParam e)) 1e-6))
    e
    (progn (princ "\nNo valid centre line - nothing created.") nil)))

;;----------------------------------------------------------------------------
;;  Road surface hatch
;;----------------------------------------------------------------------------
(defun rp:surface (cl e1 e2 elev / o1 o2 tmp h bnd pat r)
  (if (and (= (length e1) 1) (= (length e2) 1))
    (progn
      (setq o1  (car e1)
            o2  (car e2)
            pat (strcase (vl-string-trim " " (rp:val "hpat"))))
      (if (vlax-curve-isClosed cl)
        (progn
          (if (< (vla-get-Area o1) (vla-get-Area o2)) (setq tmp o1 o1 o2 o2 tmp))
          (setq h (rp:newhatch pat T elev))
          (vla-put-Layer h "ROAD-SURFACE")
          (setq r (vl-catch-all-apply
                    (function
                      (lambda ()
                        (vla-AppendOuterLoop h (rp:objarr (list o1)))
                        (vla-AppendInnerLoop h (rp:objarr (list o2)))))
                    nil)))
        (progn
          (setq bnd (rp:mkpl (rp:bnd-verts o1 o2) "ROAD-SURFACE" elev T)
                h   (rp:newhatch pat nil elev))
          (vla-put-Layer h "ROAD-SURFACE")
          (setq r (vl-catch-all-apply 'vla-AppendOuterLoop (list h (rp:objarr (list bnd)))))))
      (cond
        ((vl-catch-all-error-p r)
         (vla-Delete h)
         (setq h nil)
         (princ "\nWarning: road surface hatch could not be created."))
        (T
         (if (/= (vla-get-PatternName h) "SOLID")
           (vl-catch-all-apply 'vla-put-PatternScale (list h (rp:num "hscl"))))
         (vla-Evaluate h)
         (vl-catch-all-apply 'vla-put-EntityTransparency (list h "50"))))
      (if bnd (vla-Delete bnd))
      h)
    (progn
      (princ "\nWarning: surface hatch skipped (edge offset split into several pieces).")
      nil)))

;;----------------------------------------------------------------------------
;;  Barricades : alternating red / white units between side offsets d1 and d2
;;----------------------------------------------------------------------------
(defun rp:barrier (cl len d1 d2 seg step elev / d de n i dd pa pb cnt nred nwht)
  (setq d 0.0 cnt 0 nred 0 nwht 0)
  (while (< d (- len 1e-6))
    (setq de (+ d seg))
    (if (> de (- len (* 0.25 seg))) (setq de len))      ; no tiny slivers at the end
    (setq n  (max 1 (fix (+ 0.999999 (/ (- de d) step))))
          pa nil pb nil i 0)
    (repeat (1+ n)
      (setq dd (+ d (* (- de d) (/ (float i) n)))
            pa (cons (rp:offpt cl dd d1) pa)
            pb (cons (rp:offpt cl dd d2) pb)
            i  (1+ i)))
    (rp:solidfill (rp:poly (append (reverse pa) pb) "ROAD-BARRIER-OUTLINE" elev)
                  nil
                  (if (= 0 (rem cnt 2)) "ROAD-BARRIER-RED" "ROAD-BARRIER-WHITE")
                  elev)
    (if (= 0 (rem cnt 2)) (setq nred (1+ nred)) (setq nwht (1+ nwht)))
    (setq cnt (1+ cnt) d de))
  (list nred nwht))

;;----------------------------------------------------------------------------
;;  Signs
;;----------------------------------------------------------------------------
;; Speed limit : red ring, white centre, black number
(defun rp:sign-speed (c sz spd elev / o i)
  (setq o (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.5 sz))
        i (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.39 sz)))
  (vla-put-Layer o "ROAD-SIGN")
  (vla-put-Layer i "ROAD-SIGN-RED")
  (rp:solidfill o i "ROAD-SIGN-RED" elev)
  (rp:solidfill i nil "ROAD-SIGN-WHITE" elev)
  (rp:text spd c (* 0.32 sz) "ROAD-SIGN" elev))

;; Curve warning : red triangle with bend arrow (dir -1 = bend left, +1 = right)
(defun rp:pt+ (p v k) (list (+ (car p) (* k (car v))) (+ (cadr p) (* k (cadr v)))))

;; Triangle sign body : black outline, red border, white centre (inv = point down)
(defun rp:tri-sign (c sz elev inv / tri o i)
  (setq tri (if inv
              '((0.0 -0.57735) (0.5 0.288675) (-0.5 0.288675))
              '((0.0 0.57735) (-0.5 -0.288675) (0.5 -0.288675)))
        o   (rp:poly (rp:xf tri c 0.0 sz) "ROAD-SIGN" elev)
        i   (rp:poly (rp:xf tri c 0.0 (* 0.62 sz)) "ROAD-SIGN-RED" elev))
  (rp:solidfill o i "ROAD-SIGN-RED" elev)
  (rp:solidfill i nil "ROAD-SIGN-WHITE" elev))

;; Bend ahead : triangle with bend arrow (dir -1 = bend left, +1 = bend right)
(defun rp:sign-warn (c sz dir elev)
  (rp:tri-sign c sz elev nil)
  (rp:mkwpl
    (list (list (rp:xf1 '(0.0 -0.13) c sz) (* 0.035 sz) (* 0.035 sz))
          (list (rp:xf1 '(0.0 0.0) c sz)   (* 0.035 sz) (* 0.035 sz))
          (list (rp:xf1 (list (* dir 0.05) 0.05) c sz) (* 0.10 sz) 0.0)
          (list (rp:xf1 (list (* dir 0.11) 0.11) c sz) 0.0 0.0))
    "ROAD-SIGN" elev))

;; Road works ahead : triangle with "!" and a ROAD WORKS supplementary plate
(defun rp:icon-works (c sz elev / d)
  (rp:tri-sign c sz elev nil)
  (rp:solidfill (rp:poly (rp:xf '((-0.03 -0.03) (0.03 -0.03) (0.045 0.2) (-0.045 0.2)) c 0.0 sz)
                         "ROAD-SIGN" elev)
                nil "ROAD-SIGN" elev)
  (setq d (vla-AddCircle *rp:spc* (rp:p3 (rp:xf1 '(0.0 -0.1) c sz) elev) (* 0.04 sz)))
  (vla-put-Layer d "ROAD-SIGN")
  (rp:solidfill d nil "ROAD-SIGN" elev)
  (rp:solidfill (rp:poly (rp:xf '((-0.75 -0.72) (0.75 -0.72) (0.75 -0.4) (-0.75 -0.4)) c 0.0 sz)
                         "ROAD-SIGN" elev)
                nil "ROAD-SIGN-WHITE" elev)
  (rp:text "ROAD WORKS" (rp:xf1 '(0.0 -0.56) c sz) (* 0.14 sz) "ROAD-SIGN" elev))

(defun rp:ngon (n r a0 / i lst)
  (setq i 0)
  (repeat n
    (setq lst (cons (list (* r (cos (+ a0 (/ (* 2.0 pi i) n))))
                          (* r (sin (+ a0 (/ (* 2.0 pi i) n)))))
                    lst)
          i   (1+ i)))
  (reverse lst))

;; STOP : red octagon, white border, white STOP text
(defun rp:icon-stop (c sz elev / b)
  (rp:solidfill (rp:poly (rp:xf (rp:ngon 8 0.5 (/ pi 8.0)) c 0.0 sz) "ROAD-SIGN" elev)
                nil "ROAD-SIGN-RED" elev)
  (setq b (rp:poly (rp:xf (rp:ngon 8 0.45 (/ pi 8.0)) c 0.0 sz) "ROAD-SIGN-WHITE" elev))
  (vla-put-ConstantWidth b (* 0.025 sz))
  (rp:text "STOP" c (* 0.22 sz) "ROAD-SIGN-WHITE" elev))

;; GIVE WAY : inverted triangle
(defun rp:icon-giveway (c sz elev) (rp:tri-sign c sz elev T))

;; NO ENTRY : red disc with white bar
(defun rp:icon-noentry (c sz elev / o)
  (setq o (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.5 sz)))
  (vla-put-Layer o "ROAD-SIGN")
  (rp:solidfill o nil "ROAD-SIGN-RED" elev)
  (rp:solidfill (rp:poly (rp:xf '((-0.34 -0.08) (0.34 -0.08) (0.34 0.08) (-0.34 0.08)) c 0.0 sz)
                         "ROAD-SIGN-WHITE" elev)
                nil "ROAD-SIGN-WHITE" elev))

;; KEEP RIGHT : blue disc with white arrow pointing down-right
(defun rp:icon-keepright (c sz elev / o)
  (setq o (vla-AddCircle *rp:spc* (rp:p3 c elev) (* 0.5 sz)))
  (vla-put-Layer o "ROAD-SIGN")
  (rp:solidfill o nil "ROAD-SIGN-BLUE" elev)
  (rp:solidfill (rp:poly (rp:xf '((-0.3 -0.06) (0.1 -0.06) (0.1 -0.16) (0.32 0.0)
                                  (0.1 0.16) (0.1 0.06) (-0.3 0.06))
                                c (* -0.25 pi) sz)
                         "ROAD-SIGN-WHITE" elev)
                nil "ROAD-SIGN-WHITE" elev))

(defun rp:draw-icon (typ c sz arg elev)
  (cond
    ((= typ "speed")     (rp:sign-speed c sz arg elev))
    ((= typ "warn")      (rp:sign-warn c sz (atof arg) elev))
    ((= typ "works")     (rp:icon-works c sz elev))
    ((= typ "stop")      (rp:icon-stop c sz elev))
    ((= typ "giveway")   (rp:icon-giveway c sz elev))
    ((= typ "noentry")   (rp:icon-noentry c sz elev))
    ((= typ "keepright") (rp:icon-keepright c sz elev))
    ((= typ "closed")    (rp:sign-closed c sz elev))))

;; Chevron board : white board with red chevron, pointing into the bend
(defun rp:chevron (c ang sz elev / k)
  (setq k (* 0.6 sz))
  (rp:solidfill (rp:poly (rp:xf '((-0.35 -0.45) (0.35 -0.45) (0.35 0.45) (-0.35 0.45)) c ang k)
                         "ROAD-SIGN" elev)
                nil "ROAD-SIGN-WHITE" elev)
  (rp:solidfill (rp:poly (rp:xf '((-0.25 0.35) (0.0 0.35) (0.25 0.0) (0.0 -0.35) (-0.25 -0.35) (0.0 0.0))
                                c ang k)
                         "ROAD-SIGN-RED" elev)
                nil "ROAD-SIGN-RED" elev))

(defun rp:chevrons (cl c off sz fac elev / n k d f)
  (setq n (max 3 (1+ (fix (/ (- (cadr c) (car c)) (* 10.0 fac))))) k 0)
  (repeat n
    (setq d (+ (car c) (* (- (cadr c) (car c)) (/ (float k) (1- n))))
          f (rp:frame cl d))
    (rp:chevron (rp:loc f off 0.0)
                (+ (angle '(0.0 0.0) (caddr f)) (* (nth 4 c) 0.5 pi))
                sz elev)
    (setq k (1+ k)))
  n)

;; ROAD CLOSED board : white with red border
(defun rp:sign-closed (c sz elev / o i)
  (setq o (rp:poly (rp:xf '((-1.1 -0.4) (1.1 -0.4) (1.1 0.4) (-1.1 0.4)) c 0.0 sz) "ROAD-SIGN" elev)
        i (rp:poly (rp:xf '((-1.0 -0.3) (1.0 -0.3) (1.0 0.3) (-1.0 0.3)) c 0.0 sz) "ROAD-SIGN-RED" elev))
  (rp:solidfill o i "ROAD-SIGN-RED" elev)
  (rp:solidfill i nil "ROAD-SIGN-WHITE" elev)
  (rp:text "ROAD CLOSED" c (* 0.17 sz) "ROAD-SIGN" elev))

;;----------------------------------------------------------------------------
;;  Signage engine : post + plate facing traffic + leader + symbol + ID tag
;;----------------------------------------------------------------------------
(defun rp:sign-post (post n ic sz fac id plate elev / pc)
  (setq pc (vla-AddCircle *rp:spc* (rp:p3 post elev) (* 0.15 fac)))
  (vla-put-Layer pc "ROAD-SIGN")
  (rp:solidfill pc nil "ROAD-SIGN" elev)
  (rp:mkwpl (list (list (rp:pt+ post n (* -0.45 fac)) (* 0.12 fac) (* 0.12 fac))
                  (list (rp:pt+ post n (* 0.45 fac)) 0.0 0.0))
            "ROAD-SIGN" elev)
  (if (> (distance post ic) (* 0.6 sz))
    (rp:line post (rp:towards ic post (* 0.55 sz)) "ROAD-SIGN" elev))
  (rp:text id (list (car ic) (- (cadr ic) (if plate (* 0.95 sz) (* 0.72 sz))))
           (* 0.22 sz) "ROAD-SIGN" elev))

;; r = (dist side facing type arg description)   side R / L / M(edian) / X(across)
(defun rp:draw-sign (cl r id sz fac elev offR offL xL len / d side f n post ic in)
  (setq d (car r) side (nth 1 r) f (rp:frame cl d) n (cadr f))
  (cond
    ((= side "R")
     (setq post (rp:loc f (- offR) 0.0)
           ic   (rp:loc f (- (+ offR (* 0.6 fac) (* 0.7 sz))) 0.0)))
    ((= side "L")
     (setq post (rp:loc f offL 0.0)
           ic   (rp:loc f (+ offL (* 0.6 fac) (* 0.7 sz) xL) 0.0)))
    ((= side "M")
     (setq post (car f)
           ic   (rp:loc f 0.0 (* (if (= (nth 2 r) "F") -1.0 1.0) (+ fac (* 0.8 sz))))))
    (T
     (setq in   (if (> d (* 0.5 len)) -1.0 1.0)
           post (car f)
           ic   (rp:loc f 0.0 (* -1.0 in (+ fac (* 0.5 sz)))))))
  (if (= side "X")
    (rp:text id (list (car ic) (- (cadr ic) (* 0.6 sz))) (* 0.22 sz) "ROAD-SIGN" elev)
    (progn
      (rp:draw-icon (nth 3 r) ic sz (nth 4 r) elev)
      (rp:sign-post post n ic sz fac id (= (nth 3 r) "works") elev)))
  post)

(defun rp:dpos (len dr d) (if (= dr 1) (min len d) (max 0.0 (- len d))))

;; Plans and draws all signs, returns the sign schedule :
;; list of (ID description chainage side facing E N type arg)
(defun rp:signs (cl len curves fac sz elev offR offL xL ends endf closed st
                 / two sp wd spd d0 reqs sd fc lr jt jd i id post sched)
  (setq two (rp:on "twoway")
        sp  (* fac (rp:num "ssp"))
        wd  (* fac (rp:num "warnd"))
        spd (rtos (rp:num "speed") 2 0)
        d0  (min (* 5.0 fac) (* 0.25 len)))
  ;; entry signs : forward traffic at the start, reverse traffic at the end
  (foreach dr (if two '(1 -1) '(1))
    (setq sd (if (= dr 1) "R" "L") fc (if (= dr 1) "F" "B"))
    (if (rp:on "srw")
      (setq reqs (cons (list (rp:dpos len dr d0) sd fc "works" "" "Road works ahead") reqs)))
    (if (rp:on "sspeed")
      (setq reqs (cons (list (rp:dpos len dr (+ d0 (if (rp:on "srw") sp 0.0))) sd fc "speed" spd
                             (strcat "Speed limit " spd " km/h"))
                       reqs)))
    (if (and (rp:on "bc") (rp:on "skr"))
      (setq reqs (cons (list (rp:dpos len dr 0.0) "M" fc "keepright" "" "Keep right") reqs))))
  ;; bend ahead, before every bend of 10 deg or more
  (if (rp:on "swarn")
    (foreach c curves
      (if (>= (nth 3 c) (/ pi 18.0))
        (progn
          (setq lr (> (nth 4 c) 0))
          (setq reqs (cons (list (max 0.0 (- (car c) wd)) "R" "F" "warn" (if lr "-1" "1")
                                 (strcat "Bend ahead - " (if lr "left" "right")))
                           reqs))
          (if two
            (setq reqs (cons (list (min len (+ (cadr c) wd)) "L" "B" "warn" (if lr "1" "-1")
                                   (strcat "Bend ahead - " (if lr "right" "left")))
                             reqs)))))))
  ;; tie-in control, no entry, road closed boards
  (if (not closed)
    (progn
      (setq jt (cond ((= (rp:val "jctl") "0") "stop") ((= (rp:val "jctl") "1") "giveway"))
            jd (if (= jt "stop") "STOP" "Give way"))
      (if (and jt (member endf '("0" "3")))
        (setq reqs (cons (list (max 0.0 (- len (* 3.0 fac))) "R" "F" jt "" jd) reqs)))
      (if (and jt two (member ends '("0" "3")))
        (setq reqs (cons (list (min len (* 3.0 fac)) "L" "B" jt "" jd) reqs)))
      (if (and (not two) (/= endf "1"))
        (setq reqs (cons (list (max 0.0 (- len (* 3.0 fac))) "L" "B" "noentry" "" "No entry") reqs)))
      (if (= ends "1") (setq reqs (cons (list 0.0 "X" "B" "closed" "" "Road closed board") reqs)))
      (if (= endf "1") (setq reqs (cons (list len "X" "F" "closed" "" "Road closed board") reqs)))))
  ;; number in chainage order and draw
  (setq reqs (vl-sort reqs '(lambda (a b) (< (car a) (car b))))
        i    0)
  (foreach r reqs
    (setq i     (1+ i)
          id    (strcat "SG-" (rp:z2 i))
          post  (rp:draw-sign cl r id sz fac elev offR offL xL len)
          sched (cons (list id (nth 5 r) (rp:chfmt (+ st (/ (car r) fac)))
                            (cdr (assoc (nth 1 r) '(("R" . "Right") ("L" . "Left")
                                                    ("M" . "Median") ("X" . "Across road"))))
                            (if (= (nth 2 r) "F") "Forward (CH +)" "Reverse (CH -)")
                            (rtos (/ (car post) fac) 2 3) (rtos (/ (cadr post) fac) 2 3)
                            (nth 3 r) (nth 4 r))
                      sched)))
  (reverse sched))

;; Lane direction arrow marking (5 m long), pointing in direction ang
(defun rp:arrow (c ang k elev)
  (rp:solidfill
    (rp:poly (rp:xf '((-2.5 -0.15) (0.8 -0.15) (0.8 -0.6) (2.5 0.0) (0.8 0.6) (0.8 0.15) (-2.5 0.15))
                    c ang k)
             "ROAD-MARKING" elev)
    nil "ROAD-MARKING-FILL" elev))

;; Arrows in both lanes on every straight of 12 m or more (one set per 60 m)
(defun rp:lane-arrows (cl strs hw fac two elev / n s ln k i d f a)
  (setq n 0)
  (foreach s strs
    (setq ln (- (cadr s) (car s)))
    (if (>= ln (* 12.0 fac))
      (progn
        (setq k (max 1 (fix (/ ln (* 60.0 fac)))) i 1)
        (repeat k
          (setq d (+ (car s) (* ln (/ (float i) (1+ k))))
                f (rp:frame cl d)
                a (angle '(0.0 0.0) (caddr f)))
          (rp:arrow (rp:loc f (* -0.5 hw) 0.0) a fac elev)
          (rp:arrow (rp:loc f (* 0.5 hw) 0.0) (if two (+ a pi) a) fac elev)
          (setq n (+ n 2) i (1+ i))))))
  n)

;; Left-aligned text
(defun rp:ltext (str pt h lay / tx)
  (setq tx (vla-AddText *rp:spc* str (rp:p3 pt 0.0) h))
  (vla-put-Alignment tx acAlignmentMiddleLeft)
  (vla-put-TextAlignmentPoint tx (rp:p3 pt 0.0))
  (vla-put-Layer tx lay)
  tx)

;; Sign legend with real symbols, for the report
(defun rp:legend (pt sched th / lz x y seen pc)
  (setq lz (* 3.0 th) x (car pt) y (cadr pt))
  (rp:ltext "SIGN LEGEND" (list x y) (* 1.3 th) "ROAD-REPORT")
  (setq y (- y (* 1.6 lz)))
  (foreach r sched
    (if (not (member (nth 1 r) seen))
      (progn
        (setq seen (cons (nth 1 r) seen))
        (rp:draw-icon (nth 7 r) (list (+ x lz) y) (if (= (nth 7 r) "closed") (* 0.6 lz) lz) (nth 8 r) 0.0)
        (rp:ltext (nth 1 r) (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT")
        (setq y (- y (if (= (nth 7 r) "works") (* 2.0 lz) (* 1.5 lz)))))))
  ;; post, chevron board, lane arrow, ID tag
  (setq pc (vla-AddCircle *rp:spc* (rp:p3 (list (+ x lz) y) 0.0) (* 0.06 lz)))
  (vla-put-Layer pc "ROAD-SIGN")
  (rp:solidfill pc nil "ROAD-SIGN" 0.0)
  (rp:mkwpl (list (list (list (+ x lz) (- y (* 0.25 lz))) (* 0.05 lz) (* 0.05 lz))
                  (list (list (+ x lz) (+ y (* 0.25 lz))) 0.0 0.0))
            "ROAD-SIGN" 0.0)
  (rp:ltext "Sign post with plate (plate faces the traffic)" (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT")
  (setq y (- y (* 1.3 lz)))
  (rp:chevron (list (+ x lz) y) 0.0 lz 0.0)
  (rp:ltext "Chevron board (points into the bend)" (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT")
  (setq y (- y (* 1.3 lz)))
  (rp:arrow (list (+ x lz) y) 0.0 (/ lz 4.0) 0.0)
  (rp:ltext "Lane direction arrow (road marking)" (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT")
  (setq y (- y (* 1.3 lz)))
  (rp:text "SG-01" (list (+ x lz) y) (* 0.5 th) "ROAD-SIGN" 0.0)
  (rp:ltext "Sign ID - see SIGN SCHEDULE" (list (+ x (* 2.4 lz)) y) th "ROAD-REPORT"))

;;----------------------------------------------------------------------------
;;  Road ends : "0" tie-in line / "1" road closed / "2" none
;;  returns (red-units white-units road-closed-signs)
;;----------------------------------------------------------------------------
(defun rp:road-end (cl d atend mode hw blen bwid th fac sz elev ch / f in p s s2 cnt nr nw ln mt ip)
  (setq f (rp:frame cl d) in (if atend -1.0 1.0) p (car f) nr 0 nw 0)
  (cond
    ((= mode "0")
     (setq ln (vla-AddLine *rp:spc* (rp:p3 (rp:loc f (- (+ hw fac)) 0.0) elev)
                                    (rp:p3 (rp:loc f (+ hw fac) 0.0) elev)))
     (vla-put-Layer ln "ROAD-TIEIN")
     (vla-put-LinetypeScale ln (/ fac (getvar "LTSCALE")))
     (foreach s (list (- hw) 0.0 hw)
       (vla-put-Layer (vla-AddCircle *rp:spc* (rp:p3 (rp:loc f s 0.0) elev) (* 0.3 fac)) "ROAD-TIEIN"))
     (setq ip (rp:loc f 0.0 (* -1.0 in (+ fac (* 3.0 th))))
           mt (vla-AddMText *rp:spc* (rp:p3 ip elev) (* 30.0 th)
                (strcat "TIE-IN WITH EXISTING ROAD\\PCH " (rp:chfmt ch)
                        "\\PE " (rtos (/ (car p) fac) 2 3) "   N " (rtos (/ (cadr p) fac) 2 3))))
     (vla-put-Height mt th)
     (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
     (vla-put-InsertionPoint mt (rp:p3 ip elev))
     (vla-put-Layer mt "ROAD-TIEIN")
     (list 0 0 0))
    ((= mode "1")
     (setq s (- hw) cnt 0)
     (while (< s (- hw 1e-6))
       (setq s2 (min hw (+ s blen)))
       (if (> s2 (- hw (* 0.25 blen))) (setq s2 hw))
       (rp:solidfill
         (rp:poly (list (rp:loc f s 0.0) (rp:loc f s2 0.0)
                        (rp:loc f s2 (* in bwid)) (rp:loc f s (* in bwid)))
                  "ROAD-BARRIER-OUTLINE" elev)
         nil (if (= 0 (rem cnt 2)) "ROAD-BARRIER-RED" "ROAD-BARRIER-WHITE") elev)
       (if (= 0 (rem cnt 2)) (setq nr (1+ nr)) (setq nw (1+ nw)))
       (setq cnt (1+ cnt) s s2))
     (rp:sign-closed (rp:loc f 0.0 (* -1.0 in (+ fac (* 0.5 sz)))) sz elev)
     (list nr nw 1))
    (T (list 0 0 0))))

;;----------------------------------------------------------------------------
;;  Chainage
;;----------------------------------------------------------------------------
(defun rp:chfmt (v / km m s p)
  (setq v  (/ (fix (+ (* v 1000.0) (if (< v 0) -0.5 0.5))) 1000.0)
        km (fix (/ v 1000.0))
        m  (abs (- v (* km 1000.0)))
        s  (if (equal m (fix (+ m 0.5)) 0.0005) (itoa (fix (+ m 0.5))) (rtos m 2 3)))
  (while (< (if (setq p (vl-string-search "." s)) p (strlen s)) 3)
    (setq s (strcat "0" s)))
  (strcat (if (and (< v 0) (= km 0)) "-" "") (itoa km) "+" s))

(defun rp:chmark (cl d v hw lofs th elev / a b ip ang flip ln tx)
  (setq a    (rp:offpt cl d (- hw))
        b    (rp:offpt cl d hw)
        ip   (rp:offpt cl d lofs)
        ang  (angle a b)
        flip (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))))
  (setq ln (vla-AddLine *rp:spc* (rp:p3 a elev) (rp:p3 b elev)))
  (vla-put-Layer ln "ROAD-CHAINAGE")
  (setq tx (vla-AddText *rp:spc* (strcat "CH " (rp:chfmt v)) (rp:p3 ip elev) th))
  (vla-put-Layer tx "ROAD-CHAINAGE")
  (vla-put-Alignment tx (if flip acAlignmentMiddleRight acAlignmentMiddleLeft))
  (vla-put-TextAlignmentPoint tx (rp:p3 ip elev))
  (vla-put-Rotation tx (if flip (+ ang pi) ang)))

(defun rp:chainage (cl len fac hw lofs elev closed / iv st th k d dl n)
  (setq iv   (* fac (rp:num "chint"))
        st   (rp:num "chst")
        th   (* fac (rp:num "txth"))
        lofs (+ lofs (* 0.5 th))
        dl   (list 0.0)
        k    (fix (/ (* st fac) iv))
        d    (- (* (1+ k) iv) (* st fac)))
  (if (< d (* 0.001 iv)) (setq d (+ d iv)))
  (while (< d (- len (* 2.0 th)))
    (setq dl (cons d dl) d (+ d iv)))
  (if (not closed) (setq dl (cons len dl)))
  (setq n 0)
  (foreach x (reverse dl)
    (rp:chmark cl x (+ st (/ x fac)) hw lofs th elev)
    (setq n (1+ n)))
  n)

;;----------------------------------------------------------------------------
;;  Radius on plan : radius line + arrow + R value, centre mark, TC / CT ticks
;;  with chainage and a curve data label for every bend
;;----------------------------------------------------------------------------
(defun rp:towards (a b dist / l)
  (setq l (distance a b))
  (if (< l 1e-12)
    a
    (list (+ (car a)  (* dist (/ (- (car b) (car a)) l)))
          (+ (cadr a) (* dist (/ (- (cadr b) (cadr a)) l))))))

(defun rp:line (a b lay elev / ln)
  (setq ln (vla-AddLine *rp:spc* (rp:p3 a elev) (rp:p3 b elev)))
  (vla-put-Layer ln lay)
  ln)

;; Text beside the road at distance d, offset off (+ left / - right), reading outward
(defun rp:sidetext (cl d str off th lay elev / a ip ang flip tx)
  (setq a    (rp:offpt cl d 0.0)
        ip   (rp:offpt cl d off)
        ang  (angle a ip)
        flip (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))))
  (setq tx (vla-AddText *rp:spc* str (rp:p3 ip elev) th))
  (vla-put-Layer tx lay)
  (vla-put-Alignment tx (if flip acAlignmentMiddleRight acAlignmentMiddleLeft))
  (vla-put-TextAlignmentPoint tx (rp:p3 ip elev))
  (vla-put-Rotation tx (if flip (+ ang pi) ang)))

;; bl / br : barricades on left / right,  chon : chainage labels on (left side)
(defun rp:curve-labels (cl curves hw fac th st elev bl br chon bgap bwid atcl
                        / n c dir rr ri dm ctr edge sp ang rot mid ah tx mt lo ix)
  (setq n 0)
  (foreach c curves
    (setq n (1+ n))                                        ; same numbers as report C1, C2...
    (if (> (nth 3 c) 0.0175)                               ; ignore bends under 1 deg
      (progn
        (setq dir  (nth 4 c)                               ; +1 left turn / -1 right turn
              rr   (nth 2 c)                               ; radius at centre line
              ri   (- rr hw)                               ; radius at inner edge
              dm   (* 0.5 (+ (car c) (cadr c)))            ; middle of the curve
              ctr  (rp:offpt cl dm (* dir rr))             ; curve centre point
              edge (rp:offpt cl dm (* dir hw)))            ; inner edge, mid curve
        (if atcl (setq edge (rp:offpt cl dm 0.0)))         ; radius shown to the centre line
        (if (> ri 0.0)
          (progn
            ;; radius line : full from centre, or a short leader for big radii
            (setq sp (if (<= ri (* 50.0 fac)) ctr (rp:towards edge ctr (* 12.0 th)))
                  ah (rp:towards edge sp (* 0.7 th)))
            (rp:mkwpl (list (list sp 0.0 0.0) (list ah (* 0.35 th) 0.0) (list edge 0.0 0.0))
                      "ROAD-CURVE" elev)
            ;; centre mark
            (if (equal sp ctr 1e-9)
              (progn
                (rp:line (polar ctr 0.0 (* 0.6 th)) (polar ctr pi (* 0.6 th)) "ROAD-CURVE" elev)
                (rp:line (polar ctr (* 0.5 pi) (* 0.6 th)) (polar ctr (* 1.5 pi) (* 0.6 th))
                         "ROAD-CURVE" elev)))
            ;; R value along the radius line (always readable)
            (setq ang (angle sp edge)
                  rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang)
                  mid (polar (rp:towards sp edge (* 0.5 (distance sp edge))) (+ rot (* 0.5 pi)) (* 0.7 th))
                  tx  (rp:text (strcat "R=" (rtos (/ (if atcl rr ri) fac) 2 2) (if atcl " CL" ""))
                               mid th "ROAD-CURVE" elev))
            (vla-put-Rotation tx rot)
            ;; curve data label, beyond the start of the radius line
            (setq ix (polar sp (angle edge sp) (* 3.5 th))
                  mt (vla-AddMText *rp:spc* (rp:p3 ix elev) 0.0
                       (strcat "C" (itoa n)
                               "\\PR inner = " (rtos (/ ri fac) 2 3) " m"
                               "\\PR CL = "    (rtos (/ rr fac) 2 3) " m"
                               "\\PR outer = " (rtos (/ (+ rr hw) fac) 2 3) " m"
                               "\\PL (CL) = "  (rtos (/ (- (cadr c) (car c)) fac) 2 3) " m"
                               "\\PA = " (rtos (/ (* 2.0 hw (- (cadr c) (car c))) fac fac) 2 2) " m\\U+00B2"
                               "\\P\\U+0394 = " (vl-string-subst "\\U+00B0" "%%d" (rp:dms (nth 3 c) T)))))
            (vla-put-Height mt (* 0.8 th))
            (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
            (vla-put-InsertionPoint mt (rp:p3 ix elev))
            (vla-put-Layer mt "ROAD-CURVE")))
        ;; TC / CT ticks across the road + labels on the inner side
        (setq lo (* dir (+ hw
                           (if (if (> dir 0) bl br) (+ bgap bwid) 0.0)
                           (* 0.3 fac) (* 0.5 th)
                           (if (and chon (> dir 0)) (* 11.0 th) 0.0))))
        (foreach tp (list (list (car c) "TC") (list (cadr c) "CT"))
          (rp:line (rp:offpt cl (car tp) (- hw)) (rp:offpt cl (car tp) hw) "ROAD-CURVE" elev)
          (rp:sidetext cl (car tp)
                       (strcat (cadr tp) (itoa n) "  " (rp:chfmt (+ st (/ (car tp) fac))))
                       lo (* 0.8 th) "ROAD-CURVE" elev)))))
  n)

;;----------------------------------------------------------------------------
;;  Straight sections : list of (dist-start dist-end direction-angle P1 P2)
;;----------------------------------------------------------------------------
(defun rp:straights (o / n i p1 p2 lst)
  (setq n (fix (+ 0.5 (vlax-curve-getEndParam o))) i 0)
  (repeat n
    (if (< (abs (vla-GetBulge o i)) 1e-9)
      (progn
        (setq p1 (vlax-curve-getPointAtParam o i)
              p2 (vlax-curve-getPointAtParam o (1+ i)))
        (if (> (distance p1 p2) 1e-6)
          (setq lst (cons (list (vlax-curve-getDistAtParam o i)
                                (vlax-curve-getDistAtParam o (1+ i))
                                (angle p1 p2) p1 p2)
                          lst)))))
    (setq i (1+ i)))
  (reverse lst))

;; Whole-circle bearing (from North, clockwise) of a drawing angle
(defun rp:brg (ang) (rem (+ (- (* 0.5 pi) ang) (* 4.0 pi)) (* 2.0 pi)))

;; Plan labels for straights, on the right side beyond barricades and signs
;; ob = clear distance from the centre line to start drawing
(defun rp:straight-labels (cl strs hw fac th st elev ob / n s d1 d2 od ot ang rot ip mt)
  (setq n  0
        od (- (+ ob (* 0.8 th)))          ; extent bar
        ot (- (+ ob (* 4.2 th))))         ; label centre
  (foreach s strs
    (setq n  (1+ n)
          d1 (car s)
          d2 (cadr s))
    ;; extent bar with end ticks
    (rp:line (rp:offpt cl d1 od) (rp:offpt cl d2 od) "ROAD-SECTION" elev)
    (rp:line (rp:offpt cl d1 (+ od (* 0.6 th))) (rp:offpt cl d1 (- od (* 0.6 th))) "ROAD-SECTION" elev)
    (rp:line (rp:offpt cl d2 (+ od (* 0.6 th))) (rp:offpt cl d2 (- od (* 0.6 th))) "ROAD-SECTION" elev)
    ;; label, parallel to the road and always readable
    (setq ang (nth 2 s)
          rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang)
          ip  (rp:offpt cl (* 0.5 (+ d1 d2)) ot)
          mt  (vla-AddMText *rp:spc* (rp:p3 ip elev) 0.0
                (strcat "S" (itoa n) "  STRAIGHT"
                        "\\PL = " (rtos (/ (- d2 d1) fac) 2 3) " m    A = "
                        (rtos (/ (* 2.0 hw (- d2 d1)) fac fac) 2 2) " m\\U+00B2"
                        "\\PCH " (rp:chfmt (+ st (/ d1 fac))) " - " (rp:chfmt (+ st (/ d2 fac)))
                        "\\PBRG " (vl-string-subst "\\U+00B0" "%%d" (rp:dms (rp:brg ang) T)))))
    (vla-put-Height mt (* 0.8 th))
    (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
    (vla-put-InsertionPoint mt (rp:p3 ip elev))
    (vla-put-Rotation mt rot)
    (vla-put-Layer mt "ROAD-SECTION"))
  n)

;;----------------------------------------------------------------------------
;;  Road data stored on the centre line (XDATA) - used by ROADREPORT
;;----------------------------------------------------------------------------
(defun rp:xput (e alst)
  (regapp "ROADPRO")
  (entmod (append (entget e)
                  (list (list -3 (cons "ROADPRO"
                                       (mapcar '(lambda (p) (cons 1000 (strcat (car p) "=" (cdr p))))
                                               alst)))))))

(defun rp:xget (e / x p)
  (setq x (cdr (assoc "ROADPRO" (cdr (assoc -3 (entget e '("ROADPRO")))))))
  (mapcar '(lambda (g / s)
             (setq s (cdr g) p (vl-string-search "=" s))
             (if p (cons (substr s 1 p) (substr s (+ p 2))) (cons s "")))
          x))

(defun rp:xv (k data / v) (if (setq v (cdr (assoc k data))) v ""))

(defun rp:pair (r) (if r (strcat (itoa (car r)) "," (itoa (cadr r))) "0,0"))

(defun rp:pairget (s / p)
  (if (and s (setq p (vl-string-search "," s)))
    (list (atoi (substr s 1 p)) (atoi (substr s (+ p 2))))
    (list 0 0)))

;;----------------------------------------------------------------------------
;;  Report
;;----------------------------------------------------------------------------
(defun rp:today () (menucmd "M=$(edtime,$(getvar,date),DD-MON-YYYY)"))

(defun rp:pad (s n) (while (< (strlen s) n) (setq s (strcat s " "))) s)

(defun rp:fm (v) (strcat (rtos v 2 3) " m"))

(defun rp:z2 (n) (if (< n 10) (strcat "0" (itoa n)) (itoa n)))

(defun rp:dms (a tbl / ts d m s)
  (setq ts (fix (+ (* (/ a pi) 648000.0) 0.5))
        d  (/ ts 3600)
        m  (/ (rem ts 3600) 60)
        s  (rem ts 60))
  (if tbl
    (strcat (itoa d) "%%d" (rp:z2 m) "'" (rp:z2 s) "\"")
    (strcat (itoa d) "d " (rp:z2 m) "m " (rp:z2 s) "s")))

(defun rp:brow (lbl pr)
  (if (> (+ (car pr) (cadr pr)) 0)
    (list lbl (strcat (itoa (car pr)) " red + " (itoa (cadr pr)) " white = "
                      (itoa (+ (car pr) (cadr pr))) " units"))))

(defun rp:endtxt (mode p fac)
  (strcat (cond ((= mode "0") "Tie-in") ((= mode "1") "Road closed")
                ((= mode "2") "Open end") ((= mode "3") "Junction") (T "Closed loop"))
          "  E " (rtos (/ (car p) fac) 2 3) "  N " (rtos (/ (cadr p) fac) 2 3)))

(defun rp:join (lst sep)
  (if lst (apply 'strcat (cons (car lst) (mapcar '(lambda (x) (strcat sep x)) (cdr lst)))) ""))

(defun rp:csv (f lst)
  (write-line
    (rp:join (mapcar '(lambda (s) (strcat "\"" (vl-string-translate "\"" "'" s) "\"")) lst) ",")
    f))

(defun rp:write-csv (path title rows crows srows secs signs wsto tsto jsto / f)
  (if (setq f (open path "w"))
    (progn
      (rp:csv f (list title))
      (foreach r rows
        (if (= (car r) "#")
          (progn (rp:csv f '("")) (rp:csv f (list (cadr r))))
          (rp:csv f r)))
      (rp:csv f '(""))
      (rp:csv f '("CURVE DATA"))
      (rp:csv f '("No" "Turn" "TC Chainage" "CT Chainage" "Radius CL (m)" "Arc Length CL (m)"
                  "Deflection" "TC Easting" "TC Northing" "CT Easting" "CT Northing"))
      (if crows (foreach r crows (rp:csv f r)) (rp:csv f '("-" "No curves")))
      (rp:csv f '(""))
      (rp:csv f '("ROAD SECTIONS"))
      (rp:csv f '("Section" "Type" "From Chainage" "To Chainage" "Length CL (m)"
                  "Left Edge (m)" "Right Edge (m)" "Area (m2)" "Bearing / Radius"))
      (foreach r secs (rp:csv f r))
      (rp:csv f '(""))
      (rp:csv f '("SIGN SCHEDULE"))
      (rp:csv f '("Sign ID" "Sign" "Chainage" "Side" "Facing traffic" "Post Easting" "Post Northing"))
      (foreach r signs (rp:csv f r))
      (if wsto
        (progn
          (rp:csv f '(""))
          (rp:csv f '("LANE WIDENING SETTING-OUT (new road edge)"))
          (rp:csv f '("Widening" "Point" "Chainage" "Offset from CL (m, + left)" "Easting" "Northing"))
          (foreach r wsto (rp:csv f r))))
      (if tsto
        (progn
          (rp:csv f '(""))
          (rp:csv f '("ROAD TAPER SETTING-OUT (new road edge)"))
          (rp:csv f '("Taper" "Point" "Chainage" "Offset from CL (m, + left)" "Easting" "Northing"))
          (foreach r tsto (rp:csv f r))))
      (if jsto
        (progn
          (rp:csv f '(""))
          (rp:csv f '("JUNCTION SETTING-OUT (kerb returns)"))
          (rp:csv f '("Junction" "Point" "Chainage" "Easting" "Northing"))
          (foreach r jsto (rp:csv f r))))
      (rp:csv f '(""))
      (rp:csv f '("SETTING-OUT DATA"))
      (rp:csv f '("Point" "Chainage" "CL Easting" "CL Northing" "Left Edge Easting"
                  "Left Edge Northing" "Right Edge Easting" "Right Edge Northing"))
      (foreach r srows (rp:csv f r))
      (close f)
      path)
    (progn (princ (strcat "\nCould not write " path " - is it open in Excel?")) nil)))

(defun rp:mktable (pt title hdr rows cw th / nc nr tb r c)
  (setq nc (length cw)
        nr (+ 2 (length rows))
        tb (vla-AddTable *rp:spc* (vlax-3d-point pt) nr nc (* 1.8 th) (car cw)))
  (vla-put-RegenerateTableSuppressed tb :vlax-true)
  (vla-put-Layer tb "ROAD-REPORT")
  (vl-catch-all-apply 'vla-put-HorzCellMargin (list tb (* 0.4 th)))
  (vl-catch-all-apply 'vla-put-VertCellMargin (list tb (* 0.3 th)))
  (vla-SetTextHeight tb acTitleRow (* 1.3 th))
  (vla-SetTextHeight tb acHeaderRow th)
  (vla-SetTextHeight tb acDataRow th)
  (setq c 0)
  (foreach wd cw (vla-SetColumnWidth tb c wd) (setq c (1+ c)))
  (vla-SetText tb 0 0 title)
  (setq c 0)
  (foreach h hdr (vla-SetText tb 1 c h) (setq c (1+ c)))
  (setq r 2)
  (foreach row rows
    (if (= (car row) "#")
      (progn
        (vla-MergeCells tb r r 0 (1- nc))
        (vla-SetText tb r 0 (cadr row))
        (vla-SetCellAlignment tb r 0 acMiddleLeft))
      (progn
        (setq c 0)
        (foreach s row
          (if (< c nc)
            (progn
              (vla-SetText tb r c s)
              (vla-SetCellAlignment tb r c (if (= c 0) acMiddleLeft acMiddleCenter))))
          (setq c (1+ c)))))
    (setq r (1+ r)))
  (vla-put-RegenerateTableSuppressed tb :vlax-false)
  tb)

(defun rp:tables (pt name rows ctab srows sect schd sched wsto tsto jsto th / x t1)
  (setq t1 (rp:mktable pt (strcat "ROAD REPORT - " name) '("DESCRIPTION" "VALUE")
                       rows (list (* 28.0 th) (* 28.0 th)) th))
  (if sched
    (rp:legend (list (car pt) (- (cadr pt) (vla-get-Height t1) (* 5.0 th))) sched th))
  (setq x (+ (car pt) (* 59.0 th)))
  (rp:mktable (list x (cadr pt) 0.0) "CURVE DATA"
              '("No" "TURN" "TC CH" "CT CH" "RADIUS (m)" "ARC (m)" "DEFLECTION")
              (if ctab ctab (list (list "-" "No curves" "" "" "" "" "")))
              (mapcar '(lambda (k) (* k th)) '(4.0 6.0 10.0 10.0 9.0 8.0 11.0)) th)
  (setq x (+ x (* 61.0 th)))
  (rp:mktable (list x (cadr pt) 0.0) "SETTING-OUT DATA"
              '("POINT" "CHAINAGE" "CL E" "CL N" "LEFT E" "LEFT N" "RIGHT E" "RIGHT N")
              srows (mapcar '(lambda (k) (* k th)) '(9.0 10.0 12.0 12.0 12.0 12.0 12.0 12.0)) th)
  (setq x (+ x (* 93.0 th)))
  (rp:mktable (list x (cadr pt) 0.0) "ROAD SECTIONS"
              '("SEC" "TYPE" "FROM CH" "TO CH" "LENGTH (m)" "LEFT (m)" "RIGHT (m)" "AREA (m2)" "BEARING / RADIUS")
              sect (mapcar '(lambda (k) (* k th)) '(5.0 8.0 10.0 10.0 9.0 9.0 9.0 10.0 15.0)) th)
  (setq x (+ x (* 87.0 th)))
  (rp:mktable (list x (cadr pt) 0.0) "SIGN SCHEDULE"
              '("ID" "SIGN" "CHAINAGE" "SIDE" "FACING TRAFFIC" "POST E" "POST N")
              schd (mapcar '(lambda (k) (* k th)) '(6.0 18.0 10.0 9.0 13.0 12.0 12.0)) th)
  (if wsto
    (progn
      (setq x (+ x (* 82.0 th)))
      (rp:mktable (list x (cadr pt) 0.0) "LANE WIDENING SETTING-OUT"
                  '("WIDENING" "POINT" "CHAINAGE" "OFFSET (m)" "EASTING" "NORTHING")
                  wsto (mapcar '(lambda (k) (* k th)) '(9.0 7.0 10.0 10.0 12.0 12.0)) th)))
  (if tsto
    (progn
      (setq x (+ x (if wsto (* 62.0 th) (* 82.0 th))))
      (rp:mktable (list x (cadr pt) 0.0) "ROAD TAPER SETTING-OUT"
                  '("TAPER" "POINT" "CHAINAGE" "OFFSET (m)" "EASTING" "NORTHING")
                  tsto (mapcar '(lambda (k) (* k th)) '(9.0 7.0 10.0 10.0 12.0 12.0)) th)))
  (if jsto
    (progn
      (setq x (+ x (if (or wsto tsto) (* 62.0 th) (* 82.0 th))))
      (rp:mktable (list x (cadr pt) 0.0) "JUNCTION SETTING-OUT"
                  '("JUNCTION" "POINT" "CHAINAGE" "EASTING" "NORTHING")
                  jsto (mapcar '(lambda (k) (* k th)) '(9.0 9.0 14.0 12.0 12.0)) th))))

;; Main report : full = T  -> command line + CSV + tables in drawing
;;               full = nil -> command line only
(defun rp:report-make (e full / data fac w hw obj len closed st iv curves tsum rin rc
                         bl br bc be nr nw ns rows ctab ccsv srows pts mp i k d p pl pr
                         name path pt th lbl strs sl cl secs sect secc a q
                         sched sgrows cnt schd wid wrows wsto wtot tr ttot jr mq mrows)
  (setq data (rp:xget e)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq w        (* fac (atof (rp:xv "W" data)))
        hw       (* 0.5 w)
        obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        closed   (vlax-curve-isClosed obj)
        st       (atof (rp:xv "CHST" data))
        iv       (* fac (atof (rp:xv "CHINT" data)))
        curves   (rp:curves obj)
        name     (rp:xv "NAME" data)
        tsum     0.0)
  (foreach c curves (setq tsum (+ tsum (* (nth 4 c) (nth 3 c)))))
  (setq strs (rp:straights obj) sl 0.0 cl 0.0)
  (foreach s strs (setq sl (+ sl (- (cadr s) (car s)))))
  (foreach c curves (setq cl (+ cl (- (cadr c) (car c)))))
  (setq rin (atof (rp:xv "RIN" data))
        rc  (cond ((<= rin 0.0) 0.0)
                  ((= (rp:xv "RREF" data) "0") (+ rin (/ hw fac)))
                  (T rin))
        bl  (rp:pairget (rp:xv "BL" data))
        br  (rp:pairget (rp:xv "BR" data))
        bc  (rp:pairget (rp:xv "BC" data))
        be  (rp:pairget (rp:xv "BE" data))
        nr  (+ (car bl) (car br) (car bc) (car be))
        nw  (+ (cadr bl) (cadr br) (cadr bc) (cadr be))
        ns  (+ (atoi (rp:xv "NSPD" data)) (atoi (rp:xv "NWRN" data))
               (atoi (rp:xv "NCHV" data)) (atoi (rp:xv "NCLS" data))))
  ;; ---- signs : from the sign schedule (older roads : stored counts) ----
  (setq sched (vlax-ldata-get obj "ROADPRO_SIGNS"))
  (if sched
    (progn
      (foreach r sched
        (if (setq a (assoc (nth 1 r) cnt))
          (setq cnt (subst (cons (car a) (1+ (cdr a))) a cnt))
          (setq cnt (cons (cons (nth 1 r) 1) cnt))))
      (setq sgrows (mapcar '(lambda (x) (list (car x) (itoa (cdr x)))) (reverse cnt))))
    (setq sgrows (list (list (strcat "Speed limit signs (" (rp:xv "SPEED" data) " km/h)") (rp:xv "NSPD" data))
                       (list "Curve warning signs" (rp:xv "NWRN" data))
                       (list "ROAD CLOSED signs" (rp:xv "NCLS" data)))))
  ;; ---- lane widening ----
  (setq wid (vlax-ldata-get obj "ROADPRO_WIDEN") wtot 0.0)
  (if wid
    (progn
      (setq wrows (list '("#" "LANE WIDENING")))
      (foreach r wid
        (setq wtot  (+ wtot (atof (nth 9 r)))
              wrows (append wrows
                            (list (list (strcat (car r) " - " (cadr r) " side")
                                        (strcat "+" (caddr r) " m,  CH " (nth 3 r) " - " (nth 4 r)))
                                  (list (strcat "   " (car r) " taper in / out")
                                        (strcat (nth 5 r) " / " (nth 6 r) " m,  " (nth 7 r)))
                                  (list (strcat "   " (car r) " match points") (nth 8 r))
                                  (list (strcat "   " (car r) " area") (strcat (nth 9 r) " m2")))))
        (foreach q (nth 10 r) (setq wsto (cons q wsto))))
      (setq wsto  (reverse wsto)
            wrows (append wrows
                          (list (list "Widening area total" (strcat (rtos wtot 2 2) " m2"))
                                (list "Total paved area (road + widening)"
                                      (strcat (rtos (+ (/ (* w len) fac fac) wtot) 2 2) " m2")))))))
  ;; ---- junctions ----
  (setq jr (rp:junc-report obj))
  ;; ---- road markings (paint quantities) ----
  (setq mq (vlax-ldata-get obj "ROADPRO_MKQTY"))
  (if mq
    (setq mrows (list '("#" "ROAD MARKINGS (white, 150 mm)")
                      (list "Edge lines (both sides)" (strcat (rtos (/ (car mq) fac) 2 1) " m"))
                      (list "Lane line, broken 3 m / 6 m" (strcat (rtos (/ (cadr mq) fac) 2 1) " m"))
                      (list "Lane line, solid (bends, junctions)" (strcat (rtos (/ (caddr mq) fac) 2 1) " m"))
                      (list "Total line length / paint area"
                            (strcat (rtos (/ (+ (car mq) (cadr mq) (caddr mq)) fac) 2 1) " m  /  "
                                    (rtos (* 0.15 (/ (+ (car mq) (cadr mq) (caddr mq)) fac)) 2 2) " m2")))))
  ;; ---- road tapers ----
  (setq tr   (rp:taper-report obj fac hw st iv len)
        ttot (if tr (list (list "Total paved area (road + widening + tapers)"
                                (strcat (rtos (+ (/ (* w len) fac fac) wtot (caddr tr)) 2 2) " m2")))))
  ;; ---- summary rows ----
  (setq rows
    (vl-remove nil
     (append
      (list
        '("#" "GENERAL")
        (list "Road name / ID" name)
        (list "Report date" (rp:today))
        (list "Road created" (rp:xv "DATE" data))
        (list "Drawing" (getvar "DWGNAME"))
        (list "Drawing units" (if (= fac 1.0) "Meters" "Millimeters"))
        '("#" "GEOMETRY")
        (list "Start chainage" (rp:chfmt st))
        (list "End chainage" (rp:chfmt (+ st (/ len fac))))
        (list "Centre line length" (rp:fm (/ len fac)))
        (list "Road width" (rp:fm (/ w fac)))
        (list "Left edge length" (rp:fm (/ (- len (* hw tsum)) fac)))
        (list "Right edge length" (rp:fm (/ (+ len (* hw tsum)) fac)))
        (list "Road surface area" (strcat (rtos (/ (* w len) fac fac) 2 2) " m2"))
        (list "Straight sections" (strcat (itoa (length strs)) "  (total " (rp:fm (/ sl fac)) ")"))
        (list "Curve sections" (strcat (itoa (length curves)) "  (total " (rp:fm (/ cl fac)) ")"))
        (list "Design turning radius"
              (if (> rc 0.0)
                (strcat "inner " (rtos (- rc (/ hw fac)) 2 2) " / CL " (rtos rc 2 2)
                        " / outer " (rtos (+ rc (/ hw fac)) 2 2) " m")
                "none"))
        (list "Minimum CL radius"
              (if curves (rp:fm (/ (apply 'min (mapcar 'caddr curves)) fac)) "-"))
        '("#" "BARRICADES (RED / WHITE)")
        (list "Unit size (L x W)" (strcat (rp:xv "BLEN" data) " x " (rp:xv "BWID" data) " m"))
        (list "Gap from road edge" (strcat (rp:xv "BGAP" data) " m"))
        (rp:brow "Left side" bl)
        (rp:brow "Right side" br)
        (rp:brow "Centre median" bc)
        (rp:brow "Road-end closures" be)
        (list "TOTAL barricades" (strcat (itoa nr) " red + " (itoa nw) " white = "
                                         (itoa (+ nr nw)) " units"))
        '("#" "SIGNS AND MARKINGS"))
      sgrows
      (list
        (list "TOTAL signs" (if sched (itoa (length sched)) (itoa ns)))
        (list "Chevron boards on bends" (if (= (rp:xv "NCHV" data) "") "0" (rp:xv "NCHV" data)))
        (list "Lane direction arrows" (if (= (rp:xv "NARR" data) "") "0" (rp:xv "NARR" data)))
        '("#" "ROAD ENDS")
        (list "Start" (rp:endtxt (rp:xv "ENDS" data) (rp:offpt obj 0.0 0.0) fac))
        (list "Finish" (rp:endtxt (rp:xv "ENDF" data) (rp:offpt obj len 0.0) fac))
        '("#" "CHAINAGE")
        (list "Interval" (rp:fm (/ iv fac)))
        (list "Chainage marks" (rp:xv "NCHM" data)))
      wrows (car tr) ttot (car jr) mrows)))
  ;; ---- command line ----
  (princ "\n")
  (princ "\n==================== ROAD PRO - REPORT ====================")
  (foreach r rows
    (if (= (car r) "#")
      (princ (strcat "\n  [" (cadr r) "]"))
      (princ (strcat "\n    " (rp:pad (car r) 30) ": " (cadr r)))))
  (princ "\n===========================================================")
  (if full
    (progn
      ;; ---- curve data ----
      (setq i 1)
      (foreach c curves
        (setq k (list (itoa i) (if (> (nth 4 c) 0) "Left" "Right")
                      (rp:chfmt (+ st (/ (car c) fac))) (rp:chfmt (+ st (/ (cadr c) fac)))
                      (rtos (/ (nth 2 c) fac) 2 3) (rtos (/ (- (cadr c) (car c)) fac) 2 3)))
        (setq ctab (cons (append k (list (rp:dms (nth 3 c) T))) ctab)
              ccsv (cons (append k (list (rp:dms (nth 3 c) nil)
                                         (rtos (/ (car (nth 5 c)) fac) 2 3)
                                         (rtos (/ (cadr (nth 5 c)) fac) 2 3)
                                         (rtos (/ (car (nth 6 c)) fac) 2 3)
                                         (rtos (/ (cadr (nth 6 c)) fac) 2 3)))
                         ccsv)
              i    (1+ i)))
      (setq ctab (reverse ctab) ccsv (reverse ccsv))
      ;; ---- setting-out points ----
      (setq pts (list (cons 0.0 "START")))
      (if (not closed) (setq pts (cons (cons len "END") pts)))
      (if (> iv 0.0)
        (progn
          (setq k (fix (/ (* st fac) iv))
                d (- (* (1+ k) iv) (* st fac)))
          (if (< d (* 0.001 iv)) (setq d (+ d iv)))
          (while (< d (- len (* 0.001 iv)))
            (setq pts (cons (cons d "CH") pts) d (+ d iv)))))
      (setq i 1)
      (foreach c curves
        (setq pts (cons (cons (car c) (strcat "TC" (itoa i)))
                        (cons (cons (cadr c) (strcat "CT" (itoa i))) pts))
              i   (1+ i)))
      (setq pts (vl-sort pts '(lambda (a b) (< (car a) (car b)))))
      (foreach q pts
        (if (and mp (< (- (car q) (caar mp)) (* 0.001 fac)))
          (setq mp (cons (cons (caar mp)
                               (cond ((= (cdar mp) "CH") (cdr q))
                                     ((= (cdr q) "CH") (cdar mp))
                                     (T (strcat (cdar mp) "/" (cdr q)))))
                         (cdr mp)))
          (setq mp (cons q mp))))
      (foreach q (reverse mp)
        (setq p  (rp:offpt obj (car q) 0.0)
              pl (rp:offpt obj (car q) hw)
              pr (rp:offpt obj (car q) (- hw))
              srows (cons (list (cdr q) (rp:chfmt (+ st (/ (car q) fac)))
                                (rtos (/ (car p) fac) 2 3)  (rtos (/ (cadr p) fac) 2 3)
                                (rtos (/ (car pl) fac) 2 3) (rtos (/ (cadr pl) fac) 2 3)
                                (rtos (/ (car pr) fac) 2 3) (rtos (/ (cadr pr) fac) 2 3))
                          srows)))
      (setq srows (reverse srows))
      ;; ---- road sections : straights and curves in road order ----
      (setq i 0)
      (foreach s strs
        (setq i (1+ i) secs (cons (list (car s) (strcat "S" (itoa i)) s) secs)))
      (setq i 0)
      (foreach c curves
        (setq i (1+ i) secs (cons (list (car c) (strcat "C" (itoa i)) c) secs)))
      (setq secs (vl-sort secs '(lambda (a b) (< (car a) (car b)))))
      (foreach q secs
        (setq a (caddr q)
              d (- (cadr a) (car a))
              k (list (cadr q)
                      (if (= (substr (cadr q) 1 1) "S")
                        "Straight"
                        (if (> (nth 4 a) 0) "Curve Left" "Curve Right"))
                      (rp:chfmt (+ st (/ (car a) fac)))
                      (rp:chfmt (+ st (/ (cadr a) fac)))
                      (rtos (/ d fac) 2 3)
                      (rtos (/ (if (= (substr (cadr q) 1 1) "S") d (- d (* (nth 4 a) hw (nth 3 a)))) fac) 2 3)
                      (rtos (/ (if (= (substr (cadr q) 1 1) "S") d (+ d (* (nth 4 a) hw (nth 3 a)))) fac) 2 3)
                      (rtos (/ (* w d) fac fac) 2 2)))
        (if (= (substr (cadr q) 1 1) "S")
          (setq sect (cons (append k (list (strcat "BRG " (rp:dms (rp:brg (nth 2 a)) T)))) sect)
                secc (cons (append k (list (strcat "BRG " (rp:dms (rp:brg (nth 2 a)) nil)))) secc))
          (setq sect (cons (append k (list (strcat "R " (rtos (/ (nth 2 a) fac) 2 3) " m (CL)"))) sect)
                secc (cons (append k (list (strcat "R " (rtos (/ (nth 2 a) fac) 2 3) " m (CL)"))) secc))))
      (setq sect (reverse sect) secc (reverse secc))
      ;; ---- sign schedule ----
      (setq schd (if sched
                   (mapcar '(lambda (r) (list (nth 0 r) (nth 1 r) (nth 2 r) (nth 3 r)
                                              (nth 4 r) (nth 5 r) (nth 6 r)))
                           sched)
                   (list (list "-" "No sign schedule" "" "" "" "" ""))))
      ;; ---- Excel (CSV) ----
      (setq path (rp:write-csv
                   (strcat (getvar "DWGPREFIX")
                           (vl-string-translate "\\/:*?\"<>| " "__________" name)
                           "_RoadPro_Report.csv")
                   (strcat "ROAD PRO REPORT - " name) rows ccsv srows secc schd wsto (cadr tr) (cadr jr)))
      (if path (princ (strcat "\n  Excel report saved : " path)))
      ;; ---- tables in drawing ----
      (setq th (* 0.8 fac (rp:num "txth")))
      (if (setq pt (getpoint "\nPick top-left corner for report tables <Enter = skip>: "))
        (rp:tables pt name rows ctab srows sect schd sched wsto (cadr tr) (cadr jr) th))
      (if path
        (progn
          (initget "Yes No")
          (if (/= (getkword "\nOpen the Excel report now? [Yes/No] <Yes>: ") "No")
            (startapp "explorer" (strcat "\"" path "\"")))))))
  (princ))

;;----------------------------------------------------------------------------
;;  Main builder
;;----------------------------------------------------------------------------
(defun rp:run (/ fac w hw rad0 rc ri blen bwid bgap step cl obj len elev closed lt
                 e1 e2 surf resL resR resC resE nch curves strs sz th st ends endf r
                 offR offL sched nChv nArr nCls)
  (rp:space)
  (setq *rp:hatches* nil
        fac  (if (= (rp:val "units") "1") 1000.0 1.0)
        w    (* fac (rp:num "width"))
        hw   (* 0.5 w)
        rad0 (* fac (rp:num "radius"))
        blen (* fac (rp:num "blen"))
        bwid (* fac (rp:num "bwid"))
        bgap (* fac (rp:num "bgap"))
        rc   (cond ((<= rad0 0.0) 0.0)
                   ((= (rp:val "rref") "1") (+ rad0 hw))     ; radius given at inner edge
                   (T rad0))                                  ; radius given at centre line
        ri   (- rc hw))
  (cond
    ((and (> rc 0.0) (<= ri 0.0))
     (alert (strcat "Turning radius is too small for this road width.\n\n"
                    "Measured at the centre line it must be more than half\n"
                    "the road width (" (rtos (/ hw fac) 2 2) " m).")))
    (T
     (rp:world)
     (rp:linetypes)
     (rp:layers)
     (if (setq cl (rp:get-centreline))
       (progn
         ;; 1. turning radius at every bend
         (if (> rc 0.0)
           (progn (setvar "FILLETRAD" rc) (command "_.FILLET" "_P" cl)))
         (setq obj      (vlax-ename->vla-object cl)
               elev     (vla-get-Elevation obj)
               closed   (vlax-curve-isClosed obj)
               len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
               *rp:len* len
               curves   (rp:curves obj))
         (vl-catch-all-apply 'vla-put-ConstantWidth (list obj 0.0))
         ;; 2. road edges
         (setq e1 (rp:offset obj hw)
               e2 (rp:offset obj (- hw)))
         (foreach o (append e1 e2) (rp:props o "ROAD-EDGE" "ByLayer" 1.0))
         ;; 3. centre line
         (setq lt (rp:cl-ltype))
         (rp:props obj "ROAD-CL" lt (/ fac (getvar "LTSCALE")))
         ;; 4. road surface
         (if (rp:on "hatch") (setq surf (rp:surface obj e1 e2 elev)))
         ;; 5. barricades
         (if (and (> rc 0.0) (or (rp:on "bl") (rp:on "br")) (<= ri (+ bgap bwid)))
           (princ "\nWarning: barricades on the inside of bends are tighter than the radius - increase the radius or reduce the barricade width/gap."))
         (setq step (min blen (* 0.5 fac)))
         (if (rp:on "bl")
           (setq resL (rp:barrier obj len (+ hw bgap) (+ hw bgap bwid) blen step elev)))
         (if (rp:on "br")
           (setq resR (rp:barrier obj len (- (+ hw bgap)) (- (+ hw bgap bwid)) blen step elev)))
         (if (rp:on "bc")
           (setq resC (rp:barrier obj len (* -0.5 bwid) (* 0.5 bwid) blen step elev)))
         ;; 6. chainage
         (setq th (* fac (rp:num "txth"))
               st (rp:num "chst"))
         (if (rp:on "ch")
           (setq nch (rp:chainage obj len fac hw
                                  (+ hw (if (rp:on "bl") (+ bgap bwid) 0.0) (* 0.3 fac))
                                  elev closed)))
         ;; 6b. radius, TC / CT and curve data on plan
         (if (rp:on "rlab")
           (rp:curve-labels obj curves hw fac th st elev (rp:on "bl") (rp:on "br")
                            (rp:on "ch") bgap bwid (= (rp:val "rref") "0")))
         ;; 6c. straight sections on plan (right side, beyond barricades and signs)
         (setq sz   (* fac (rp:num "signsz"))
               offR (+ hw (if (rp:on "br") (+ bgap bwid) 0.0) (* 0.5 fac))
               offL (+ hw (if (rp:on "bl") (+ bgap bwid) 0.0) (* 0.5 fac))
               strs (rp:straights obj))
         (if (rp:on "slab")
           (rp:straight-labels obj strs hw fac th st elev (+ offR (* 0.6 fac) (* 1.5 sz))))
         ;; 7. road ends
         (setq resE (list 0 0)
               nCls 0
               ends (if closed "-" (rp:val "endst"))
               endf (if closed "-" (rp:val "endfn")))
         (if (not closed)
           (foreach en (list (list 0.0 nil ends) (list len T endf))
             (setq r    (rp:road-end obj (car en) (cadr en) (caddr en) hw blen bwid th fac sz
                                     elev (+ st (/ (car en) fac)))
                   resE (list (+ (car resE) (car r)) (+ (cadr resE) (cadr r)))
                   nCls (+ nCls (caddr r)))))
         ;; 8. chevron boards on the outside of every bend of 10 deg or more
         (setq nChv 0)
         (if (rp:on "schev")
           (foreach c curves
             (if (>= (nth 3 c) (/ pi 18.0))
               (setq nChv (+ nChv (rp:chevrons obj c
                                               (if (> (nth 4 c) 0)
                                                 (- (+ offR (* 0.35 sz)))
                                                 (+ offL (* 0.35 sz)))
                                               sz fac elev))))))
         ;; 9. signs : post, plate, leader, symbol, ID tag (traffic keeps right)
         (setq sched (rp:signs obj len curves fac sz elev offR offL
                               (if (rp:on "ch") (* 10.0 th) 0.0) ends endf closed st))
         ;; 10. lane direction arrows
         (setq nArr (if (rp:on "sarr") (rp:lane-arrows obj strs hw fac (rp:on "twoway") elev) 0))
         ;; 11. draw order: surface bottom, fills above, all lines and text on top
         (if *rp:hatches* (rp:toback *rp:hatches*))
         (if surf (rp:toback (list surf)))
         ;; 12. store road data on the centre line, then report
         (rp:xput cl
           (list (cons "NAME"  (rp:val "rname"))   (cons "VER"   *rp:ver*)
                 (cons "DATE"  (rp:today))         (cons "FAC"   (rtos fac 2 0))
                 (cons "W"     (rtos (/ w fac) 2 4)) (cons "RIN" (rtos (/ rad0 fac) 2 4))
                 (cons "RREF"  (if (= (rp:val "rref") "1") "0" "1"))  (cons "CHST"  (rp:val "chst"))
                 (cons "CHINT" (rp:val "chint"))   (cons "BLEN"  (rp:val "blen"))
                 (cons "BWID"  (rp:val "bwid"))    (cons "BGAP"  (rp:val "bgap"))
                 (cons "BL"    (rp:pair resL))     (cons "BR"    (rp:pair resR))
                 (cons "BC"    (rp:pair resC))     (cons "BE"    (rp:pair resE))
                 (cons "SPEED" (rtos (rp:num "speed") 2 0))
                 (cons "NCHV"  (itoa nChv))        (cons "NARR"  (itoa nArr))
                 (cons "NCLS"  (itoa nCls))        (cons "ENDS"  ends)
                 (cons "ENDF"  endf)               (cons "NCHM"  (itoa (if nch nch 0)))
                 (cons "TWOWAY" (rp:val "twoway"))))
         (vlax-ldata-put obj "ROADPRO_SIGNS" sched)
         (if (rp:on "mark") (rp:mark-run cl))
         (rp:report-make cl (rp:on "report"))
         ;; 13. typical cross section
         (if (rp:on "xsec") (rp:xsec-run cl "0")))))))

;;----------------------------------------------------------------------------
;;  CROSS SECTIONS
;;  Drawn true size (1 unit = 1 m, or 1 mm for mm drawings), looking in the
;;  direction of increasing chainage : the road's LEFT side is on the LEFT.
;;----------------------------------------------------------------------------
(setq *rp:xdcl*
 (list
  "roadxsec : dialog {"
  "  label = \"ROAD PRO  -  Cross Section\";"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Section\";"
  "      : popup_list { key = \"xmode\";  label = \"Draw:\";                      edit_width = 26; }"
  "      : edit_box   { key = \"xch\";    label = \"Chainage (m):\";              edit_width = 8; }"
  "      : edit_box   { key = \"xint\";   label = \"Interval (m):\";              edit_width = 8; }"
  "      : edit_box   { key = \"xcf\";    label = \"Crossfall (%):\";             edit_width = 8; }"
  "      : popup_list { key = \"xcamb\";  label = \"Crossfall type:\";            edit_width = 26; }"
  "      : edit_box   { key = \"xverge\"; label = \"Verge beyond barricade (m):\"; edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Pavement layers (thickness 0 = not used)\";"
  "      : row { : edit_box { key = \"xl1n\"; label = \"1\"; edit_width = 26; }"
  "              : edit_box { key = \"xl1t\"; label = \"t (m)\"; edit_width = 6; } }"
  "      : row { : edit_box { key = \"xl2n\"; label = \"2\"; edit_width = 26; }"
  "              : edit_box { key = \"xl2t\"; label = \"t (m)\"; edit_width = 6; } }"
  "      : row { : edit_box { key = \"xl3n\"; label = \"3\"; edit_width = 26; }"
  "              : edit_box { key = \"xl3t\"; label = \"t (m)\"; edit_width = 6; } }"
  "    }"
  "  }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Barricade profile (red / white, black outline)\";"
  "      : popup_list { key = \"xbtype\"; label = \"Type:\";       edit_width = 26; }"
  "      : edit_box   { key = \"xbh\";    label = \"Height (m):\"; edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Sign post\";"
  "      : toggle   { key = \"xsign\";   label = \"Show sign post with height\"; }"
  "      : edit_box { key = \"xsclr\";   label = \"Clearance to sign (m):\"; edit_width = 8; }"
  "      : edit_box { key = \"xsplate\"; label = \"Sign size (m):\";         edit_width = 8; }"
  "    }"
  "  }"
  "  spacer;"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:xdlg-modes ()
  (mode_tile "xch"  (if (= (get_tile "xmode") "1") 0 1))
  (mode_tile "xint" (if (= (get_tile "xmode") "2") 0 1))
  (foreach k '("xsclr" "xsplate") (mode_tile k (if (= (get_tile "xsign") "1") 0 1))))

(defun rp:xdlg-accept (/ bad v)
  (foreach k '(("xch" "Chainage" 1) ("xint" "Interval" 0) ("xcf" "Crossfall" 1)
               ("xverge" "Verge" 1) ("xl1t" "Layer 1 thickness" 1) ("xl2t" "Layer 2 thickness" 1)
               ("xl3t" "Layer 3 thickness" 1) ("xbh" "Barricade height" 0)
               ("xsclr" "Sign clearance" 0) ("xsplate" "Sign size" 0))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (if (= (caddr k) 1) (< v 0.0) (<= v 0.0)))
          (setq bad k)))))
  (if bad
    (progn
      (set_tile "error" (strcat (cadr bad)
                                (if (= (caddr bad) 1)
                                  " must be zero or a positive number."
                                  " must be a number greater than zero.")))
      (mode_tile (car bad) 2))
    (progn
      (foreach k *rp:xkeys* (rp:set k (get_tile k)))
      (done_dialog 1))))

(defun rp:xdialog (/ fn f id res)
  (setq fn (vl-filename-mktemp "roadxsec.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:xdcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadxsec" id))
        (progn
          (rp:fill "xmode"  '("Typical cross section" "At one chainage" "At every chainage interval"))
          (rp:fill "xcamb"  '("Camber (falls both sides)" "One-way, falls to right" "One-way, falls to left"))
          (rp:fill "xbtype" '("Water-filled plastic barrier" "New Jersey concrete barrier"))
          (foreach k *rp:xkeys* (set_tile k (rp:val k)))
          (rp:xdlg-modes)
          (foreach k '("xmode" "xsign") (action_tile k "(rp:xdlg-modes)"))
          (action_tile "accept" "(rp:xdlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; ---- local section coordinates -> drawing ----
(defun rp:xp (x y) (list (+ (car *rp:xo*) x) (+ (cadr *rp:xo*) y)))

(defun rp:xpl (pts lay closed)
  (rp:mkpl (mapcar '(lambda (p) (list (rp:xp (car p) (cadr p)) 0.0)) pts) lay 0.0 closed))

(defun rp:xline (a b lay) (rp:line (rp:xp (car a) (cadr a)) (rp:xp (car b) (cadr b)) lay 0.0))

(defun rp:xtext (str p h) (rp:ltext str (rp:xp (car p) (cadr p)) h "ROAD-XSEC-TEXT"))

(defun rp:xmtext (str p h / mt)
  (setq mt (vla-AddMText *rp:spc* (rp:p3 (rp:xp (car p) (cadr p)) 0.0) 0.0 str))
  (vla-put-Height mt h)
  (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
  (vla-put-InsertionPoint mt (rp:p3 (rp:xp (car p) (cadr p)) 0.0))
  (vla-put-Layer mt "ROAD-XSEC-TEXT")
  mt)

;; finished surface level at x (0 at the centre line), level beyond the edges
(defun rp:ys (x)
  (setq x (max (- *rp:xhw*) (min *rp:xhw* x)))
  (cond ((= *rp:ct* "1") (* -1.0 *rp:cf* x))
        ((= *rp:ct* "2") (* *rp:cf* x))
        (T (* -1.0 *rp:cf* (abs x)))))

;; carriageway top line shifted by dy
(defun rp:xsurf (dy)
  (if (= *rp:ct* "0")
    (list (list (- *rp:xhw*) (+ (rp:ys (- *rp:xhw*)) dy)) (list 0.0 dy) (list *rp:xhw* (+ (rp:ys *rp:xhw*) dy)))
    (list (list (- *rp:xhw*) (+ (rp:ys (- *rp:xhw*)) dy)) (list *rp:xhw* (+ (rp:ys *rp:xhw*) dy)))))

(defun rp:xlay (kn kt fac) (if (> (rp:num kt) 0.0) (list (rp:val kn) (* fac (rp:num kt)))))

(defun rp:xlayers (fac)
  (vl-remove nil (list (rp:xlay "xl1n" "xl1t" fac) (rp:xlay "xl2n" "xl2t" fac) (rp:xlay "xl3n" "xl3t" fac))))

(defun rp:xthk (fac / tt) (setq tt 0.0) (foreach l (rp:xlayers fac) (setq tt (+ tt (cadr l)))) tt)

(defun rp:dim (p1 p2 loc rot th fac / d)
  (setq d (vla-AddDimRotated *rp:spc*
            (rp:p3 (rp:xp (car p1) (cadr p1)) 0.0)
            (rp:p3 (rp:xp (car p2) (cadr p2)) 0.0)
            (rp:p3 (rp:xp (car loc) (cadr loc)) 0.0)
            rot))
  (vla-put-Layer d "ROAD-XSEC-DIM")
  (foreach pr (list (list 'vla-put-TextHeight th)
                    (list 'vla-put-ArrowheadSize (* 0.6 th))
                    (list 'vla-put-ExtensionLineExtension (* 0.4 th))
                    (list 'vla-put-ExtensionLineOffset (* 0.3 th))
                    (list 'vla-put-TextGap (* 0.25 th))
                    (list 'vla-put-PrimaryUnitsPrecision
                          (if (= fac 1.0) acDimPrecisionTwo acDimPrecisionZero)))
    (vl-catch-all-apply (car pr) (list d (cadr pr))))
  d)

;; barricade profile, base centre (cx,by), base width bw, height bh
(defun rp:xbar (cx by bw bh lay / prof)
  (setq prof (if (= (rp:val "xbtype") "1")
               '((-0.5 0.0) (0.5 0.0) (0.5 0.09) (0.38 0.4) (0.12 1.0) (-0.12 1.0) (-0.38 0.4) (-0.5 0.09))
               '((-0.5 0.0) (0.5 0.0) (0.5 0.12) (0.32 0.2) (0.25 0.92) (0.15 1.0)
                 (-0.15 1.0) (-0.25 0.92) (-0.32 0.2) (-0.5 0.12))))
  (rp:solidfill (rp:xpl (mapcar '(lambda (p) (list (+ cx (* bw (car p))) (+ by (* bh (cadr p))))) prof)
                        "ROAD-BARRIER-OUTLINE" T)
                nil lay 0.0))

;; crossfall arrow + % text, dir +1 falls to the right, -1 to the left
(defun rp:xfall (x dir th fac / y1 y2 p1 p2 pm)
  (setq p1 (list (- x (* dir 0.7 fac)) (+ (rp:ys (- x (* dir 0.7 fac))) (* 0.35 fac)))
        p2 (list (+ x (* dir 0.7 fac)) (+ (rp:ys (+ x (* dir 0.7 fac))) (* 0.35 fac)))
        pm (rp:towards p2 p1 (* 0.25 fac)))
  (rp:mkwpl (list (list (rp:xp (car p1) (cadr p1)) 0.0 0.0)
                  (list (rp:xp (car pm) (cadr pm)) (* 0.12 fac) 0.0)
                  (list (rp:xp (car p2) (cadr p2)) 0.0 0.0))
            "ROAD-XSEC-TEXT" 0.0)
  (rp:xmtext (strcat (rtos (rp:num "xcf") 2 1) "%") (list x (+ (rp:ys x) (* 0.35 fac) (* 1.2 th))) th))

;; sign post with footing and sign face; dims = T adds clearance dimension + note
(defun rp:xpost (px py sclr spl spd fac th dims / po)
  (rp:solidfill (rp:xpl (list (list (- px (* 0.2 fac)) py) (list (+ px (* 0.2 fac)) py)
                              (list (+ px (* 0.2 fac)) (- py (* 0.6 fac)))
                              (list (- px (* 0.2 fac)) (- py (* 0.6 fac))))
                        "ROAD-XSEC" T)
                nil "ROAD-XSEC-CONC" 0.0)
  (setq po (rp:xpl (list (list px (- py (* 0.5 fac))) (list px (+ py sclr))) "ROAD-SIGN" nil))
  (vla-put-ConstantWidth po (* 0.076 fac))
  (rp:sign-speed (rp:xp px (+ py sclr (* 0.5 spl))) spl spd 0.0)
  (if dims
    (progn
      (rp:dim (list px py) (list px (+ py sclr)) (list (+ px (* 0.5 spl) (* 0.6 fac)) py) (* 0.5 pi) th fac)
      (rp:xtext (strcat "TRAFFIC SIGN " (rtos (/ spl fac) 2 2) " m ON 76 mm POST")
                (list (+ px (* 0.5 spl) (* 1.4 fac)) (+ py sclr (* 0.5 spl))) th)
      (rp:xtext "WITH CONCRETE FOOTING 0.40 x 0.60 m"
                (list (+ px (* 0.5 spl) (* 1.4 fac)) (- (+ py sclr (* 0.5 spl)) (* 1.6 th))) th))))

;; One complete cross section with its origin (CL, finished level) at org
(defun rp:xsection (org hw bgap bwid bl br bc fac two spd title note
                    / th bh vg sclr spl lys tt yL yR xl xr xo1 xo2 ybot d0 d1 i pg ytx xt
                      gx1 gx2 x ln top xs ys2 yd1 yd2 yd3 cxL cxR btxt ny)
  (setq *rp:xo*  org
        *rp:cf*  (/ (rp:num "xcf") 100.0)
        *rp:ct*  (rp:val "xcamb")
        *rp:xhw* hw
        th   (* 0.2 fac (rp:num "txth"))
        bh   (* fac (rp:num "xbh"))
        vg   (* fac (rp:num "xverge"))
        sclr (* fac (rp:num "xsclr"))
        spl  (* fac (rp:num "xsplate"))
        lys  (rp:xlayers fac)
        tt   (rp:xthk fac)
        yL   (rp:ys (- hw))
        yR   (rp:ys hw)
        xl   (+ hw (if bl (+ bgap bwid) 0.0))
        xr   (+ hw (if br (+ bgap bwid) 0.0))
        xo1  (- (+ xl vg))
        xo2  (+ xr vg)
        ybot (- (min yL yR) tt)
        xt   (+ xo2 (* 2.0 tt) (* 1.5 fac))
        ny   0)
  ;; ---- shoulders / verges ----
  (if (> tt 0.0)
    (progn
      (rp:solidfill (rp:xpl (list (list (- hw) yL) (list xo1 yL) (list (- xo1 (* 2.0 tt)) (- yL tt))
                                  (list (- hw) (- yL tt)))
                            "ROAD-XSEC" T)
                    nil "ROAD-XSEC-SHLD" 0.0)
      (rp:solidfill (rp:xpl (list (list hw yR) (list xo2 yR) (list (+ xo2 (* 2.0 tt)) (- yR tt))
                                  (list hw (- yR tt)))
                            "ROAD-XSEC" T)
                    nil "ROAD-XSEC-SHLD" 0.0)))
  ;; ---- pavement layers with labels ----
  (setq d0 0.0 i 0)
  (foreach l lys
    (setq i  (1+ i)
          d1 (+ d0 (cadr l))
          pg (append (rp:xsurf (- d0)) (reverse (rp:xsurf (- d1)))))
    (rp:solidfill (rp:xpl pg "ROAD-XSEC" T) nil (strcat "ROAD-XSEC-L" (itoa i)) 0.0)
    (setq ytx (- (+ yR (* 0.8 fac)) (* ny 2.0 th)) ny (1+ ny))
    (rp:xline (list (* 0.6 hw) (- (rp:ys (* 0.6 hw)) (* 0.5 (+ d0 d1)))) (list (- xt (* 0.3 fac)) ytx)
              "ROAD-XSEC-THIN")
    (rp:xtext (strcat (rtos (/ (* 1000.0 (cadr l)) fac) 2 0) " mm  " (car l)) (list xt ytx) th)
    (setq d0 d1))
  (if (> tt 0.0)
    (progn
      (setq ytx (- (+ yR (* 0.8 fac)) (* ny 2.0 th)) ny (1+ ny))
      (rp:xline (list (* 0.5 (+ xr xo2)) (- yR (* 0.5 tt))) (list (- xt (* 0.3 fac)) ytx) "ROAD-XSEC-THIN")
      (rp:xtext "COMPACTED SHOULDER / VERGE" (list xt ytx) th)))
  (setq ytx (- (+ yR (* 0.8 fac)) (* ny 2.0 th)) ny (1+ ny))
  (rp:xline (list (+ xo2 (* 2.0 tt) (* 0.6 fac)) (- yR tt)) (list (- xt (* 0.3 fac)) ytx) "ROAD-XSEC-THIN")
  (rp:xtext "SUBGRADE - COMPACTED" (list xt ytx) th)
  ;; ---- finished surface line ----
  (setq ln (rp:xpl (append (list (list xo1 yL)) (rp:xsurf 0.0) (list (list xo2 yR))) "ROAD-XSEC" nil))
  (vla-put-ConstantWidth ln (* 0.02 fac))
  ;; ---- subgrade / ground line with ground ticks ----
  (setq gx1 (- xo1 (* 2.0 tt) (* 1.5 fac))
        gx2 (+ xo2 (* 2.0 tt) (* 1.5 fac)))
  (rp:xpl (append (list (list gx1 (- yL tt)) (list (- xo1 (* 2.0 tt)) (- yL tt)))
                  (rp:xsurf (- tt))
                  (list (list (+ xo2 (* 2.0 tt)) (- yR tt)) (list gx2 (- yR tt))))
          "ROAD-XSEC" nil)
  (setq x gx1)
  (while (<= x gx2)
    (rp:xline (list x (- (rp:ys x) tt)) (list (- x (* 0.25 fac)) (- (rp:ys x) tt (* 0.25 fac)))
              "ROAD-XSEC-THIN")
    (setq x (+ x (* 0.5 fac))))
  ;; ---- barricades with height ----
  (setq cxL (- (+ hw bgap (* 0.5 bwid)))
        cxR (+ hw bgap (* 0.5 bwid))
        btxt (if (= (rp:val "xbtype") "1") "NEW JERSEY CONCRETE BARRIER" "WATER-FILLED BARRIER"))
  (if bl (rp:xbar cxL yL bwid bh "ROAD-BARRIER-RED"))
  (if br (rp:xbar cxR yR bwid bh "ROAD-BARRIER-WHITE"))
  (if bc (rp:xbar 0.0 0.0 bwid bh "ROAD-BARRIER-RED"))
  (cond
    (bl
     (rp:dim (list (- cxL (* 0.5 bwid)) yL) (list (- cxL (* 0.5 bwid)) (+ yL bh))
             (list (- cxL (* 0.5 bwid) (* 0.6 fac)) yL) (* 0.5 pi) th fac)
     (rp:xmtext (strcat btxt "\\P(RED / WHITE)  H = " (rtos (/ bh fac) 2 2) " m")
                (list cxL (+ yL bh (* 2.2 th))) th))
    (br
     (rp:dim (list (+ cxR (* 0.5 bwid)) yR) (list (+ cxR (* 0.5 bwid)) (+ yR bh))
             (list (+ cxR (* 0.5 bwid) (* 0.6 fac)) yR) (* 0.5 pi) th fac)
     (rp:xmtext (strcat btxt "\\P(RED / WHITE)  H = " (rtos (/ bh fac) 2 2) " m")
                (list cxR (+ yR bh (* 2.2 th))) th)))
  (if bc
    (rp:xmtext (strcat "MEDIAN " btxt) (list 0.0 (+ bh (* 3.5 th))) th))
  ;; ---- sign posts with clearance height ----
  (if (rp:on "xsign")
    (progn
      (rp:xpost (+ xr (* 0.5 fac)) yR sclr spl spd fac th T)
      (if two (rp:xpost (- (+ xl (* 0.5 fac))) yL sclr spl spd fac th nil))))
  ;; ---- centre line ----
  (setq top (+ (max bh (if (rp:on "xsign") (+ sclr spl) 0.0)) (* 0.8 fac))
        ln  (rp:xline (list 0.0 (- ybot (* 0.4 fac))) (list 0.0 top) "ROAD-CL"))
  (vla-put-LinetypeScale ln (/ (* 0.12 fac) (getvar "LTSCALE")))
  (rp:xmtext "CL" (list 0.0 (+ top (* 1.0 th))) (* 1.4 th))
  ;; ---- crossfall ----
  (if (> *rp:cf* 0.0)
    (if (= *rp:ct* "0")
      (progn (rp:xfall (* -0.5 hw) -1.0 th fac) (rp:xfall (* 0.5 hw) 1.0 th fac))
      (rp:xfall 0.0 (if (= *rp:ct* "1") 1.0 -1.0) th fac)))
  ;; ---- dimensions : chain, carriageway, total ----
  (setq xs (vl-remove nil (list xo1
                                (if bl (- xl)) (if bl (- (+ hw bgap)))
                                (- hw) 0.0 hw
                                (if br (+ hw bgap)) (if br xr)
                                xo2))
        yd1 (- ybot (* 0.9 fac))
        yd2 (- ybot (* 1.7 fac))
        yd3 (- ybot (* 2.5 fac)))
  (while (cdr xs)
    (if (> (- (cadr xs) (car xs)) 1e-6)
      (rp:dim (list (car xs) (rp:ys (car xs))) (list (cadr xs) (rp:ys (cadr xs)))
              (list (* 0.5 (+ (car xs) (cadr xs))) yd1) 0.0 th fac))
    (setq xs (cdr xs)))
  (rp:dim (list (- hw) yL) (list hw yR) (list 0.0 yd2) 0.0 th fac)
  (rp:dim (list xo1 yL) (list xo2 yR) (list 0.0 yd3) 0.0 th fac)
  (rp:xtext "CARRIAGEWAY" (list (+ hw (* 0.5 fac)) yd2) (* 0.8 th))
  (rp:xtext "TOTAL FORMATION" (list (+ xo2 (* 0.5 fac)) yd3) (* 0.8 th))
  ;; ---- title ----
  (rp:xmtext (strcat "{\\L" title "}") (list 0.0 (- yd3 (* 1.6 fac))) (* 1.6 th))
  (rp:xmtext (strcat (if (/= note "") (strcat note "\\P") "")
                     "Looking towards increasing chainage  |  1 unit = 1 "
                     (if (= fac 1.0) "m" "mm") "  |  True scale")
             (list 0.0 (- yd3 (* 1.6 fac) (* 2.8 th))) (* 0.9 th))
  (princ))

(defun rp:xnote (d curves strs fac / i r)
  (setq i 0)
  (foreach c curves
    (setq i (1+ i))
    (if (and (not r) (>= d (- (car c) 1e-6)) (<= d (+ (cadr c) 1e-6)))
      (setq r (strcat "On curve C" (itoa i) " - " (if (> (nth 4 c) 0) "left" "right")
                      " bend, R (CL) = " (rtos (/ (nth 2 c) fac) 2 3) " m"))))
  (setq i 0)
  (foreach s strs
    (setq i (1+ i))
    (if (and (not r) (>= d (- (car s) 1e-6)) (<= d (+ (cadr s) 1e-6)))
      (setq r (strcat "On straight S" (itoa i)))))
  (if r r ""))

(defun rp:take (lst n / r) (repeat (min n (length lst)) (setq r (cons (car lst) r) lst (cdr lst))) (reverse r))

;; mode "0" typical / "1" one chainage / "2" every interval
(defun rp:xsec-run (e mode / data fac obj len st hw bl br bc bgap bwid two spd nm curves strs
                       pt ch d dl k iv n vg tt top dx dy lx th)
  (setq data (rp:xget e)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        st       (atof (rp:xv "CHST" data))
        hw       (* 0.5 fac (atof (rp:xv "W" data)))
        bl       (/= (rp:xv "BL" data) "0,0")
        br       (/= (rp:xv "BR" data) "0,0")
        bc       (/= (rp:xv "BC" data) "0,0")
        bgap     (* fac (atof (rp:xv "BGAP" data)))
        bwid     (* fac (atof (rp:xv "BWID" data)))
        two      (/= (rp:xv "TWOWAY" data) "0")
        spd      (if (= (rp:xv "SPEED" data) "") "30" (rp:xv "SPEED" data))
        nm       (rp:xv "NAME" data)
        curves   (rp:curves obj)
        strs     (rp:straights obj)
        *rp:hatches* nil)
  (cond
    ((= mode "1")
     (setq ch (rp:num "xch")
           d  (* fac (- ch st)))
     (if (or (< d -1e-6) (> d (+ len 1e-6)))
       (alert (strcat "Chainage " (rp:chfmt ch) " is outside this road\n("
                      (rp:chfmt st) " to " (rp:chfmt (+ st (/ len fac))) ")."))
       (if (setq pt (getpoint "\nPick point for the section centre line (finished road level): "))
         (rp:xsection pt hw bgap bwid bl br bc fac two spd
                      (strcat "CROSS SECTION AT CH " (rp:chfmt ch) "  -  " nm)
                      (rp:xnote d curves strs fac)))))
    ((= mode "2")
     (setq iv (* fac (rp:num "xint"))
           dl (list 0.0)
           k  (fix (/ (* st fac) iv))
           d  (- (* (1+ k) iv) (* st fac)))
     (if (< d (* 0.001 iv)) (setq d (+ d iv)))
     (while (< d (- len (* 0.001 iv))) (setq dl (cons d dl) d (+ d iv)))
     (setq dl (reverse (cons len dl)))
     (if (> (length dl) 60)
       (progn (princ "\nMore than 60 sections - only the first 60 are drawn.") (setq dl (rp:take dl 60))))
     (setq vg  (* fac (rp:num "xverge"))
           tt  (rp:xthk fac)
           th  (* 0.2 fac (rp:num "txth"))
           top (+ (max (* fac (rp:num "xbh"))
                       (if (rp:on "xsign") (* fac (+ (rp:num "xsclr") (rp:num "xsplate"))) 0.0))
                  (* 2.5 fac))
           lx  (+ hw bgap bwid vg (* 2.0 tt) (* 3.0 fac))
           dx  (+ (* 2.0 lx) (* 32.0 th) (* 4.0 fac))
           dy  (+ top tt (* 9.0 fac)))
     (if (setq pt (getpoint (strcat "\nPick top-left corner for " (itoa (length dl)) " cross sections: ")))
       (progn
         (setq n 0)
         (foreach dd dl
           (rp:xsection (list (+ (car pt) (* (rem n 3) dx) lx) (- (cadr pt) top (* (/ n 3) dy)))
                        hw bgap bwid bl br bc fac two spd
                        (strcat "SECTION AT CH " (rp:chfmt (+ st (/ dd fac))))
                        (rp:xnote dd curves strs fac))
           (setq n (1+ n)))
         (princ (strcat "\n  " (itoa n) " cross sections drawn.")))))
    (T
     (if (setq pt (getpoint "\nPick point for the TYPICAL CROSS SECTION centre line <Enter = skip>: "))
       (rp:xsection pt hw bgap bwid bl br bc fac two spd
                    (strcat "TYPICAL CROSS SECTION  -  " nm) ""))))
  (if *rp:hatches* (rp:toback *rp:hatches*))
  (princ))

;;----------------------------------------------------------------------------
;;  LANE WIDENING
;;  Extra lane from a start chainage to an end chainage on the left, right or
;;  both sides, with taper in and taper out.
;;    Taper type  : Straight (linear)  or  Curve (reverse curve, tangent ends)
;;    Match point : Fillet with radius R  or  Direct link (sharp joint)
;;  The geometry is built in station-offset space and mapped onto the centre
;;  line, so it follows straights and curves of the road.
;;----------------------------------------------------------------------------
(setq *rp:wdcl*
 (list
  "roadwiden : dialog {"
  "  label = \"ROAD PRO  -  Lane Widening\";"
  "  : text { key = \"info\"; width = 60; }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Extra lane  (Left side when different)\";"
  "      : popup_list { key = \"wside\"; label = \"Side:\";                 edit_width = 16; }"
  "      : edit_box   { key = \"wwid\";  label = \"Extra width (m):\";      edit_width = 8; }"
  "      : edit_box   { key = \"wst\";   label = \"Start chainage (m):\";   edit_width = 8; }"
  "      : edit_box   { key = \"wen\";   label = \"End chainage (m):\";     edit_width = 8; }"
  "      : edit_box   { key = \"wtin\";  label = \"Taper in length (m):\";  edit_width = 8; }"
  "      : edit_box   { key = \"wtout\"; label = \"Taper out length (m):\"; edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Right side  (Both sides only)\";"
  "      : toggle   { key = \"wdiff\";  label = \"Different chainage on right side\"; }"
  "      : edit_box { key = \"wwid2\";  label = \"Extra width (m):\";      edit_width = 8; }"
  "      : edit_box { key = \"wst2\";   label = \"Start chainage (m):\";   edit_width = 8; }"
  "      : edit_box { key = \"wen2\";   label = \"End chainage (m):\";     edit_width = 8; }"
  "      : edit_box { key = \"wtin2\";  label = \"Taper in length (m):\";  edit_width = 8; }"
  "      : edit_box { key = \"wtout2\"; label = \"Taper out length (m):\"; edit_width = 8; }"
  "      : edit_box { key = \"wrad2\";  label = \"Fillet radius (m):\";    edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Taper and match points\";"
  "      : popup_list { key = \"wtype\";  label = \"Taper type:\";  edit_width = 26; }"
  "      : popup_list { key = \"wmatch\"; label = \"Match point:\"; edit_width = 26; }"
  "      : edit_box   { key = \"wrad\";   label = \"Fillet radius (m):\"; edit_width = 8; }"
  "      : toggle { key = \"wbar\"; label = \"Move barricades to the new edge\"; }"
  "      : toggle { key = \"warr\"; label = \"Lane arrow in the new lane\"; }"
  "      : toggle { key = \"wlab\"; label = \"Labels, width dimension, match points\"; }"
  "    }"
  "  }"
  "  spacer;"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:wdlg-modes (/ st both)
  (setq st   (= (get_tile "wtype") "0")
        both (= (get_tile "wside") "2"))
  (mode_tile "wmatch" (if st 0 1))
  (mode_tile "wrad" (if (and st (= (get_tile "wmatch") "0")) 0 1))
  (mode_tile "wdiff" (if both 0 1))
  (foreach k '("wwid2" "wst2" "wen2" "wtin2" "wtout2")
    (mode_tile k (if (and both (= (get_tile "wdiff") "1")) 0 1)))
  (mode_tile "wrad2" (if (and both (= (get_tile "wdiff") "1") st (= (get_tile "wmatch") "0")) 0 1)))

(defun rp:wdlg-accept (/ bad v r2)
  (setq r2 (and (= (get_tile "wside") "2") (= (get_tile "wdiff") "1")))
  (foreach k (append
               '(("wwid" "Extra width" 0) ("wst" "Start chainage" 1) ("wen" "End chainage" 1)
                 ("wtin" "Taper in length" 1) ("wtout" "Taper out length" 1) ("wrad" "Fillet radius" 0))
               (if r2 '(("wwid2" "Right extra width" 0) ("wst2" "Right start chainage" 1)
                        ("wen2" "Right end chainage" 1) ("wtin2" "Right taper in length" 1)
                        ("wtout2" "Right taper out length" 1) ("wrad2" "Right fillet radius" 0))))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (if (= (caddr k) 1) (< v 0.0) (<= v 0.0)))
          (setq bad k)))))
  (cond
    (bad
     (set_tile "error" (strcat (cadr bad)
                               (if (= (caddr bad) 1)
                                 " must be zero or a positive number."
                                 " must be a number greater than zero.")))
     (mode_tile (car bad) 2))
    ((<= (rp:dist (get_tile "wen")) (rp:dist (get_tile "wst")))
     (set_tile "error" "End chainage must be greater than the start chainage.")
     (mode_tile "wen" 2))
    ((and r2 (<= (rp:dist (get_tile "wen2")) (rp:dist (get_tile "wst2"))))
     (set_tile "error" "Right side: end chainage must be greater than the start chainage.")
     (mode_tile "wen2" 2))
    (T
     (foreach k *rp:wkeys* (rp:set k (get_tile k)))
     (done_dialog 1))))

(defun rp:wdialog (info / fn f id res)
  (setq fn (vl-filename-mktemp "roadwiden.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:wdcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadwiden" id))
        (progn
          (rp:fill "wside"  '("Left" "Right" "Both sides"))
          (rp:fill "wtype"  '("Straight (linear) taper" "Curve (reverse-curve) taper"))
          (rp:fill "wmatch" '("Fillet at match points" "Direct link (no fillet)"))
          (foreach k *rp:wkeys* (set_tile k (rp:val k)))
          (set_tile "info" info)
          (rp:wdlg-modes)
          (foreach k '("wtype" "wmatch" "wside" "wdiff") (action_tile k "(rp:wdlg-modes)"))
          (action_tile "accept" "(rp:wdlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; ---- profile helpers (station s, offset o) ----
(defun rp:acos (x) (setq x (max -1.0 (min 1.0 x))) (atan (sqrt (- 1.0 (* x x))) x))

(defun rp:unit2 (a b / d)
  (setq d (distance a b))
  (if (< d 1e-12) (list 1.0 0.0) (list (/ (- (car b) (car a)) d) (/ (- (cadr b) (cadr a)) d))))

;; Fillet the corner k between p0-k and k-p1 with radius r : list of arc points
(defun rp:fillet-pts (p0 k p1 r n / u1 u2 cr dl tl t1 sg c a0 i lst)
  (setq u1 (rp:unit2 p0 k)
        u2 (rp:unit2 k p1)
        cr (- (* (car u1) (cadr u2)) (* (cadr u1) (car u2)))
        dl (rp:acos (+ (* (car u1) (car u2)) (* (cadr u1) (cadr u2)))))
  (if (or (< (abs cr) 1e-9) (<= r 0.0))
    (list k)
    (progn
      (setq tl (* r (/ (sin (* 0.5 dl)) (cos (* 0.5 dl))))
            t1 (list (- (car k) (* tl (car u1))) (- (cadr k) (* tl (cadr u1))))
            sg (if (> cr 0.0) 1.0 -1.0)
            c  (list (- (car t1) (* sg r (cadr u1))) (+ (cadr t1) (* sg r (car u1))))
            a0 (angle c t1)
            i  0)
      (repeat (1+ n)
        (setq lst (cons (polar c (+ a0 (* sg dl (/ (float i) n))) r) lst) i (1+ i)))
      (reverse lst))))

;; Reverse-curve taper offset at x along a taper of length tl and width w
(defun rp:rc-o (x tl w / r)
  (setq r (/ (+ (* tl tl) (* w w)) (* 4.0 w)))
  (if (<= x (* 0.5 tl))
    (- r (sqrt (max 0.0 (- (* r r) (* x x)))))
    (- w (- r (sqrt (max 0.0 (- (* r r) (* (- tl x) (- tl x)))))))))

(defun rp:densify (pts step / out a b n i)
  (setq out (list (car pts)) a (car pts))
  (foreach b (cdr pts)
    (setq n (max 1 (fix (+ 0.999999 (/ (distance a b) step)))) i 1)
    (repeat n
      (setq out (cons (list (+ (car a) (* (- (car b) (car a)) (/ (float i) n)))
                            (+ (cadr a) (* (- (cadr b) (cadr a)) (/ (float i) n))))
                      out)
            i   (1+ i)))
    (setq a b))
  (reverse out))

;; Widening profile : dense list of (s o) from the first to the last match point
(defun rp:wprofile (s1 st en s2 w curve rf fac / k pts big n out s)
  (if curve
    (progn
      (setq out (list (list s1 0.0)) s (+ s1 (* 0.25 fac)))
      (while (< s st)
        (setq out (cons (list s (rp:rc-o (- s s1) (- st s1) w)) out) s (+ s (* 0.25 fac))))
      (setq out (cons (list st w) out))
      (setq out (cons (list en w) out) s (+ en (* 0.25 fac)))
      (while (< s s2)
        (setq out (cons (list s (rp:rc-o (- s2 s) (- s2 en) w)) out) s (+ s (* 0.25 fac))))
      (setq out (reverse (cons (list s2 0.0) out)))
      (rp:densify out (* 0.5 fac)))
    (progn
      (setq big (max (* 2.0 rf) fac)
            k   (list (list (- s1 big) 0.0) (list s1 0.0) (list st w) (list en w)
                      (list s2 0.0) (list (+ s2 big) 0.0))
            pts (list (car k)))
      (setq n 1)
      (repeat 4
        (setq pts (append pts
                          (if (> rf 0.0)
                            (rp:fillet-pts (nth (1- n) k) (nth n k) (nth (1+ n) k) rf
                                           (max 6 (fix (/ (* rf 0.4) (* 0.25 fac)))))
                            (list (nth n k))))
              n   (1+ n)))
      (setq pts (append pts (list (last k))))
      ;; drop the lead-in and lead-out on the original edge
      (while (and (cadr pts) (< (abs (cadr (cadr pts))) 1e-7)) (setq pts (cdr pts)))
      (setq pts (reverse pts))
      (while (and (cadr pts) (< (abs (cadr (cadr pts))) 1e-7)) (setq pts (cdr pts)))
      (rp:densify (reverse pts) (* 0.5 fac)))))

;; Offset of the profile at station s (0 outside the widening)
(defun rp:prof-o (pts s / a b r)
  (if (<= s (car (car pts)))
    (cadr (car pts))
    (progn
      (setq a (car pts) pts (cdr pts))
      (while (and pts (not r))
        (setq b (car pts))
        (if (<= s (car b))
          (setq r (if (< (- (car b) (car a)) 1e-9)
                    (cadr b)
                    (+ (cadr a) (* (- (cadr b) (cadr a)) (/ (- s (car a)) (- (car b) (car a))))))))
        (setq a b pts (cdr pts)))
      (if r r 0.0))))

;; Remove barricade units on one side between stations sA and sB
;; returns (red-removed white-removed first-centre last-centre)
(defun rp:wbar-remove (cl sg hw sA sB blen / ss i e o mn mx c p d f lat nr nw dmin dmax lay)
  (setq nr 0 nw 0
        ss (ssget "_X" '((8 . "ROAD-BARRIER-RED,ROAD-BARRIER-WHITE,ROAD-BARRIER-OUTLINE"))))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (setq e (ssname ss i) o (vlax-ename->vla-object e) i (1+ i))
        (vla-GetBoundingBox o 'mn 'mx)
        (setq mn (vlax-safearray->list mn) mx (vlax-safearray->list mx)
              c  (list (* 0.5 (+ (car mn) (car mx))) (* 0.5 (+ (cadr mn) (cadr mx))))
              p  (vlax-curve-getClosestPointTo cl (list (car c) (cadr c) (caddr mn)))
              d  (vlax-curve-getDistAtPoint cl p))
        (if d
          (progn
            (setq f   (rp:frame cl d)
                  lat (+ (* (- (car c) (car (car f))) (car (cadr f)))
                         (* (- (cadr c) (cadr (car f))) (cadr (cadr f)))))
            (if (and (> (* sg lat) hw)
                     (>= d (- sA (* 0.5 blen))) (<= d (+ sB (* 0.5 blen))))
              (progn
                (setq lay (vla-get-Layer o))
                (cond ((= lay "ROAD-BARRIER-RED") (setq nr (1+ nr)))
                      ((= lay "ROAD-BARRIER-WHITE") (setq nw (1+ nw))))
                (if (/= lay "ROAD-BARRIER-OUTLINE")
                  (setq dmin (if dmin (min dmin d) d) dmax (if dmax (max dmax d) d)))
                (vla-Delete o))))))))
  (list nr nw dmin dmax))

;; Barricade units along the widened edge between stations d0 and d1
(defun rp:barrier-prof (cl pts sg hw gap bwid d0 d1 seg step elev k0
                        / d de n i dd o pa pb cnt nred nwht)
  (setq d d0 cnt k0 nred 0 nwht 0)
  (while (< d (- d1 1e-6))
    (setq de (+ d seg))
    (if (> de (- d1 (* 0.25 seg))) (setq de d1))
    (setq n  (max 1 (fix (+ 0.999999 (/ (- de d) step))))
          pa nil pb nil i 0)
    (repeat (1+ n)
      (setq dd (+ d (* (- de d) (/ (float i) n)))
            o  (rp:prof-o pts dd)
            pa (cons (rp:offpt cl dd (* sg (+ hw o gap))) pa)
            pb (cons (rp:offpt cl dd (* sg (+ hw o gap bwid))) pb)
            i  (1+ i)))
    (rp:solidfill (rp:poly (append (reverse pa) pb) "ROAD-BARRIER-OUTLINE" elev)
                  nil
                  (if (= 0 (rem cnt 2)) "ROAD-BARRIER-RED" "ROAD-BARRIER-WHITE")
                  elev)
    (if (= 0 (rem cnt 2)) (setq nred (1+ nred)) (setq nwht (1+ nwht)))
    (setq cnt (1+ cnt) d de))
  (list nred nwht))

;; Radius mark at station s on an edge at offset eoff : leader arrow + "R=.." text
;; placed on the pavement side of the edge, parallel to the road
(defun rp:rmark (cl s eoff sg rr fac th elev / pe pm pt f ang rot tx)
  (setq pe  (rp:offpt cl s (* sg eoff))
        pm  (rp:offpt cl s (* sg (- eoff (* 1.2 fac))))
        pt  (rp:offpt cl s (* sg (- eoff (* 1.2 fac) (* 0.9 th))))
        f   (rp:frame cl s)
        ang (angle '(0.0 0.0) (caddr f))
        rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang))
  (rp:mkwpl (list (list pm 0.0 0.0)
                  (list (rp:towards pe pm (* 0.5 th)) (* 0.25 th) 0.0)
                  (list pe 0.0 0.0))
            "ROAD-WIDENING" elev)
  (setq tx (rp:text (strcat "R=" (rtos (/ rr fac) 2 2)) pt (* 0.7 th) "ROAD-WIDENING" elev))
  (vla-put-Rotation tx rot)
  tx)

;; One side of a widening. Returns (record bar-change surface-hatch)
(defun rp:widen-side (cl id sg hw w s1 st en s2 curve rf fac th elev st0 iv
                      barq bgap bwid blen two
                      / pts wp ep bnd h area edge rmv add k0 sA sB mid f ang rot ip mt
                        dimo p1 p2 kp rows s o pp lbl side tr txt)
  (setq pts (rp:wprofile s1 st en s2 w curve rf fac)
        sA  (car (car pts))
        sB  (car (last pts))
        wp  (mapcar '(lambda (p) (rp:offpt cl (car p) (* sg (+ hw (cadr p))))) pts)
        ep  (mapcar '(lambda (p) (rp:offpt cl (car p) (* sg hw))) pts)
        side (if (> sg 0) "Left" "Right"))
  ;; new road edge
  (setq edge (rp:mkpl (mapcar '(lambda (p) (list p 0.0)) wp) "ROAD-EDGE" elev nil))
  ;; widening surface
  (setq bnd (rp:poly (append wp (reverse (cdr (reverse (cdr (reverse ep)))))) "ROAD-SURFACE" elev)
        h   (rp:newhatch "SOLID" nil elev))
  (vla-put-Layer h "ROAD-SURFACE")
  (vla-AppendOuterLoop h (rp:objarr (list bnd)))
  (vla-Evaluate h)
  (vl-catch-all-apply 'vla-put-EntityTransparency (list h "50"))
  (setq area (vla-get-Area h))
  (vla-Delete bnd)
  ;; barricades moved to the new edge
  (setq add (list 0 0) rmv (list 0 0 nil nil))
  (if barq
    (progn
      (setq rmv (rp:wbar-remove cl sg hw sA sB blen))
      (if (caddr rmv)
        (setq k0  (fix (+ 0.5 (/ (- (caddr rmv) (* 0.5 blen)) blen)))
              add (rp:barrier-prof cl pts sg hw bgap bwid
                                   (max 0.0 (- (caddr rmv) (* 0.5 blen)))
                                   (min *rp:len* (+ (cadddr rmv) (* 0.5 blen)))
                                   blen (min blen (* 0.5 fac)) elev k0)))))
  ;; lane arrow in the new lane
  (if (and (rp:on "warr") (>= (- en st) (* 12.0 fac)))
    (progn
      (setq f   (rp:frame cl (* 0.5 (+ st en)))
            ang (angle '(0.0 0.0) (caddr f)))
      (rp:arrow (rp:loc f (* sg (+ hw (* 0.5 w))) 0.0)
                (if (and (> sg 0) two) (+ ang pi) ang) fac elev)))
  ;; key points (taper start, full width start / end, taper end)
  (setq kp (list (list (car (car pts)) "TS")))
  (foreach q pts (if (and (>= (cadr q) (- w 1e-6)) (not (assoc "FS" (mapcar 'reverse kp))))
                   (setq kp (cons (list (car q) "FS") kp))))
  (foreach q (reverse pts) (if (and (>= (cadr q) (- w 1e-6)) (not (assoc "FE" (mapcar 'reverse kp))))
                             (setq kp (cons (list (car q) "FE") kp))))
  (setq kp (cons (list (car (last pts)) "TE") kp))
  ;; setting-out rows : key points + every chainage interval
  (if (> iv 0.0)
    (progn
      (setq s (* iv (fix (+ 1.0 (/ (+ sA (* st0 fac)) iv)))))
      (setq s (- s (* st0 fac)))
      (while (< s sB)
        (if (> s sA) (setq kp (cons (list s "CH") kp)))
        (setq s (+ s iv)))))
  (setq kp (vl-sort kp '(lambda (a b) (< (car a) (car b)))))
  (foreach q kp
    (setq o  (rp:prof-o pts (car q))
          pp (rp:offpt cl (car q) (* sg (+ hw o)))
          rows (cons (list (strcat id "-" (if (> sg 0) "L" "R")) (cadr q)
                           (rp:chfmt (+ st0 (/ (car q) fac)))
                           (rtos (/ (* sg (+ hw o)) fac) 2 3)
                           (rtos (/ (car pp) fac) 2 3) (rtos (/ (cadr pp) fac) 2 3))
                     rows)))
  (setq rows (reverse rows))
  ;; labels, dimension, match point markers
  (if (rp:on "wlab")
    (progn
      (foreach q kp
        (if (/= (cadr q) "CH")
          (progn
            (setq o  (rp:prof-o pts (car q))
                  pp (rp:offpt cl (car q) (* sg (+ hw o))))
            (vla-put-Layer (vla-AddCircle *rp:spc* (rp:p3 pp elev) (* 0.3 fac)) "ROAD-WIDENING")
            (rp:sidetext cl (car q) (strcat (cadr q) " " (rp:chfmt (+ st0 (/ (car q) fac))))
                         (* sg (+ hw o (* 0.8 fac))) (* 0.8 th) "ROAD-WIDENING" elev))))
      ;; radius marks : every fillet, or both arcs of each reverse-curve taper
      (if curve
        (foreach q (list (list (+ s1 (* 0.25 (- st s1))) (- st s1)) (list (+ s1 (* 0.75 (- st s1))) (- st s1))
                         (list (+ en (* 0.25 (- s2 en))) (- s2 en)) (list (+ en (* 0.75 (- s2 en))) (- s2 en)))
          (if (> (cadr q) 0.0)
            (rp:rmark cl (car q) (+ hw (rp:prof-o pts (car q))) sg
                      (/ (+ (* (cadr q) (cadr q)) (* w w)) (* 4.0 w)) fac th elev)))
        (if (> rf 0.0)
          (foreach sc (list s1 st en s2)
            (rp:rmark cl sc (+ hw (rp:prof-o pts sc)) sg rf fac th elev))))
      (setq mid (* 0.5 (+ st en))
            p1  (rp:offpt cl mid (* sg hw))
            p2  (rp:offpt cl mid (* sg (+ hw w)))
            f   (rp:frame cl mid)
            dimo (vla-AddDimAligned *rp:spc* (rp:p3 p1 elev) (rp:p3 p2 elev)
                                    (rp:p3 (rp:pt+ (rp:towards p1 p2 (* 0.5 w)) (caddr f) (* 3.0 fac)) elev)))
      (vla-put-Layer dimo "ROAD-WIDENING")
      (foreach pr (list (list 'vla-put-TextHeight (* 0.8 th)) (list 'vla-put-ArrowheadSize (* 0.5 th))
                        (list 'vla-put-PrimaryUnitsPrecision (if (= fac 1.0) acDimPrecisionTwo acDimPrecisionZero)))
        (vl-catch-all-apply (car pr) (list dimo (cadr pr))))
      (setq ang (angle '(0.0 0.0) (caddr f))
            rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang)
            ip  (rp:offpt cl mid (* sg (+ hw w bgap bwid (* 1.0 fac) (* 3.0 th))))
            tr  (if curve
                  (strcat "CURVE TAPER (REVERSE CURVE)  R in "
                          (rtos (/ (/ (+ (* (- st s1) (- st s1)) (* w w)) (* 4.0 w)) fac) 2 1) " m  /  R out "
                          (rtos (/ (/ (+ (* (- s2 en) (- s2 en)) (* w w)) (* 4.0 w)) fac) 2 1) " m")
                  (strcat "STRAIGHT TAPER 1:" (rtos (/ (- st s1) w) 2 1) " in, 1:" (rtos (/ (- s2 en) w) 2 1) " out"
                          (if (> rf 0.0) (strcat "  -  FILLET R=" (rtos (/ rf fac) 2 1) " m") "  -  DIRECT LINK")))
            mt  (vla-AddMText *rp:spc* (rp:p3 ip elev) 0.0
                  (strcat "LANE WIDENING " id " (" side ")  +" (rtos (/ w fac) 2 2) " m"
                          "\\PCH " (rp:chfmt (+ st0 (/ st fac))) " - " (rp:chfmt (+ st0 (/ en fac)))
                          "\\PTAPER IN " (rtos (/ (- st s1) fac) 2 1) " m  /  OUT " (rtos (/ (- s2 en) fac) 2 1) " m"
                          "\\P" tr
                          "\\PAREA = " (rtos (/ area fac fac) 2 2) " m\\U+00B2")))
      (vla-put-Height mt (* 0.8 th))
      (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
      (vla-put-InsertionPoint mt (rp:p3 ip elev))
      (vla-put-Rotation mt rot)
      (vla-put-Layer mt "ROAD-WIDENING")))
  (list (list (strcat id "-" (if (> sg 0) "L" "R")) side (rtos (/ w fac) 2 2)
              (rp:chfmt (+ st0 (/ st fac))) (rp:chfmt (+ st0 (/ en fac)))
              (rtos (/ (- st s1) fac) 2 1) (rtos (/ (- s2 en) fac) 2 1)
              (if curve "Curve (reverse curve)" "Straight")
              (if curve "Tangent (curve)" (if (> rf 0.0) (strcat "Fillet R " (rtos (/ rf fac) 2 1) " m") "Direct link"))
              (rtos (/ area fac fac) 2 2)
              rows)
        (list (- (car add) (car rmv)) (- (cadr add) (cadr rmv)))
        h))

;; Widening values for one side : (w st en s1 s2)
;; the right side uses its own fields when Both sides + different chainage
(defun rp:wside-par (sg fac st0 / sx st en)
  (setq sx (if (and (< sg 0) (= (rp:val "wside") "2") (= (rp:val "wdiff") "1")) "2" "")
        st (* fac (- (rp:num (strcat "wst" sx)) st0))
        en (* fac (- (rp:num (strcat "wen" sx)) st0)))
  (list (* fac (rp:num (strcat "wwid" sx))) st en
        (- st (* fac (rp:num (strcat "wtin" sx))))
        (+ en (* fac (rp:num (strcat "wtout" sx))))
        (* fac (rp:num (strcat "wrad" sx)))))

;; Keep the fillet radius inside the tapers and the full-width length
(defun rp:wrf (rf w st en s1 s2 fac sg / rfmax dl)
  (if (> rf 0.0)
    (progn
      (setq rfmax 1e99)
      (foreach tl (list (- st s1) (- s2 en))
        (setq dl    (atan w tl)
              rfmax (min rfmax (/ (min (* 0.5 (sqrt (+ (* tl tl) (* w w)))) (* 0.5 (- en st)))
                                  (/ (sin (* 0.5 dl)) (cos (* 0.5 dl)))))))
      (if (> rf rfmax)
        (progn
          (princ (strcat "\nFillet radius reduced to " (rtos (/ rfmax fac) 2 1) " m on the "
                         (if (> sg 0) "left" "right") " side so it fits inside the tapers."))
          rfmax)
        rf))
    rf))

(defun rp:widen-run (e / data fac obj len st0 hw bgap bwid blen two curve rf0 rf pr bad
                       sides recs old id bl br res surf iv elev th)
  (setq data (rp:xget e)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        elev     (vla-get-Elevation obj)
        st0      (atof (rp:xv "CHST" data))
        iv       (* fac (atof (rp:xv "CHINT" data)))
        hw       (* 0.5 fac (atof (rp:xv "W" data)))
        bgap     (* fac (atof (rp:xv "BGAP" data)))
        bwid     (* fac (atof (rp:xv "BWID" data)))
        blen     (* fac (atof (rp:xv "BLEN" data)))
        two      (/= (rp:xv "TWOWAY" data) "0")
        th       (* fac (rp:num "txth"))
        curve    (= (rp:val "wtype") "1")
        rf0      (and (not curve) (= (rp:val "wmatch") "0"))
        sides    (cond ((= (rp:val "wside") "0") '(1.0))
                       ((= (rp:val "wside") "1") '(-1.0))
                       (T '(1.0 -1.0)))
        *rp:hatches* nil)
  (if (<= blen 0.0) (setq blen (* 2.0 fac)))
  ;; check every side before drawing anything
  (foreach sg sides
    (setq pr (rp:wside-par sg fac st0))
    (if (and (not bad) (or (< (nth 3 pr) -1e-6) (> (nth 4 pr) (+ len 1e-6))))
      (setq bad (list sg pr))))
  (cond
    (bad
     (alert (strcat "The " (if (> (car bad) 0) "LEFT" "RIGHT")
                    " side widening with its tapers runs outside the road.\n\n"
                    "Road : " (rp:chfmt st0) " to " (rp:chfmt (+ st0 (/ len fac))) "\n"
                    "Widening incl. tapers : " (rp:chfmt (+ st0 (/ (nth 3 (cadr bad)) fac))) " to "
                    (rp:chfmt (+ st0 (/ (nth 4 (cadr bad)) fac))) "\n\n"
                    "The start chainage is where the FULL width starts;\n"
                    "the taper in is added before it.")))
    (T
     (setq old (vlax-ldata-get obj "ROADPRO_WIDEN")
           id  (strcat "W" (itoa (1+ (length old))))
           bl  (rp:pairget (rp:xv "BL" data))
           br  (rp:pairget (rp:xv "BR" data)))
     (foreach sg sides
       (setq pr  (rp:wside-par sg fac st0)
             rf  (rp:wrf (if rf0 (nth 5 pr) 0.0) (nth 0 pr) (nth 1 pr) (nth 2 pr) (nth 3 pr) (nth 4 pr) fac sg)
             res (rp:widen-side obj id sg hw (nth 0 pr) (nth 3 pr) (nth 1 pr) (nth 2 pr) (nth 4 pr)
                                curve rf fac th elev st0 iv
                                (and (rp:on "wbar")
                                     (/= (rp:xv (if (> sg 0) "BL" "BR") data) "0,0"))
                                bgap bwid blen two))
       (setq recs (cons (car res) recs)
             surf (cons (caddr res) surf))
       (if (> sg 0)
         (setq bl (list (+ (car bl) (car (cadr res))) (+ (cadr bl) (cadr (cadr res)))))
         (setq br (list (+ (car br) (car (cadr res))) (+ (cadr br) (cadr (cadr res)))))))
     ;; draw order, stored data
     (if *rp:hatches* (rp:toback *rp:hatches*))
     (if surf (rp:toback surf))
     (vlax-ldata-put obj "ROADPRO_WIDEN" (append old (reverse recs)))
     (setq data (vl-remove-if '(lambda (x) (member (car x) '("BL" "BR"))) data))
     (rp:xput e (append data (list (cons "BL" (rp:pair bl)) (cons "BR" (rp:pair br)))))
     (foreach r (reverse recs)
       (princ (strcat "\n  " (car r) " (" (cadr r) ") +" (caddr r) " m  CH " (nth 3 r) " - " (nth 4 r)
                      "  |  " (nth 7 r) ", " (nth 8 r) "  |  area " (nth 9 r) " m2")))
     (princ "\n  Lane widening added. Run RDR for the updated report.")))
  (princ))

;;----------------------------------------------------------------------------
;;  ROAD TAPER
;;  Widen (+) or narrow (-) the road edge on the left, right or both sides
;;  between ANY start and end chainage. The new width continues to the road
;;  end; add more tapers anywhere to change it again (they add up).
;;    Taper type  : Straight (linear)  or  Curve (reverse curve)
;;    Match point : Fillet with radius R  or  Direct link
;;  Each run rebuilds the edge, surface, barricades and labels of that side.
;;----------------------------------------------------------------------------
(setq *rp:tdcl*
 (list
  "roadtaper : dialog {"
  "  label = \"ROAD PRO  -  Road Taper\";"
  "  : text { key = \"info\"; width = 64; }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Where and how much  (Left side when different)\";"
  "      : popup_list { key = \"tside\";  label = \"Side:\";                     edit_width = 16; }"
  "      : edit_box   { key = \"tst\";    label = \"Taper start chainage (m):\"; edit_width = 8; }"
  "      : edit_box   { key = \"ten\";    label = \"Taper end chainage (m):\";   edit_width = 8; }"
  "      : edit_box   { key = \"tshift\"; label = \"Edge shift per side (m):\";  edit_width = 8; }"
  "      : text { label = \"+ = wider road     - = narrower road\"; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Right side  (Both sides only)\";"
  "      : toggle   { key = \"tdiff\";   label = \"Different chainage on right side\"; }"
  "      : edit_box { key = \"tst2\";    label = \"Taper start chainage (m):\"; edit_width = 8; }"
  "      : edit_box { key = \"ten2\";    label = \"Taper end chainage (m):\";   edit_width = 8; }"
  "      : edit_box { key = \"tshift2\"; label = \"Edge shift (m):\";           edit_width = 8; }"
  "      : edit_box { key = \"trad2\";   label = \"Fillet radius (m):\";        edit_width = 8; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Taper and match points\";"
  "      : popup_list { key = \"ttype\";  label = \"Taper type:\";  edit_width = 26; }"
  "      : popup_list { key = \"tmatch\"; label = \"Match point:\"; edit_width = 26; }"
  "      : edit_box   { key = \"trad\";   label = \"Fillet radius (m):\"; edit_width = 8; }"
  "      : toggle { key = \"tbar\"; label = \"Barricades follow the new edge\"; }"
  "      : toggle { key = \"tlab\"; label = \"Labels and match points\"; }"
  "    }"
  "  }"
  "  : text { label = \"The new width continues to the road end. Run RDT again to add more tapers anywhere.\"; }"
  "  spacer;"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:tdlg-modes (/ st both)
  (setq st   (= (get_tile "ttype") "0")
        both (= (get_tile "tside") "2"))
  (mode_tile "tmatch" (if st 0 1))
  (mode_tile "trad" (if (and st (= (get_tile "tmatch") "0")) 0 1))
  (mode_tile "tdiff" (if both 0 1))
  (foreach k '("tst2" "ten2" "tshift2")
    (mode_tile k (if (and both (= (get_tile "tdiff") "1")) 0 1)))
  (mode_tile "trad2" (if (and both (= (get_tile "tdiff") "1") st (= (get_tile "tmatch") "0")) 0 1)))

(defun rp:tdlg-accept (/ bad v v2 r2)
  (setq r2 (and (= (get_tile "tside") "2") (= (get_tile "tdiff") "1")))
  (foreach k (append '(("tst" "Taper start chainage" 1) ("ten" "Taper end chainage" 1) ("trad" "Fillet radius" 0))
                     (if r2 '(("tst2" "Right taper start chainage" 1) ("ten2" "Right taper end chainage" 1)
                              ("trad2" "Right fillet radius" 0))))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (if (= (caddr k) 1) (< v 0.0) (<= v 0.0)))
          (setq bad k)))))
  (setq v  (rp:dist (get_tile "tshift"))
        v2 (rp:dist (get_tile "tshift2")))
  (cond
    (bad
     (set_tile "error" (strcat (cadr bad)
                               (if (= (caddr bad) 1)
                                 " must be zero or a positive number."
                                 " must be a number greater than zero.")))
     (mode_tile (car bad) 2))
    ((or (null v) (< (abs v) 0.001))
     (set_tile "error" "Edge shift must be a number, + to widen or - to narrow (not zero).")
     (mode_tile "tshift" 2))
    ((<= (rp:dist (get_tile "ten")) (rp:dist (get_tile "tst")))
     (set_tile "error" "Taper end chainage must be greater than the start chainage.")
     (mode_tile "ten" 2))
    ((and r2 (or (null v2) (< (abs v2) 0.001)))
     (set_tile "error" "Right side edge shift must be + to widen or - to narrow (not zero).")
     (mode_tile "tshift2" 2))
    ((and r2 (<= (rp:dist (get_tile "ten2")) (rp:dist (get_tile "tst2"))))
     (set_tile "error" "Right side: taper end chainage must be greater than the start chainage.")
     (mode_tile "ten2" 2))
    (T
     (foreach k *rp:tkeys* (rp:set k (get_tile k)))
     (done_dialog 1))))

(defun rp:tdialog (info / fn f id res)
  (setq fn (vl-filename-mktemp "roadtaper.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:tdcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadtaper" id))
        (progn
          (rp:fill "tside"  '("Left" "Right" "Both sides"))
          (rp:fill "ttype"  '("Straight (linear) taper" "Curve (reverse-curve) taper"))
          (rp:fill "tmatch" '("Fillet at match points" "Direct link (no fillet)"))
          (foreach k *rp:tkeys* (set_tile k (rp:val k)))
          (set_tile "info" info)
          (rp:tdlg-modes)
          (foreach k '("ttype" "tmatch" "tside" "tdiff") (action_tile k "(rp:tdlg-modes)"))
          (action_tile "accept" "(rp:tdlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; One-way taper profile (s o) : from 0 at the start match point to d at the end
(defun rp:tprofile (a b d curve rf fac / sg ad out s big k pts n)
  (if curve
    (progn
      (setq sg  (if (< d 0.0) -1.0 1.0)
            ad  (abs d)
            out (list (list a 0.0))
            s   (+ a (* 0.25 fac)))
      (while (< s b)
        (setq out (cons (list s (* sg (rp:rc-o (- s a) (- b a) ad))) out)
              s   (+ s (* 0.25 fac))))
      (rp:densify (reverse (cons (list b d) out)) (* 0.5 fac)))
    (progn
      (setq big (max (* 2.0 rf) fac)
            k   (list (list (- a big) 0.0) (list a 0.0) (list b d) (list (+ b big) d))
            n   (max 6 (fix (/ (* rf 0.4) (* 0.25 fac)))))
      (setq pts (append (list (car k))
                        (if (> rf 0.0)
                          (append (rp:fillet-pts (nth 0 k) (nth 1 k) (nth 2 k) rf n)
                                  (rp:fillet-pts (nth 1 k) (nth 2 k) (nth 3 k) rf n))
                          (list (nth 1 k) (nth 2 k)))))
      (while (and (cadr pts) (< (abs (cadr (cadr pts))) 1e-7)) (setq pts (cdr pts)))
      (rp:densify pts (* 0.5 fac)))))

;; Profile value that HOLDS the end value after the last point
(defun rp:prof-hold (pts s)
  (cond ((<= s (car (car pts))) (cadr (car pts)))
        ((>= s (car (last pts))) (cadr (last pts)))
        (T (rp:prof-o pts s))))

(defun rp:taper-profs (recs sg fac / out)
  (foreach r recs
    (if (= (nth 2 r) sg)
      (setq out (cons (rp:tprofile (nth 3 r) (nth 4 r) (nth 5 r) (= (nth 6 r) 1) (nth 7 r) fac) out))))
  (reverse out))

;; Edge offset from the CL on one side at station s (all tapers of that side)
(defun rp:soff (profs hw s / t0)
  (setq t0 hw)
  (foreach p profs (setq t0 (+ t0 (rp:prof-hold p s))))
  t0)

(defun rp:tstations (profs s0 len fac / s lst out prev)
  (setq s s0)
  (while (< s len) (setq lst (cons s lst) s (+ s fac)))
  (setq lst (cons len lst))
  (foreach p profs
    (foreach q p (if (and (>= (car q) s0) (<= (car q) len)) (setq lst (cons (car q) lst)))))
  (foreach x (vl-sort lst '<)
    (if (or (null prev) (> (- x prev) 1e-6)) (setq out (cons x out) prev x)))
  (reverse out))

(defun rp:since (mark / e lst)
  (setq e (if mark (entnext mark) (entnext)))
  (while e (setq lst (cons e lst) e (entnext e)))
  (reverse lst))

(defun rp:order-ss (enames opt / ss)
  (setq ss (ssadd))
  (foreach en enames (ssadd en ss))
  (if (> (sslength ss) 0) (command "_.DRAWORDER" ss "" opt)))

;; Break object e between points p1 and p2. The points are snapped onto e,
;; OSNAP is off, and BREAK is never left waiting for the user.
(defun rp:break (e p1 p2 / om q1 q2)
  (if (and e (entget e) p1 p2)
    (progn
      (setq q1 (vlax-curve-getClosestPointTo e (list (car p1) (cadr p1) (if (caddr p1) (caddr p1) 0.0)))
            q2 (vlax-curve-getClosestPointTo e (list (car p2) (cadr p2) (if (caddr p2) (caddr p2) 0.0))))
      (if (and q1 q2 (> (distance (list (car q1) (cadr q1)) (list (car q2) (cadr q2))) 1e-6))
        (progn
          (setq om (getvar "OSMODE"))
          (setvar "OSMODE" 0)
          (command "_.BREAK" (list e (trans q1 0 1)) "_F" (trans q1 0 1) (trans q2 0 1))
          (while (> (getvar "CMDACTIVE") 0) (command))
          (setvar "OSMODE" om)
          T)))))

;; Shorten the original road edge on one side, from station s to its end
(defun rp:break-edge (cl sg hw s fac elev / p ss i e cp best bl l om)
  (setq p  (rp:offpt cl s (* sg hw))
        ss (ssget "_X" '((0 . "LWPOLYLINE") (8 . "ROAD-EDGE")))
        i  0
        bl 0.0)
  (if ss
    (repeat (sslength ss)
      (setq e (ssname ss i) i (1+ i)
            cp (vlax-curve-getClosestPointTo e (list (car p) (cadr p) elev)))
      (if (and cp (< (distance (list (car cp) (cadr cp)) p) (* 0.002 fac)))
        (progn
          (setq l (vlax-curve-getDistAtParam e (vlax-curve-getEndParam e)))
          (if (> l bl) (setq best e bl l))))))
  (if best
    (progn
      (setq om (getvar "OSMODE"))
      (setvar "OSMODE" 0)
      (rp:break best (list (car p) (cadr p) elev) (vlax-curve-getEndPoint best))
      (setvar "OSMODE" om)
      T)
    (progn (princ "\nNote: original road edge not found on this side - it was left as it is.") nil)))

;; Wipeout over a narrowed area, returns its area
(defun rp:wipe (pts elev / pl ar w)
  (setq pl (rp:poly pts "ROAD-SURFACE" elev)
        ar (vla-get-Area pl))
  (command "_.WIPEOUT" "_P" (vlax-vla-object->ename pl) "_Y")
  (setq w (entlast))
  (if (and w (= (cdr (assoc 0 (entget w))) "WIPEOUT"))
    (vla-put-Layer (vlax-ename->vla-object w) "ROAD-SURFACE"))
  ar)

;; Rebuild everything a taper changes on one side. Returns (d-red d-white add-area cut-area)
(defun rp:taper-rebuild (cl sg hw fac len elev blen bgap bwid barq labq st0 th all
                         / sd recs profs s0 e en nr nw brk mark stl offs grp grps prev cur o k
                           newp oldp bnd h addA cutA rmv bstart rel add p q pp mid f ang rot ip mt
                           new ty ly wl bh sh oth)
  (setq sd    (if (> sg 0) "L" "R")
        recs  (vl-remove-if-not '(lambda (r) (= (nth 2 r) sg)) all)
        profs (rp:taper-profs all sg fac)
        s0    (apply 'min (mapcar '(lambda (x) (car (car x))) profs))
        nr 0 nw 0 addA 0.0 cutA 0.0 add (list 0 0))
  ;; 1. remove what earlier tapers drew on this side
  (foreach hd (vlax-ldata-get cl (strcat "ROADPRO_TMAN_" sd))
    (if (and (setq en (handent hd)) (entget en))
      (progn
        (if (= (cdr (assoc 0 (entget en))) "HATCH")
          (cond ((= (cdr (assoc 8 (entget en))) "ROAD-BARRIER-RED") (setq nr (1+ nr)))
                ((= (cdr (assoc 8 (entget en))) "ROAD-BARRIER-WHITE") (setq nw (1+ nw)))))
        (entdel en))))
  ;; 2. shorten the original edge (only further back than before)
  (setq brk (vlax-ldata-get cl (strcat "ROADPRO_TBRK_" sd)))
  (if (or (null brk) (< s0 (- brk 1e-6)))
    (progn
      (rp:break-edge cl sg hw s0 fac elev)
      (vlax-ldata-put cl (strcat "ROADPRO_TBRK_" sd) s0)))
  (setq mark (entlast))
  ;; 3. new edge from the first taper to the road end
  (setq stl  (rp:tstations profs s0 len fac)
        offs (mapcar '(lambda (x) (list x (rp:soff profs hw x))) stl))
  (rp:mkpl (mapcar '(lambda (x) (list (rp:offpt cl (car x) (* sg (cadr x))) 0.0)) offs) "ROAD-EDGE" elev nil)
  ;; 4. surface : added (hatch) and removed (wipeout) areas
  (setq cur 0)
  (foreach x offs
    (setq o (- (cadr x) hw)
          k (cond ((> o (* 0.001 fac)) 1) ((< o (* -0.001 fac)) -1) (T 0)))
    (cond
      ((and (/= k 0) (= k cur)) (setq grp (cons x grp)))
      (T
       (if grp (setq grps (cons (list cur (reverse (cons x grp))) grps)))
       (setq grp (if (/= k 0) (if prev (list x prev) (list x)) nil)
             cur k)))
    (setq prev x))
  (if grp (setq grps (cons (list cur (reverse grp)) grps)))
  (foreach g grps
    (if (>= (length (cadr g)) 2)
      (progn
        (setq newp (mapcar '(lambda (x) (rp:offpt cl (car x) (* sg (cadr x)))) (cadr g))
              oldp (reverse (mapcar '(lambda (x) (rp:offpt cl (car x) (* sg hw))) (cadr g))))
        (if (> (car g) 0)
          (progn
            (setq bnd (rp:poly (append newp oldp) "ROAD-SURFACE" elev)
                  h   (rp:newhatch "SOLID" nil elev))
            (vla-put-Layer h "ROAD-SURFACE")
            (vla-AppendOuterLoop h (rp:objarr (list bnd)))
            (vla-Evaluate h)
            (vl-catch-all-apply 'vla-put-EntityTransparency (list h "50"))
            (setq addA (+ addA (vla-get-Area h)))
            (vla-Delete bnd))
          (setq cutA (+ cutA (rp:wipe (append newp oldp) elev)))))))
  ;; 5. barricades follow the new edge
  (if barq
    (progn
      (setq rmv    (rp:wbar-remove cl sg hw s0 len blen)
            bstart (vlax-ldata-get cl (strcat "ROADPRO_TBAR_" sd))
            nr     (+ nr (car rmv))
            nw     (+ nw (cadr rmv)))
      (if (caddr rmv)
        (setq bstart (if bstart
                       (min bstart (- (caddr rmv) (* 0.5 blen)))
                       (- (caddr rmv) (* 0.5 blen)))))
      (if bstart
        (progn
          (setq bstart (max 0.0 bstart)
                rel    (mapcar '(lambda (x) (list (car x) (- (cadr x) hw))) offs))
          (vlax-ldata-put cl (strcat "ROADPRO_TBAR_" sd) bstart)
          (setq add (rp:barrier-prof cl rel sg hw bgap bwid bstart len blen
                                     (min blen (* 0.5 fac)) elev
                                     (fix (+ 0.5 (/ bstart blen)))))))))
  ;; 6. labels and match points
  (if labq
    (foreach r recs
      (setq p (rp:tprofile (nth 3 r) (nth 4 r) (nth 5 r) (= (nth 6 r) 1) (nth 7 r) fac))
      (foreach q (list (list (car (car p)) "TS") (list (car (last p)) "TE"))
        (setq o  (rp:soff profs hw (car q))
              pp (rp:offpt cl (car q) (* sg o)))
        (vla-put-Layer (vla-AddCircle *rp:spc* (rp:p3 pp elev) (* 0.3 fac)) "ROAD-WIDENING")
        (rp:sidetext cl (car q) (strcat (cadr q) " " (rp:chfmt (+ st0 (/ (car q) fac))))
                     (* sg (+ o (* 0.8 fac))) (* 0.8 th) "ROAD-WIDENING" elev))
      ;; radius marks : both fillets, or both arcs of the reverse curve
      (if (= (nth 6 r) 1)
        (foreach sc (list (+ (nth 3 r) (* 0.25 (- (nth 4 r) (nth 3 r))))
                          (+ (nth 3 r) (* 0.75 (- (nth 4 r) (nth 3 r)))))
          (rp:rmark cl sc (rp:soff profs hw sc) sg
                    (/ (+ (* (- (nth 4 r) (nth 3 r)) (- (nth 4 r) (nth 3 r))) (* (nth 5 r) (nth 5 r)))
                       (* 4.0 (abs (nth 5 r))))
                    fac th elev))
        (if (> (nth 7 r) 0.0)
          (foreach sc (list (nth 3 r) (nth 4 r))
            (rp:rmark cl sc (rp:soff profs hw sc) sg (nth 7 r) fac th elev))))
      (setq mid (* 0.5 (+ (nth 3 r) (nth 4 r)))
            f   (rp:frame cl mid)
            ang (angle '(0.0 0.0) (caddr f))
            rot (if (and (> ang (* 0.5 pi)) (<= ang (* 1.5 pi))) (+ ang pi) ang)
            ip  (rp:offpt cl mid (* sg (+ (rp:soff profs hw mid) bgap bwid fac (* 3.0 th))))
            mt  (vla-AddMText *rp:spc* (rp:p3 ip elev) 0.0
                  (strcat "ROAD TAPER " (car r) "  EDGE " (if (> (nth 5 r) 0) "+" "")
                          (rtos (/ (nth 5 r) fac) 2 2) " m"
                          "\\PCH " (rp:chfmt (+ st0 (/ (nth 3 r) fac))) " - "
                          (rp:chfmt (+ st0 (/ (nth 4 r) fac)))
                          "   L = " (rtos (/ (- (nth 4 r) (nth 3 r)) fac) 2 1) " m"
                          "\\P"
                          (if (= (nth 6 r) 1)
                            (strcat "CURVE TAPER (REVERSE CURVE)  R "
                                    (rtos (/ (/ (+ (* (- (nth 4 r) (nth 3 r)) (- (nth 4 r) (nth 3 r)))
                                                   (* (nth 5 r) (nth 5 r)))
                                                (* 4.0 (abs (nth 5 r))))
                                             fac) 2 1) " m")
                            (strcat "STRAIGHT TAPER 1:" (rtos (/ (- (nth 4 r) (nth 3 r)) (abs (nth 5 r))) 2 1)
                                    (if (> (nth 7 r) 0.0)
                                      (strcat "  -  FILLET R=" (rtos (/ (nth 7 r) fac) 2 1) " m")
                                      "  -  DIRECT LINK")))
                          "\\PROAD WIDTH " (nth 8 r) " m  >  " (nth 9 r) " m")))
      (vla-put-Height mt (* 0.8 th))
      (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
      (vla-put-InsertionPoint mt (rp:p3 ip elev))
      (vla-put-Rotation mt rot)
      (vla-put-Layer mt "ROAD-WIDENING")))
  ;; 7. draw order and bookkeeping
  (setq new (rp:since mark))
  (foreach en new
    (setq ty (cdr (assoc 0 (entget en))) ly (cdr (assoc 8 (entget en))))
    (cond ((= ty "WIPEOUT") (setq wl (cons en wl)))
          ((and (= ty "HATCH") (= ly "ROAD-SURFACE")) (setq sh (cons en sh)))
          ((= ty "HATCH") (setq bh (cons en bh)))
          (T (setq oth (cons en oth)))))
  (if wl  (rp:order-ss (reverse wl) "_F"))
  (if bh  (rp:order-ss (reverse bh) "_F"))
  (if oth (rp:order-ss (reverse oth) "_F"))
  (if sh  (rp:order-ss (reverse sh) "_B"))
  (vlax-ldata-put cl (strcat "ROADPRO_TMAN_" sd)
                  (mapcar '(lambda (x) (cdr (assoc 5 (entget x)))) new))
  (list (- (car add) nr) (- (cadr add) nw) addA cutA))

;; Taper values for one side : (a b d)
;; the right side uses its own fields when Both sides + different chainage
(defun rp:tside-par (sg fac st0 / sx)
  (setq sx (if (and (< sg 0) (= (rp:val "tside") "2") (= (rp:val "tdiff") "1")) "2" ""))
  (list (* fac (- (rp:num (strcat "tst" sx)) st0))
        (* fac (- (rp:num (strcat "ten" sx)) st0))
        (* fac (rp:num (strcat "tshift" sx)))
        (* fac (rp:num (strcat "trad" sx)))))

;; Road width (both sides) at station x for a list of taper records
(defun rp:twidth (recs x hw fac)
  (+ (rp:soff (rp:taper-profs recs 1.0 fac) hw x) (rp:soff (rp:taper-profs recs -1.0 fac) hw x)))

(defun rp:taper-run (e / data fac obj len st0 hw bgap bwid blen elev th curve rf0 rf pr a b d
                       hyp dl rfmax old n id sides newrecs all bad bads s profs bl br res sd)
  (setq data (rp:xget e)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        elev     (vla-get-Elevation obj)
        st0      (atof (rp:xv "CHST" data))
        hw       (* 0.5 fac (atof (rp:xv "W" data)))
        bgap     (* fac (atof (rp:xv "BGAP" data)))
        bwid     (* fac (atof (rp:xv "BWID" data)))
        blen     (* fac (atof (rp:xv "BLEN" data)))
        th       (* fac (rp:num "txth"))
        curve    (= (rp:val "ttype") "1")
        rf0      (and (not curve) (= (rp:val "tmatch") "0"))
        sides    (cond ((= (rp:val "tside") "0") '(1.0))
                       ((= (rp:val "tside") "1") '(-1.0))
                       (T '(1.0 -1.0)))
        *rp:hatches* nil)
  (if (<= blen 0.0) (setq blen (* 2.0 fac)))
  ;; check every side before drawing anything
  (foreach sg sides
    (setq pr (rp:tside-par sg fac st0))
    (if (and (not bads)
             (or (< (car pr) -1e-6) (> (cadr pr) (+ len 1e-6)) (< (abs (caddr pr)) 1e-9)))
      (setq bads (list sg pr))))
  (cond
    ((vlax-curve-isClosed obj)
     (alert "Road tapers are not available on closed (loop) roads."))
    (bads
     (alert (strcat "The " (if (> (car bads) 0) "LEFT" "RIGHT") " side taper is not valid.\n\n"
                    "Road : " (rp:chfmt st0) " to " (rp:chfmt (+ st0 (/ len fac))) "\n"
                    "Taper : " (rp:chfmt (+ st0 (/ (car (cadr bads)) fac))) " to "
                    (rp:chfmt (+ st0 (/ (cadr (cadr bads)) fac)))
                    "\n\nThe taper must lie inside the road and the edge shift cannot be zero.")))
    (T
     (setq old (vlax-ldata-get obj "ROADPRO_TAPERS")
           n   (1+ (if (vlax-ldata-get obj "ROADPRO_TCOUNT") (vlax-ldata-get obj "ROADPRO_TCOUNT") 0))
           id  (strcat "T" (itoa n)))
     (foreach sg sides
       (setq pr (rp:tside-par sg fac st0)
             a  (car pr) b (cadr pr) d (caddr pr)
             rf (if rf0 (cadddr pr) 0.0))
       ;; keep the fillets inside the taper and the road
       (if (> rf 0.0)
         (progn
           (setq hyp   (sqrt (+ (* (- b a) (- b a)) (* d d)))
                 dl    (atan (abs d) (- b a))
                 rfmax (/ (min (* 0.5 hyp) (max (* 0.01 fac) a) (max (* 0.01 fac) (- len b)))
                          (/ (sin (* 0.5 dl)) (cos (* 0.5 dl)))))
           (if (> rf rfmax)
             (progn
               (princ (strcat "\nFillet radius reduced to " (rtos (/ rfmax fac) 2 1) " m on the "
                              (if (> sg 0) "left" "right") " side so it fits inside the taper."))
               (setq rf rfmax)))))
       (setq newrecs (cons (list (strcat id "-" (if (> sg 0) "L" "R")) (if (> sg 0) "Left" "Right")
                                 sg a b d (if curve 1 0) rf)
                           newrecs)))
     (setq newrecs (reverse newrecs)
           all     (append old newrecs))
     ;; the edge must stay clear of the centre line
     (foreach sg sides
       (setq profs (rp:taper-profs all sg fac) s 0.0)
       (while (and (not bad) (<= s len))
         (if (< (rp:soff profs hw s) (* 0.3 fac)) (setq bad s))
         (setq s (+ s fac))))
     (if bad
       (alert (strcat "The road edge would reach the centre line near CH "
                      (rp:chfmt (+ st0 (/ bad fac))) ".\n\nUse a smaller narrowing."))
       (progn
         (setq newrecs (mapcar '(lambda (r)
                                  (append r (list (rtos (/ (rp:twidth all (max 0.0 (- (nth 3 r) fac)) hw fac) fac) 2 2)
                                                  (rtos (/ (rp:twidth all (min len (+ (nth 4 r) fac)) hw fac) fac) 2 2))))
                               newrecs)
               all     (append old newrecs))
         (vlax-ldata-put obj "ROADPRO_TAPERS" all)
         (vlax-ldata-put obj "ROADPRO_TCOUNT" n)
         (setq bl (rp:pairget (rp:xv "BL" data))
               br (rp:pairget (rp:xv "BR" data)))
         (foreach sg sides
           (setq sd  (if (> sg 0) "L" "R")
                 res (rp:taper-rebuild obj sg hw fac len elev blen bgap bwid
                                       (and (rp:on "tbar") (/= (rp:xv (if (> sg 0) "BL" "BR") data) "0,0"))
                                       (rp:on "tlab") st0 th all))
           (vlax-ldata-put obj (strcat "ROADPRO_TAREA_" sd) (list (caddr res) (cadddr res)))
           (if (> sg 0)
             (setq bl (list (+ (car bl) (car res)) (+ (cadr bl) (cadr res))))
             (setq br (list (+ (car br) (car res)) (+ (cadr br) (cadr res))))))
         (setq data (vl-remove-if '(lambda (x) (member (car x) '("BL" "BR"))) data))
         (rp:xput e (append data (list (cons "BL" (rp:pair bl)) (cons "BR" (rp:pair br)))))
         (foreach r newrecs
           (princ (strcat "\n  Road taper " (car r) " (" (cadr r) ") : CH "
                          (rp:chfmt (+ st0 (/ (nth 3 r) fac))) " - " (rp:chfmt (+ st0 (/ (nth 4 r) fac)))
                          ",  edge " (if (> (nth 5 r) 0) "+" "") (rtos (/ (nth 5 r) fac) 2 2)
                          " m,  road width " (nth 8 r) " m > " (nth 9 r) " m")))
         (princ "\n  Run RDR for the updated report.")))))
  (princ))

;; Report rows for tapers : (rows setting-out-rows net-area) or nil
(defun rp:taper-report (obj fac hw st0 iv len / recs rows sto sg profs p s0 s1 s kp o pp ar addT cutT)
  (setq recs (vlax-ldata-get obj "ROADPRO_TAPERS"))
  (if recs
    (progn
      (setq rows (list '("#" "ROAD TAPERS")))
      (foreach r recs
        (setq rows (append rows
                     (list (list (strcat (car r) " - " (cadr r) " side")
                                 (strcat "edge " (if (> (nth 5 r) 0) "+" "") (rtos (/ (nth 5 r) fac) 2 2)
                                         " m,  CH " (rp:chfmt (+ st0 (/ (nth 3 r) fac))) " - "
                                         (rp:chfmt (+ st0 (/ (nth 4 r) fac)))))
                           (list (strcat "   " (car r) " taper / match")
                                 (strcat (if (= (nth 6 r) 1) "Curve (reverse curve)" "Straight") ",  "
                                         (if (= (nth 6 r) 1) "tangent"
                                           (if (> (nth 7 r) 0.0)
                                             (strcat "fillet R " (rtos (/ (nth 7 r) fac) 2 1) " m")
                                             "direct link"))))
                           (list (strcat "   " (car r) " road width") (strcat (nth 8 r) " m  >  " (nth 9 r) " m"))))))
      (foreach r recs
        (setq sg    (nth 2 r)
              profs (rp:taper-profs recs sg fac)
              p     (rp:tprofile (nth 3 r) (nth 4 r) (nth 5 r) (= (nth 6 r) 1) (nth 7 r) fac)
              s0    (car (car p))
              s1    (car (last p))
              kp    (list (list s0 "TS") (list s1 "TE")))
        (if (> iv 0.0)
          (progn
            (setq s (- (* iv (fix (+ 1.0 (/ (+ s0 (* st0 fac)) iv)))) (* st0 fac)))
            (while (< s s1)
              (if (> s s0) (setq kp (cons (list s "CH") kp)))
              (setq s (+ s iv)))))
        (foreach q (vl-sort kp '(lambda (a b) (< (car a) (car b))))
          (setq o   (rp:soff profs hw (car q))
                pp  (rp:offpt obj (car q) (* sg o))
                sto (cons (list (car r) (cadr q) (rp:chfmt (+ st0 (/ (car q) fac)))
                                (rtos (/ (* sg o) fac) 2 3)
                                (rtos (/ (car pp) fac) 2 3) (rtos (/ (cadr pp) fac) 2 3))
                          sto))))
      (setq addT 0.0 cutT 0.0)
      (foreach sd '("L" "R")
        (if (setq ar (vlax-ldata-get obj (strcat "ROADPRO_TAREA_" sd)))
          (setq addT (+ addT (car ar)) cutT (+ cutT (cadr ar)))))
      (setq rows (append rows
                   (list (list "Taper area added / removed"
                               (strcat (rtos (/ addT fac fac) 2 2) " / " (rtos (/ cutT fac fac) 2 2) " m2"))
                         (list "Road width at road end"
                               (strcat (rtos (/ (+ (rp:soff (rp:taper-profs recs 1.0 fac) hw len)
                                                   (rp:soff (rp:taper-profs recs -1.0 fac) hw len))
                                                fac) 2 3) " m")))))
      (list rows (reverse sto) (/ (- addT cutT) fac fac)))))

;;----------------------------------------------------------------------------
;;  ROAD JUNCTION / TIE-IN
;;  Join a new (branch) road to an existing RoadPro road. The branch is built
;;  with the normal RoadPro settings, then the junction is formed:
;;    - main road edge opened between the kerb returns
;;    - kerb-return arcs (corner radius) left and right, radius marked
;;    - corner and mouth surface, barricades cleared from the mouth and
;;      placed around the corners, STOP / GIVE WAY on the branch
;;    - junction label and setting-out (TC / IP / CT of each corner)
;;----------------------------------------------------------------------------
(setq *rp:jdcl*
 (list
  "roadjunc : dialog {"
  "  label = \"ROAD PRO  -  Road Junction / Tie-in\";"
  "  : text { key = \"info\"; width = 62; }"
  "  : row {"
  "    : boxed_column {"
  "      label = \"Joining road (branch)\";"
  "      : edit_box   { key = \"jname\"; label = \"Branch road name / ID:\"; edit_width = 14; }"
  "      : edit_box   { key = \"jwid\";  label = \"Branch road width (m):\"; edit_width = 8; }"
  "      : popup_list { key = \"jmode\"; label = \"Branch centre line:\";    edit_width = 28; }"
  "    }"
  "    : boxed_column {"
  "      label = \"Junction\";"
  "      : edit_box   { key = \"jrad\"; label = \"Corner (kerb return) radius (m):\"; edit_width = 8; }"
  "      : popup_list { key = \"jctl\"; label = \"Control on the branch:\";           edit_width = 18; }"
  "      : toggle     { key = \"jbar\"; label = \"Barricades around the corners\"; }"
  "      : toggle     { key = \"jmark\"; label = \"Road markings in the turning area\"; }"
  "    }"
  "  }"
  "  : text { label = \"Start the branch centre line ON the main road centre line and draw outward.\"; }"
  "  : text { label = \"Barricades, signs and chainage of the branch use your RDP settings.\"; }"
  "  spacer;"
  "  ok_cancel;"
  "  errtile;"
  "}"))

(defun rp:jdlg-accept (/ bad v)
  (foreach k '(("jwid" "Branch road width") ("jrad" "Corner radius"))
    (if (not bad)
      (progn
        (setq v (rp:dist (get_tile (car k))))
        (if (or (null v) (<= v 0.0)) (setq bad k)))))
  (cond
    (bad
     (set_tile "error" (strcat (cadr bad) " must be a number greater than zero."))
     (mode_tile (car bad) 2))
    ((= (vl-string-trim " " (get_tile "jname")) "")
     (set_tile "error" "Enter a name for the branch road.")
     (mode_tile "jname" 2))
    (T
     (foreach k *rp:jkeys* (rp:set k (get_tile k)))
     (done_dialog 1))))

(defun rp:jdialog (info / fn f id res)
  (setq fn (vl-filename-mktemp "roadjunc.dcl"))
  (if (setq f (open fn "w"))
    (progn
      (foreach l *rp:jdcl* (write-line l f))
      (close f)
      (setq id (load_dialog fn))
      (if (and id (not (minusp id)) (new_dialog "roadjunc" id))
        (progn
          (rp:fill "jmode" '("Draw new (from main road CL)" "Select existing Line/Pline/Arc"))
          (rp:fill "jctl"  '("STOP sign" "GIVE WAY sign" "No sign"))
          (foreach k *rp:jkeys* (set_tile k (rp:val k)))
          (set_tile "info" info)
          (action_tile "accept" "(rp:jdlg-accept)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (if (= (start_dialog) 1) 'ok 'cancel)))
        (setq res 'fail))
      (if (and id (not (minusp id))) (unload_dialog id))
      (vl-file-delete fn))
    (setq res 'fail))
  res)

;; ---- geometry helpers ----
(defun rp:p2 (p) (list (car p) (cadr p)))

(defun rp:inters (o1 o2 mode / v sa l out)
  (setq v (vl-catch-all-apply 'vla-IntersectWith (list o1 o2 mode)))
  (if (not (vl-catch-all-error-p v))
    (progn
      (setq sa (vlax-variant-value v))
      (if (and (= (type sa) 'SAFEARRAY) (>= (vlax-safearray-get-u-bound sa 1) 0))
        (progn
          (setq l (vlax-safearray->list sa))
          (while l (setq out (cons (list (car l) (cadr l) (caddr l)) out) l (cdddr l)))))))
  (reverse out))

(defun rp:nearest (pts p / best bd d)
  (setq bd 1e99)
  (foreach q pts (if (< (setq d (distance (rp:p2 q) (rp:p2 p))) bd) (setq best q bd d)))
  best)

(defun rp:cpt (obj p / z)
  (setq z (caddr (vlax-curve-getStartPoint obj)))
  (vlax-curve-getClosestPointTo obj (list (car p) (cadr p) z)))

;; signed lateral offset of point c from a curve (+ = left of its direction)
(defun rp:lat (obj c / cp dv)
  (setq cp (rp:cpt obj c)
        dv (vlax-curve-getFirstDeriv obj (vlax-curve-getParamAtPoint obj cp)))
  (- (* (car dv) (- (cadr c) (cadr cp))) (* (cadr dv) (- (car c) (car cp)))))

(defun rp:unitv (v / l) (setq l (distance '(0.0 0.0) (rp:p2 v))) (if (< l 1e-12) '(1.0 0.0) (list (/ (car v) l) (/ (cadr v) l))))

(defun rp:edge-near (p fac excl / ss i e d best bd)
  (setq ss (ssget "_X" '((0 . "LWPOLYLINE") (8 . "ROAD-EDGE"))) i 0 bd 1e99)
  (if ss
    (repeat (sslength ss)
      (setq e (ssname ss i) i (1+ i))
      (if (not (member e excl))
        (progn
          (setq d (distance (rp:p2 (rp:cpt e p)) (rp:p2 p)))
          (if (< d bd) (setq best e bd d))))))
  (if (and best (< bd (* 5.0 fac))) best))

;; Remove barricade units beside a road : side sg, true lateral distance between
;; lo and hi, centre station between sA and sB. Returns (red white)
(defun rp:jbar-band (obj sg lo hi sA sB / ss i e o mn mx c cp d lat nr nw lay)
  (setq nr 0 nw 0
        ss (ssget "_X" '((8 . "ROAD-BARRIER-RED,ROAD-BARRIER-WHITE,ROAD-BARRIER-OUTLINE")))
        i  0)
  (if ss
    (repeat (sslength ss)
      (setq e (ssname ss i) i (1+ i))
      (if (entget e)
        (progn
          (setq o (vlax-ename->vla-object e))
          (vla-GetBoundingBox o 'mn 'mx)
          (setq mn  (vlax-safearray->list mn)
                mx  (vlax-safearray->list mx)
                c   (list (* 0.5 (+ (car mn) (car mx))) (* 0.5 (+ (cadr mn) (cadr mx))))
                cp  (rp:cpt obj c)
                d   (vlax-curve-getDistAtPoint obj cp)
                lat (* (if (> (rp:lat obj c) 0.0) 1.0 -1.0) (distance c (rp:p2 cp))))
          (if (and d (>= d sA) (<= d sB) (> (* sg lat) lo) (< (* sg lat) hi))
            (progn
              (setq lay (vla-get-Layer o))
              (cond ((= lay "ROAD-BARRIER-RED") (setq nr (1+ nr)))
                    ((= lay "ROAD-BARRIER-WHITE") (setq nw (1+ nw))))
              (vla-Delete o)))))))
  (list nr nw))

;; Remove barricade units near the junction; counts per owner road and side
(defun rp:jbar-remove (pts rad mobj bobj / ss i e o mn mx c hit lay own key cnt a)
  (setq cnt (list (list "ML" 0 0) (list "MR" 0 0) (list "BL" 0 0) (list "BR" 0 0))
        ss  (ssget "_X" '((8 . "ROAD-BARRIER-RED,ROAD-BARRIER-WHITE,ROAD-BARRIER-OUTLINE")))
        i   0)
  (if ss
    (repeat (sslength ss)
      (setq e (ssname ss i) o (vlax-ename->vla-object e) i (1+ i) hit nil)
      (vla-GetBoundingBox o 'mn 'mx)
      (setq mn (vlax-safearray->list mn) mx (vlax-safearray->list mx)
            c  (list (* 0.5 (+ (car mn) (car mx))) (* 0.5 (+ (cadr mn) (cadr mx)))))
      (foreach q pts (if (and (not hit) (< (distance c (rp:p2 q)) rad)) (setq hit T)))
      (if hit
        (progn
          (setq lay (vla-get-Layer o))
          (if (/= lay "ROAD-BARRIER-OUTLINE")
            (progn
              (setq own (if (< (distance c (rp:p2 (rp:cpt mobj c))) (distance c (rp:p2 (rp:cpt bobj c)))) mobj bobj)
                    key (strcat (if (eq own mobj) "M" "B") (if (> (rp:lat own c) 0.0) "L" "R"))
                    a   (assoc key cnt))
              (setq cnt (subst (if (= lay "ROAD-BARRIER-RED")
                                 (list key (1+ (cadr a)) (caddr a))
                                 (list key (cadr a) (1+ (caddr a))))
                               a cnt))))
          (vla-Delete o)))))
  cnt)

(defun rp:jsurf (pts elev / bnd h ar)
  (setq bnd (rp:poly pts "ROAD-SURFACE" elev)
        ar  (vla-get-Area bnd))
  (if (> ar 1e-6)
    (progn
      (setq h (rp:newhatch "SOLID" nil elev))
      (vla-put-Layer h "ROAD-SURFACE")
      (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-AppendOuterLoop (list h (rp:objarr (list bnd)))))
        (progn (vla-Delete h) (setq h nil ar 0.0))
        (progn
          (vla-Evaluate h)
          (vl-catch-all-apply 'vla-put-EntityTransparency (list h "50"))))))
  (vla-Delete bnd)
  (list h ar))

;; White road-marking polygon
(defun rp:jmk (pts elev)
  (rp:solidfill (rp:poly pts "ROAD-MARKING" elev) nil "ROAD-MARKING-FILL" elev))

;; Point from a base, x along direction d, y to the left of d
(defun rp:lmap (base d x y)
  (list (+ (car base) (* x (car d)) (* -1.0 y (cadr d)))
        (+ (cadr base) (* x (cadr d)) (* y (car d)))))

;; Radius mark at the middle of a kerb-return arc
(defun rp:jrmark (arc ip rr fac th elev / mid u pt pm tx)
  (setq mid (nth (/ (length arc) 2) arc)
        u   (rp:unitv (list (- (car mid) (car ip)) (- (cadr mid) (cadr ip))))
        pm  (rp:pt+ mid u (* 1.2 fac))
        pt  (rp:pt+ mid u (+ (* 1.2 fac) (* 1.4 th))))
  (rp:mkwpl (list (list pm 0.0 0.0) (list (rp:towards mid pm (* 0.5 th)) (* 0.25 th) 0.0) (list mid 0.0 0.0))
            "ROAD-JUNCTION" elev)
  (setq tx (rp:text (strcat "R=" (rtos (/ rr fac) 2 2)) pt (* 0.8 th) "ROAD-JUNCTION" elev)))

;; Junction rows for the report of the MAIN road : (rows setting-out) or nil
(defun rp:junc-report (obj / recs rows sto)
  (setq recs (vlax-ldata-get obj "ROADPRO_JUNC"))
  (if recs
    (progn
      (setq rows (list '("#" "JUNCTIONS / TIE-INS")))
      (foreach r recs
        (setq rows (append rows
                     (list (list (strcat (car r) " - " (cadr r))
                                 (strcat "at CH " (nth 2 r) " (" (nth 3 r) " side)"))
                           (list (strcat "   " (car r) " angle / corner R")
                                 (strcat (nth 4 r) "  /  R " (nth 5 r) " m"))
                           (list (strcat "   " (car r) " control") (nth 6 r))
                           (if (nth 8 r) (list (strcat "   " (car r) " road markings") (nth 8 r))))))
        (foreach q (nth 7 r) (setq sto (cons q sto))))
      (list rows (reverse sto)))))

(defun rp:junction-run (me / mdata fac mobj mlen st0 hwm bgap bwid blen elev th br bobj bpt dJ fj sg
                          mside medge xs saved res hwb blen2 rr bd e1 e2 corners k be bep ip ub tm
                          oth dl tl arc t1 t2 c ar pts surfs nm bdata bfac bl br2 cnt cntm cntb add
                          ang jid recs rows jct sA sB lbl mid fb rot mt t2d sd ok
                          mbar bbar s1 glo ghi sb st2 bge pg pb path key
                          mkl q1 q2 u12 sl f dv lm tx shp)
  (setq mdata (rp:xget me)
        fac   (atof (rp:xv "FAC" mdata)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq mobj (vlax-ename->vla-object me)
        mlen (vlax-curve-getDistAtParam mobj (vlax-curve-getEndParam mobj))
        st0  (atof (rp:xv "CHST" mdata))
        hwm  (* 0.5 fac (atof (rp:xv "W" mdata)))
        bgap (* fac (atof (rp:xv "BGAP" mdata)))
        bwid (* fac (atof (rp:xv "BWID" mdata)))
        blen (* fac (atof (rp:xv "BLEN" mdata)))
        elev (vla-get-Elevation mobj)
        th   (* fac (rp:num "txth"))
        hwb  (* 0.5 fac (rp:num "jwid"))
        rr   (* fac (rp:num "jrad")))
  (if (<= blen 0.0) (setq blen (* 2.0 fac)))
  ;; 1. branch centre line
  (setq saved (rp:val "mode"))
  (rp:set "mode" (rp:val "jmode"))
  (princ "\nBranch centre line : start ON the main road centre line and go outward.")
  (setq br (rp:get-centreline))
  (rp:set "mode" saved)
  (cond
    ((null br) (princ "\nNo branch centre line - junction cancelled."))
    ((eq br me) (alert "The branch cannot be the main road itself."))
    (T
     ;; start of the branch must be the end nearest the main road
     (if (> (distance (rp:p2 (vlax-curve-getStartPoint br)) (rp:p2 (rp:cpt mobj (vlax-curve-getStartPoint br))))
            (distance (rp:p2 (vlax-curve-getEndPoint br)) (rp:p2 (rp:cpt mobj (vlax-curve-getEndPoint br)))))
       (command "_.REVERSE" br ""))
     (setq bobj (vlax-ename->vla-object br)
           bpt  (vlax-curve-getStartPoint br))
     (cond
       ((> (distance (rp:p2 bpt) (rp:p2 (rp:cpt mobj bpt))) (+ hwm (* 2.0 fac)))
        (alert "The branch centre line must start on (or very near) the main road.\n\nJunction cancelled."))
       (T
        ;; 2. which side of the main road, and the junction station
        (setq *rp:len* mlen
              dJ   (vlax-curve-getDistAtPoint mobj (rp:cpt mobj bpt))
              fj   (rp:frame mobj dJ)
              ub   (rp:unitv (vlax-curve-getFirstDeriv br (vlax-curve-getStartParam br)))
              sg   (if (> (+ (* (car ub) (car (cadr fj))) (* (cadr ub) (cadr (cadr fj)))) 0.0) 1.0 -1.0)
              mside (if (> sg 0) "Left" "Right")
              ang  (rp:acos (abs (+ (* (car ub) (car (caddr fj))) (* (cadr ub) (cadr (caddr fj)))))))
        (setq medge (rp:edge-near (list (car (rp:offpt mobj dJ (* sg hwm))) (cadr (rp:offpt mobj dJ (* sg hwm))) elev) fac nil))
        (cond
          ((null medge) (alert "The main road edge was not found at the junction.\n\nJunction cancelled."))
          (T
           ;; 3. cut the branch centre line back to the main road edge
           (setq xs (rp:inters bobj (vlax-ename->vla-object medge) acExtendNone))
           (if xs
             (progn
               (setq k (rp:nearest xs bpt))
               (if (> (distance (rp:p2 k) (rp:p2 bpt)) (* 0.01 fac))
                 (progn
                   (setvar "OSMODE" 0)
                   (rp:break br bpt k)))))
           ;; 4. build the branch with the RDP settings
           (setq saved (mapcar '(lambda (x) (cons x (rp:val x))) '("rname" "width" "endst" "report" "xsec" "chst")))
           (rp:set "rname" (rp:val "jname"))
           (rp:set "width" (rp:val "jwid"))
           (rp:set "endst" "3")
           (rp:set "report" "0")
           (rp:set "xsec" "0")
           (rp:set "chst" "0")
           (setq *rp:presetcl* br)
           (setq ok (vl-catch-all-apply 'rp:run nil))
           (setq *rp:presetcl* nil)
           (foreach x saved (rp:set (car x) (cdr x)))
           (cond
             ((or (vl-catch-all-error-p ok) (null (rp:xget br)))
              (alert "The branch road could not be built.\n\nJunction cancelled."))
             (T
              (setq bdata (rp:xget br)
                    *rp:hatches* nil
                    blen2 (vlax-curve-getDistAtParam br (vlax-curve-getEndParam br)))
              ;; 5. branch edges and the corner points IP (edge x main edge)
              (setq *rp:len* blen2
                    e1 (rp:edge-near (append (rp:offpt bobj (* 0.5 fac) hwb) (list elev)) fac (list medge))
                    e2 (rp:edge-near (append (rp:offpt bobj (* 0.5 fac) (- hwb)) (list elev)) fac (list medge)))
              (foreach be (list e1 e2)
                (if be
                  (progn
                    (setq bep (vlax-curve-getStartPoint be)
                          ip  (rp:nearest (rp:inters (vlax-ename->vla-object be) (vlax-ename->vla-object medge)
                                                     acExtendThisEntity)
                                          bep))
                    (if ip (setq corners (cons (list be bep ip) corners))))))
              (setq corners (reverse corners))
              (if (/= (length corners) 2)
                (alert "The kerb returns could not be formed (branch edges do not meet the main road edge).")
                (progn
                  ;; 6. kerb-return arcs
                  (foreach cr corners
                    (setq be  (car cr) bep (cadr cr) ip (caddr cr)
                          oth (caddr (if (eq cr (car corners)) (cadr corners) (car corners)))
                          ub  (rp:unitv (vlax-curve-getFirstDeriv be (vlax-curve-getStartParam be)))
                          tm  (rp:unitv (vlax-curve-getFirstDeriv medge
                                          (vlax-curve-getParamAtPoint medge (rp:cpt medge ip)))))
                    (if (< (+ (* (car tm) (- (car ip) (car oth))) (* (cadr tm) (- (cadr ip) (cadr oth)))) 0.0)
                      (setq tm (list (- (car tm)) (- (cadr tm)))))
                    ;; keep the tangent length inside the branch edge
                    (setq dl (rp:acos (+ (* (- (car tm)) (car ub)) (* (- (cadr tm)) (cadr ub))))
                          tl (* rr (/ (sin (* 0.5 dl)) (cos (* 0.5 dl)))))
                    (setq c rr)
                    (if (> tl (* 0.6 (vlax-curve-getDistAtParam be (vlax-curve-getEndParam be))))
                      (setq c (/ (* 0.6 (vlax-curve-getDistAtParam be (vlax-curve-getEndParam be)))
                                 (/ (sin (* 0.5 dl)) (cos (* 0.5 dl))))))
                    (setq arc (rp:fillet-pts (rp:pt+ (rp:p2 ip) tm (* 4.0 c)) (rp:p2 ip)
                                             (rp:pt+ (rp:p2 ip) ub (* 4.0 c)) c 24))
                    (setq res (cons (list be bep (rp:p2 ip) arc c) res)))
                  (setq res (reverse res))
                  ;; 7. open the main road edge between the two returns
                  (setvar "OSMODE" 0)
                  (setq t1 (rp:cpt medge (append (car (nth 3 (car res))) (list elev)))
                        t2 (rp:cpt medge (append (car (nth 3 (cadr res))) (list elev))))
                  (rp:break medge t1 t2)
                  ;; 8. trim the branch edges back to the end of each return
                  (foreach cr res
                    (setq be (car cr) bep (cadr cr) ip (caddr cr) arc (nth 3 cr)
                          t2d (last arc)
                          ub  (rp:unitv (list (- (car t2d) (car ip)) (- (cadr t2d) (cadr ip)))))
                    (if (> (+ (* (car ub) (- (car t2d) (car bep))) (* (cadr ub) (- (cadr t2d) (cadr bep)))) 0.0)
                      (rp:break be (rp:cpt be bep) (rp:cpt be (append t2d (list elev))))
                      (rp:line t2d (rp:p2 bep) "ROAD-EDGE" elev))
                    ;; the return arc
                    (rp:mkpl (mapcar '(lambda (q) (list q 0.0)) arc) "ROAD-EDGE" elev nil))
                  ;; 9. corner and mouth surface
                  (foreach cr res
                    (setq surfs (cons (car (rp:jsurf (cons (caddr cr) (nth 3 cr)) elev)) surfs)))
                  (setq surfs (cons (car (rp:jsurf (list (caddr (car res)) (caddr (cadr res))
                                                         (rp:p2 (cadr (cadr res))) (rp:p2 (cadr (car res))))
                                                   elev))
                                    surfs))
                  ;; 10. barricades : remove exactly the units that touch the junction
                  ;;     (whole units on the main road and on the branch), then lay ONE
                  ;;     continuous run per corner : main edge > kerb return > branch edge
                  (setq cnt  (list (list "ML" 0 0) (list "MR" 0 0) (list "BL" 0 0) (list "BR" 0 0))
                        add  (list 0 0)
                        mbar (/= (rp:xv (if (> sg 0) "BL" "BR") mdata) "0,0")
                        s1   (mapcar '(lambda (cr) (vlax-curve-getDistAtPoint mobj (rp:cpt mobj (car (nth 3 cr))))) res)
                        glo  (max 0.0 (* blen (fix (/ (apply 'min s1) blen))))
                        ghi  (min mlen (* blen (fix (+ 0.999999 (/ (apply 'max s1) blen))))))
                  (setq k (rp:jbar-band mobj sg hwm (+ hwm bgap bwid (* 0.5 fac)) glo ghi)
                        cnt (subst (cons (if (> sg 0) "ML" "MR") k) (assoc (if (> sg 0) "ML" "MR") cnt) cnt))
                  (foreach cr res
                    (setq arc  (nth 3 cr)
                          sb   (if (> (rp:lat bobj (cadr cr)) 0.0) 1.0 -1.0)
                          bbar (/= (rp:xv (if (> sb 0) "BL" "BR") bdata) "0,0")
                          st2  (vlax-curve-getDistAtPoint bobj (rp:cpt bobj (last arc)))
                          bge  (min blen2 (* blen (fix (+ 0.999999 (/ st2 blen))))))
                    (setq k   (rp:jbar-band bobj sb hwb (+ hwb bgap bwid (* 0.5 fac)) (- blen) bge)
                          key (if (> sb 0) "BL" "BR")
                          cnt (subst (list key (+ (cadr (assoc key cnt)) (car k)) (+ (caddr (assoc key cnt)) (cadr k)))
                                     (assoc key cnt) cnt))
                    (if (rp:on "jbar")
                      (progn
                        ;; path : main edge at the end of the removed units > T1 > arc > T2 > branch edge
                        (setq *rp:len* mlen
                              pg   (if mbar
                                     (rp:offpt mobj (if (< (vlax-curve-getDistAtPoint mobj (rp:cpt mobj (car arc)))
                                                           (* 0.5 (+ glo ghi)))
                                                      glo ghi)
                                               (* sg hwm)))
                              *rp:len* blen2
                              pb   (if bbar (rp:offpt bobj bge (* sb hwb)))
                              path (append (if (and pg (> (distance pg (car arc)) (* 0.05 fac))) (list pg))
                                           arc
                                           (if (and pb (> (distance pb (last arc)) (* 0.05 fac))) (list pb)))
                              path (rp:mkpl (mapcar '(lambda (q) (list q 0.0)) path) "ROAD-JUNCTION" elev nil)
                              *rp:len* (vlax-curve-getDistAtParam path (vlax-curve-getEndParam path))
                              sd   (if (> (rp:lat path (caddr cr)) 0.0) -1.0 1.0)
                              k    (rp:barrier path *rp:len* (* sd bgap) (* sd (+ bgap bwid)) blen
                                               (min blen (* 0.25 fac)) elev)
                              add  (list (+ (car add) (car k)) (+ (cadr add) (cadr k))))
                        (vla-Delete path)))
                    (setq *rp:len* blen2))
                  ;; 10b. road markings in the turning area
                  (setq mkl nil)
                  (if (rp:on "jmark")
                    (progn
                      ;; broken edge line across the junction mouth (main road edge continued)
                      (setq q1  (caddr (car res))
                            q2  (caddr (cadr res))
                            u12 (rp:unitv (list (- (car q2) (car q1)) (- (cadr q2) (cadr q1))))
                            k   0.0)
                      (while (< (+ k (* 1.0 fac)) (distance q1 q2))
                        (rp:jmk (list (rp:lmap q1 u12 k (* -0.075 fac)) (rp:lmap q1 u12 (+ k fac) (* -0.075 fac))
                                      (rp:lmap q1 u12 (+ k fac) (* 0.075 fac)) (rp:lmap q1 u12 k (* 0.075 fac)))
                                elev)
                        (setq k (+ k (* 2.0 fac))))
                      (setq mkl (list "broken edge line across the mouth"))
                      ;; approach lane of the branch (two-way : traffic coming to the junction)
                      (setq *rp:len* blen2
                            sl  (+ (apply 'max (mapcar '(lambda (cr) (vlax-curve-getDistAtPoint bobj (rp:cpt bobj (last (nth 3 cr))))) res))
                                   (* 1.0 fac)))
                      (if (and (rp:on "twoway") (< sl (- blen2 (* 16.0 fac))))
                        (progn
                          (setq f  (rp:frame bobj sl)
                                dv (list (- (car (caddr f))) (- (cadr (caddr f))))
                                lm (* 0.5 hwb))
                          (cond
                            ;; STOP : solid stop line + STOP word
                            ((= (rp:val "jctl") "0")
                             (rp:jmk (list (rp:loc f (* 0.15 fac) 0.0) (rp:loc f (- hwb (* 0.15 fac)) 0.0)
                                           (rp:loc f (- hwb (* 0.15 fac)) (* 0.3 fac)) (rp:loc f (* 0.15 fac) (* 0.3 fac)))
                                     elev)
                             (setq tx (rp:text "STOP" (rp:loc f lm (* 4.0 fac)) (* 1.6 fac) "ROAD-MARKING-FILL" elev))
                             (vl-catch-all-apply 'vla-put-ScaleFactor (list tx 0.4))
                             (vla-put-Rotation tx (- (angle '(0.0 0.0) dv) (* 0.5 pi)))
                             (setq mkl (cons "stop line + STOP word" mkl)))
                            ;; GIVE WAY : broken give-way line + triangle
                            ((= (rp:val "jctl") "1")
                             (setq k (* 0.15 fac))
                             (while (< (+ k (* 0.6 fac)) hwb)
                               (rp:jmk (list (rp:loc f k 0.0) (rp:loc f (+ k (* 0.6 fac)) 0.0)
                                             (rp:loc f (+ k (* 0.6 fac)) (* 0.3 fac)) (rp:loc f k (* 0.3 fac)))
                                       elev)
                               (setq k (+ k (* 1.2 fac))))
                             (rp:jmk (list (rp:loc f (- lm (* 0.75 fac)) (* 2.5 fac)) (rp:loc f (+ lm (* 0.75 fac)) (* 2.5 fac))
                                           (rp:loc f lm (* 5.0 fac)))
                                     elev)
                             (setq mkl (cons "give-way line + triangle" mkl))))
                          ;; left / right turn arrow 12 m before the line
                          (setq f  (rp:frame bobj (+ sl (* 12.0 fac)))
                                dv (list (- (car (caddr f))) (- (cadr (caddr f))))
                                q1 (rp:loc f lm 0.0))
                          (foreach shp (list '((0.0 -0.15) (2.85 -0.15) (2.85 0.15) (0.0 0.15))
                                             '((2.55 0.0) (2.85 0.0) (2.85 1.0) (3.15 1.0) (2.7 1.6) (2.25 1.0) (2.55 1.0))
                                             '((2.55 0.0) (2.85 0.0) (2.85 -1.0) (3.15 -1.0) (2.7 -1.6) (2.25 -1.0) (2.55 -1.0)))
                            (rp:jmk (mapcar '(lambda (q) (rp:lmap q1 dv (* fac (car q)) (* fac (cadr q)))) shp) elev))
                          (setq mkl (cons "left / right turn arrow" mkl))))))
                  ;; barricade counts : main road side and branch sides
                  (setq cntm (rp:pairget (rp:xv (if (> sg 0) "BL" "BR") mdata))
                        k    (assoc (if (> sg 0) "ML" "MR") cnt)
                        cntm (list (+ (- (car cntm) (cadr k)) (car add)) (+ (- (cadr cntm) (caddr k)) (cadr add))))
                  (setq mdata (vl-remove-if '(lambda (x) (= (car x) (if (> sg 0) "BL" "BR"))) mdata))
                  (rp:xput me (append mdata (list (cons (if (> sg 0) "BL" "BR") (rp:pair cntm)))))
                  (foreach sd '("BL" "BR")
                    (setq k    (assoc sd cnt)
                          cntb (rp:pairget (rp:xv sd bdata))
                          bdata (vl-remove-if '(lambda (x) (= (car x) sd)) bdata)
                          bdata (append bdata (list (cons sd (rp:pair (list (max 0 (- (car cntb) (cadr k)))
                                                                             (max 0 (- (cadr cntb) (caddr k))))))))))
                  (rp:xput br bdata)
                  ;; 11. labels : radius marks + junction label
                  (setq *rp:len* blen2
                        recs (vlax-ldata-get mobj "ROADPRO_JUNC")
                        jid  (strcat "J" (itoa (1+ (length recs))))
                        jct  (cond ((= (rp:val "jctl") "0") "STOP") ((= (rp:val "jctl") "1") "GIVE WAY") (T "None")))
                  (foreach cr res (rp:jrmark (nth 3 cr) (caddr cr) (nth 4 cr) fac th elev))
                  (setq mid (min blen2 (+ (* 4.0 rr) (* 3.0 fac)))
                        fb  (rp:frame bobj mid)
                        ang (* 1.0 ang)
                        rot (angle '(0.0 0.0) (caddr fb))
                        rot (if (and (> rot (* 0.5 pi)) (<= rot (* 1.5 pi))) (+ rot pi) rot)
                        mt  (vla-AddMText *rp:spc*
                              (rp:p3 (rp:offpt bobj mid (+ hwb bgap bwid fac (* 3.0 th))) elev) 0.0
                              (strcat "JUNCTION " jid " : " (rp:val "jname") " joins " (rp:xv "NAME" mdata)
                                      "\\PAT CH " (rp:chfmt (+ st0 (/ dJ fac))) " (" mside " side)"
                                      "\\PANGLE " (vl-string-subst "\\U+00B0" "%%d" (rp:dms ang T))
                                      "   CORNER R=" (rtos (/ rr fac) 2 2) " m"
                                      "\\PCONTROL : " jct)))
                  (vla-put-Height mt (* 0.8 th))
                  (vla-put-AttachmentPoint mt acAttachmentPointMiddleCenter)
                  (vla-put-InsertionPoint mt (rp:p3 (rp:offpt bobj mid (+ hwb bgap bwid fac (* 3.0 th))) elev))
                  (vla-put-Rotation mt rot)
                  (vla-put-Layer mt "ROAD-JUNCTION")
                  ;; 12. setting-out of the kerb returns, stored on the main road
                  (setq *rp:len* mlen sd 0)
                  (foreach cr res
                    (setq sd (1+ sd) arc (nth 3 cr))
                    (foreach q (list (list "TC" (car arc)) (list "IP" (caddr cr)) (list "CT" (last arc)))
                      (setq rows (cons (list (strcat jid "-" (itoa sd)) (car q)
                                             (rp:chfmt (+ st0 (/ (vlax-curve-getDistAtPoint mobj (rp:cpt mobj (cadr q))) fac)))
                                             (rtos (/ (car (cadr q)) fac) 2 3) (rtos (/ (cadr (cadr q)) fac) 2 3))
                                       rows))))
                  (vlax-ldata-put mobj "ROADPRO_JUNC"
                                  (append recs (list (list jid (rp:val "jname") (rp:chfmt (+ st0 (/ dJ fac))) mside
                                                           (rp:dms ang nil) (rtos (/ rr fac) 2 2) jct (reverse rows)
                                                           (if mkl (rp:join (reverse mkl) ", ") "none")))))
                  ;; 13. draw order
                  (if *rp:hatches* (rp:toback *rp:hatches*))
                  (setq surfs (vl-remove nil surfs))
                  (if surfs (rp:toback surfs))
                  (princ (strcat "\n  Junction " jid " : " (rp:val "jname") " joins " (rp:xv "NAME" mdata)
                                 " at CH " (rp:chfmt (+ st0 (/ dJ fac))) ", " mside " side, corner R "
                                 (rtos (/ rr fac) 2 2) " m."))
                  ;; 14. road markings : gaps at the junction, then redraw if the roads have markings
                  (setq *rp:len* mlen
                        k    (vlax-ldata-get mobj "ROADPRO_MKGAP"))
                  (vlax-ldata-put mobj "ROADPRO_MKGAP"
                                  (cons (list "E" sg (apply 'min s1) (apply 'max s1)) k))
                  (setq k nil sd 0.0)
                  (foreach cr res
                    (setq sb  (if (> (rp:lat bobj (cadr cr)) 0.0) 1.0 -1.0)
                          st2 (vlax-curve-getDistAtPoint bobj (rp:cpt bobj (last (nth 3 cr))))
                          sd  (max sd st2)
                          k   (cons (list "E" sb 0.0 st2) k)))
                  (vlax-ldata-put bobj "ROADPRO_MKGAP" (cons (list "S" 1.0 0.0 (+ sd (* 16.0 fac))) k))
                  (if (vlax-ldata-get mobj "ROADPRO_MKMAN") (rp:mark-run me))
                  (if (vlax-ldata-get bobj "ROADPRO_MKMAN") (rp:mark-run br))
                  (princ "\n  Run RDR on either road for the updated report.")))))))))))
  (princ))

;;----------------------------------------------------------------------------
;;  ROAD MARKINGS
;;  White 150 mm lines : edge lines 0.30 m inside each edge (they follow road
;;  tapers), lane line on the centre line - broken 3 m / 6 m, solid on bends
;;  (10 m before and after) and on junction approaches. No lane line with a
;;  centre median. Gaps where junctions open the edge. Every run replaces the
;;  previous markings of that road and stores the paint quantities.
;;----------------------------------------------------------------------------
;; White strip between stations a and b; edge = T follows the edge (side sg)
(defun rp:mk-strip (obj a b sg profs hw fac elev edge / s0 s1 n i d o1 o2 pa pb)
  (setq s0 a)
  (while (< s0 (- b 1e-6))
    (setq s1 (min b (+ s0 (* 50.0 fac)))
          n  (max 1 (fix (+ 0.999999 (/ (- s1 s0) fac))))
          i  0 pa nil pb nil)
    (repeat (1+ n)
      (setq d (+ s0 (* (- s1 s0) (/ (float i) n))))
      (if edge
        (setq o2 (- (rp:soff profs hw d) (* 0.3 fac)) o1 (- o2 (* 0.15 fac)))
        (setq o1 (* -0.075 fac) o2 (* 0.075 fac)))
      (setq pa (cons (rp:offpt obj d (* sg o1)) pa)
            pb (cons (rp:offpt obj d (* sg o2)) pb)
            i  (1+ i)))
    (rp:jmk (append (reverse pa) pb) elev)
    (setq s0 s1)))

;; [a b] minus a list of (lo hi) gaps -> list of (a b) pieces
(defun rp:mk-ranges (a b gaps / out cur g)
  (setq cur a)
  (foreach g (vl-sort gaps '(lambda (x y) (< (car x) (car y))))
    (if (> (car g) cur) (setq out (cons (list cur (min b (car g))) out)))
    (setq cur (max cur (cadr g))))
  (if (< cur b) (setq out (cons (list cur b) out)))
  (vl-remove-if '(lambda (r) (< (- (cadr r) (car r)) 1e-6)) (reverse out)))

(defun rp:mk-inside (d ranges / hit)
  (foreach r ranges (if (and (> d (- (car r) 1e-6)) (< d (+ (cadr r) 1e-6))) (setq hit T)))
  hit)

(defun rp:mark-run (e / data fac obj len hw elev bc recs gaps curves en mark new solid sg rg d de
                      qe qb qs sh oth ty ly)
  (setq data (rp:xget e)
        fac  (atof (rp:xv "FAC" data)))
  (if (<= fac 0.0) (setq fac 1.0))
  (setq obj      (vlax-ename->vla-object e)
        len      (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
        *rp:len* len
        hw       (* 0.5 fac (atof (rp:xv "W" data)))
        elev     (vla-get-Elevation obj)
        bc       (/= (rp:xv "BC" data) "0,0")
        recs     (vlax-ldata-get obj "ROADPRO_TAPERS")
        gaps     (vlax-ldata-get obj "ROADPRO_MKGAP")
        curves   (rp:curves obj)
        qe 0.0 qb 0.0 qs 0.0)
  ;; remove the previous markings of this road
  (foreach hd (vlax-ldata-get obj "ROADPRO_MKMAN")
    (if (and (setq en (handent hd)) (entget en)) (entdel en)))
  (setq mark (entlast))
  ;; edge lines, both sides, with gaps at junctions
  (foreach sg '(1.0 -1.0)
    (foreach rg (rp:mk-ranges 0.0 len
                  (mapcar '(lambda (g) (list (nth 2 g) (nth 3 g)))
                          (vl-remove-if-not '(lambda (g) (and (= (car g) "E") (= (cadr g) sg))) gaps)))
      (rp:mk-strip obj (car rg) (cadr rg) sg (rp:taper-profs recs sg fac) hw fac elev T)
      (setq qe (+ qe (- (cadr rg) (car rg))))))
  ;; lane line on the centre line
  (if (not bc)
    (progn
      (setq solid nil)
      (foreach c curves
        (if (>= (nth 3 c) (/ pi 18.0))
          (setq solid (cons (list (max 0.0 (- (car c) (* 10.0 fac))) (min len (+ (cadr c) (* 10.0 fac)))) solid))))
      (foreach g gaps (if (= (car g) "S") (setq solid (cons (list (max 0.0 (nth 2 g)) (min len (nth 3 g))) solid))))
      ;; solid parts, merged (the complement of the complement)
      (setq solid (rp:mk-ranges 0.0 len (rp:mk-ranges 0.0 len solid)))
      (foreach rg solid
        (rp:mk-strip obj (car rg) (cadr rg) 1.0 nil hw fac elev nil)
        (setq qs (+ qs (- (cadr rg) (car rg)))))
      ;; broken parts : 3 m dash, 6 m gap, outside the solid parts
      (setq d 0.0)
      (while (< d len)
        (setq de (min len (+ d (* 3.0 fac))))
        (if (and (not (rp:mk-inside d solid)) (not (rp:mk-inside de solid)) (> (- de d) (* 0.5 fac)))
          (progn
            (rp:mk-strip obj d de 1.0 nil hw fac elev nil)
            (setq qb (+ qb (- de d)))))
        (setq d (+ d (* 9.0 fac))))))
  ;; bookkeeping and draw order : markings above the surface, below all lines
  (setq new (rp:since mark))
  (vlax-ldata-put obj "ROADPRO_MKMAN" (mapcar '(lambda (x) (cdr (assoc 5 (entget x)))) new))
  (vlax-ldata-put obj "ROADPRO_MKQTY" (list qe qb qs))
  (foreach x new
    (if (= (cdr (assoc 0 (entget x))) "HATCH") (setq sh (cons x sh)) (setq oth (cons x oth))))
  (if sh (rp:order-ss (reverse sh) "_B"))
  (if oth (rp:order-ss (reverse oth) "_B"))
  (setq sh (ssget "_X" '((0 . "HATCH") (8 . "ROAD-SURFACE"))))
  (if sh (command "_.DRAWORDER" sh "" "_B"))
  (princ (strcat "\n  Road markings : edge lines " (rtos (/ qe fac) 2 1) " m, lane line "
                 (rtos (/ qb fac) 2 1) " m broken + " (rtos (/ qs fac) 2 1) " m solid."))
  (princ))

;;----------------------------------------------------------------------------
;;  Commands
;;----------------------------------------------------------------------------
(defun c:ROADPRO (/ res)
  (rp:start)
  (setq res (rp:dialog))
  (if (= res 'fail)
    (progn
      (princ "\nDialog not available - using command line.")
      (rp:cmdline)
      (setq res 'ok)))
  (if (= res 'ok) (rp:run) (princ "\nRoad Pro cancelled."))
  (rp:finish))

(defun c:RDP () (c:ROADPRO))

(defun c:ROADREPORT (/ sel)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel (rp:report-make (car sel) T))
  (rp:finish))

(defun c:RDR () (c:ROADREPORT))

;; Add radius / TC / CT / curve data labels to an existing RoadPro road
(defun c:ROADRADIUS (/ sel e data fac obj hw n)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (setq *rp:hatches* nil)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq e    (car sel)
            data (rp:xget e)
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq obj      (vlax-ename->vla-object e)
            hw       (* 0.5 fac (atof (rp:xv "W" data)))
            *rp:len* (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
            n        (rp:curve-labels obj (rp:curves obj) hw fac (* fac (rp:num "txth"))
                                      (atof (rp:xv "CHST" data)) (vla-get-Elevation obj)
                                      (/= (rp:xv "BL" data) "0,0") (/= (rp:xv "BR" data) "0,0")
                                      (/= (atoi (rp:xv "NCHM" data)) 0)
                                      (* fac (atof (rp:xv "BGAP" data)))
                                      (* fac (atof (rp:xv "BWID" data)))
                                      (= (rp:xv "RREF" data) "1")))
      (princ (strcat "\n  Radius labels added to " (itoa n) " curve(s) on layer ROAD-CURVE."))))
  (rp:finish))

(defun c:RDRAD () (c:ROADRADIUS))

;; Add straight-section labels to an existing RoadPro road
(defun c:ROADSECTIONS (/ sel e data fac obj hw n)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq e    (car sel)
            data (rp:xget e)
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq obj      (vlax-ename->vla-object e)
            hw       (* 0.5 fac (atof (rp:xv "W" data)))
            *rp:len* (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
            n        (rp:straight-labels
                       obj (rp:straights obj) hw fac (* fac (rp:num "txth"))
                       (atof (rp:xv "CHST" data)) (vla-get-Elevation obj)
                       (+ hw
                          (if (/= (rp:xv "BR" data) "0,0")
                            (* fac (+ (atof (rp:xv "BGAP" data)) (atof (rp:xv "BWID" data))))
                            0.0)
                          (* 0.5 fac) (* 0.6 fac) (* 1.5 fac (rp:num "signsz")))))
      (princ (strcat "\n  " (itoa n) " straight section(s) labelled on layer ROAD-SECTION."))))
  (rp:finish))

(defun c:RDSEC () (c:ROADSECTIONS))

;; Cross section drawings of a RoadPro road
(defun c:ROADXSEC (/ sel res)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq res (rp:xdialog))
      (if (= res 'fail) (princ "\nDialog not available - using saved cross-section settings."))
      (if (/= res 'cancel)
        (rp:xsec-run (car sel) (rp:val "xmode"))
        (princ "\nCross section cancelled."))))
  (rp:finish))

(defun c:RDX () (c:ROADXSEC))

;; Lane widening on a RoadPro road
(defun c:ROADWIDEN (/ sel data fac len res)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq data (rp:xget (car sel))
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq len (vlax-curve-getDistAtParam (car sel) (vlax-curve-getEndParam (car sel))))
      (setq res (rp:wdialog (strcat "Road " (rp:xv "NAME" data) " :  CH "
                                    (rp:chfmt (atof (rp:xv "CHST" data))) "  to  "
                                    (rp:chfmt (+ (atof (rp:xv "CHST" data)) (/ len fac)))
                                    "   |   width " (rp:xv "W" data) " m")))
      (if (= res 'fail) (princ "\nDialog not available - using saved widening settings."))
      (if (/= res 'cancel)
        (rp:widen-run (car sel))
        (princ "\nLane widening cancelled."))))
  (rp:finish))

(defun c:RDW () (c:ROADWIDEN))

;; Road taper anywhere on a RoadPro road
(defun c:ROADTAPER (/ sel data fac len res)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq data (rp:xget (car sel))
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq len (vlax-curve-getDistAtParam (car sel) (vlax-curve-getEndParam (car sel))))
      (setq res (rp:tdialog (strcat "Road " (rp:xv "NAME" data) " :  CH "
                                    (rp:chfmt (atof (rp:xv "CHST" data))) "  to  "
                                    (rp:chfmt (+ (atof (rp:xv "CHST" data)) (/ len fac)))
                                    "   |   design width " (rp:xv "W" data) " m")))
      (if (= res 'fail) (princ "\nDialog not available - using saved taper settings."))
      (if (/= res 'cancel)
        (rp:taper-run (car sel))
        (princ "\nRoad taper cancelled."))))
  (rp:finish))

(defun c:RDT () (c:ROADTAPER))

;; Join a new road to an existing RoadPro road
(defun c:ROADJUNCTION (/ sel data fac len res)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (setq *rp:presetcl* nil)
  (while (and (setq sel (entsel "\nSelect the MAIN road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (setq data (rp:xget (car sel))
            fac  (atof (rp:xv "FAC" data)))
      (if (<= fac 0.0) (setq fac 1.0))
      (setq len (vlax-curve-getDistAtParam (car sel) (vlax-curve-getEndParam (car sel))))
      (setq res (rp:jdialog (strcat "Main road " (rp:xv "NAME" data) " :  CH "
                                    (rp:chfmt (atof (rp:xv "CHST" data))) "  to  "
                                    (rp:chfmt (+ (atof (rp:xv "CHST" data)) (/ len fac)))
                                    "   |   width " (rp:xv "W" data) " m")))
      (if (= res 'fail) (princ "\nDialog not available - using saved junction settings."))
      (if (/= res 'cancel)
        (rp:junction-run (car sel))
        (princ "\nRoad junction cancelled."))))
  (setq *rp:presetcl* nil)
  (rp:finish))

(defun c:RDJ () (c:ROADJUNCTION))

;; Road markings on any RoadPro road (draw again = refresh, or remove)
(defun c:ROADMARK (/ sel opt obj en)
  (rp:start)
  (rp:space)
  (rp:world)
  (rp:linetypes)
  (rp:layers)
  (while (and (setq sel (entsel "\nSelect the road centre line (layer ROAD-CL): "))
              (not (rp:xget (car sel))))
    (princ "\n  No RoadPro data on this object - select the centre line of a RoadPro road."))
  (if sel
    (progn
      (initget "Draw Remove")
      (setq opt (getkword "\nRoad markings [Draw/Remove] <Draw>: "))
      (if (= opt "Remove")
        (progn
          (setq obj (vlax-ename->vla-object (car sel)))
          (foreach hd (vlax-ldata-get obj "ROADPRO_MKMAN")
            (if (and (setq en (handent hd)) (entget en)) (entdel en)))
          (vlax-ldata-delete obj "ROADPRO_MKMAN")
          (vlax-ldata-delete obj "ROADPRO_MKQTY")
          (princ "\n  Road markings removed."))
        (rp:mark-run (car sel)))))
  (rp:finish))

(defun c:RDM () (c:ROADMARK))

(defun c:ROADPRORESET ()
  (foreach p *rp:defaults* (rp:set (car p) (cdr p)))
  (princ "\nRoad Pro settings restored to defaults (width 7.30 m, radius 10 m).")
  (princ))

(princ (strcat "\nRoad Pro v" *rp:ver* " loaded.  ROADPRO (RDP) = build road   |   ROADREPORT (RDR) = report   |   ROADRADIUS (RDRAD) = radius   |   ROADSECTIONS (RDSEC) = straights   |   ROADXSEC (RDX) = cross sections   |   ROADWIDEN (RDW) = lane widening   |   ROADTAPER (RDT) = road taper   |   ROADJUNCTION (RDJ) = junction / tie-in   |   ROADMARK (RDM) = road markings"))
(princ "\nDeveloped by https://www.exceltokml.com/")
(princ)
