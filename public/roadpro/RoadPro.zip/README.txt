RoadPro v3.3 - Road Builder for AutoCAD
Developed by https://www.exceltokml.com/
Date: 12-Oct-2026

FILES
  RoadPro.lsp              The AutoCAD plugin (AutoLISP)
  RoadPro_User_Guide.pdf   Complete user manual - 38 pages, step by step
  RoadPro_User_Guide.pptx  Complete user manual - editable PowerPoint
  RoadPro_Shortcuts.xlsx   All shortcut keys, ready to print

INSTALL
  1. Copy RoadPro.lsp to a fixed folder, e.g. C:\RoadPro\
  2. In AutoCAD type APPLOAD, select RoadPro.lsp and click Load
  3. To load it every time: APPLOAD > Startup Suite > Contents > Add
  Needs full AutoCAD / Civil 3D / Map 3D 2014 or newer (not AutoCAD LT)
  Upgrading from 3.2: replace the old file, your settings are kept.

SHORTCUTS
  RDP    ROADPRO       Build a complete road from a centre line
  RDR    ROADREPORT    Report tables + Excel (CSV) file
  RDRAD  ROADRADIUS    Radius, TC / CT and curve data on plan
  RDSEC  ROADSECTIONS  Straight section labels S1, S2 ...
  RDX    ROADXSEC      Cross sections
  RDW    ROADWIDEN     Lane widening with tapers
  RDT    ROADTAPER     Road taper - wider or narrower
  RDJ    ROADJUNCTION  Junction / tie-in, corner treatment, aux lane, island
  RDM    ROADMARK      Road markings - draw or remove
  RDL    ROADLINE      NEW - single line of barricades, cones or kerb stone
  -      ROADPRORESET  Restore default settings
  U = undo whole command   F2 = summary and file path   Esc = cancel

NEW IN 3.3
  - RDL: one run of barricades, traffic cones or kerb stone on any line,
    polyline, arc, spline, circle or ellipse (centred, left, right or both
    sides, from / to distance, quantity label)
  - RDJ: Corner treatment - same as main road, barricades, cones or kerb
  - RDW / RDT move cones and kerb stone to the new edge too
  - Kerb stone drawn as units; cone white band on layer ROAD-CONE-BAND

HOW TO ADD BARRICADES / CONES / KERB
  Along a road : RDP > Road Edge and Centre > Edge = Barricades / Traffic
                 cones / Kerb stone, set unit length (cone spacing) and width
  Junction     : RDJ > Edge treatment around the corners > Corner treatment
  Single line  : RDL > select line(s) > Type, Placement, Offset, sizes

NOTE
  Sign sizes, warning distances and line markings follow the Oman Highway
  Design Standards 2017, Section 19 (GCC Manual based). For projects in
  Qatar, check against the Qatar Traffic Control Manual (QTCM).
