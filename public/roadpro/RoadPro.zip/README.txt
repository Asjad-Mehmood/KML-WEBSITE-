ROADPRO v3.5  -  Road Builder for AutoCAD / Civil 3D            03-Nov-2026
Developed by https://www.exceltokml.com/
=============================================================================

INSTALL (ONE TIME ONLY)
  1. AutoCAD or Civil 3D (2013 or newer, not LT) : type APPLOAD.
  2. Select RoadPro.lsp and press Load, then Close.
  3. RoadPro installs itself : it copies RoadPro.lsp and RP_PAVER.pat to
     %APPDATA%\RoadPro, adds that folder to the support and trusted paths and
     to the APPLOAD Startup Suite of the current profile. From then on it loads
     in every drawing by itself. If it cannot find the file it opens a file
     dialog once - pick the same RoadPro.lsp.
     RDINSTALL repeats the setup, RDUNINSTALL removes it, RDHELP lists all
     commands. Set MENUBAR = 1 to see the RoadPro menu.
  Civil 3D users : install once in each profile you use (Metric / Imperial).

WHAT IS NEW IN v3.5
  1. Saudi Arabia junction standard (RDJ)
     Design standard : Manual or Saudi Arabia - SHC 301 / MOMRA (AASHTO based).
     Road class / design vehicle (P, SU, WB-15, WB-19) fills the corner radius,
     auxiliary lane width, approach / departure tapers and storage (from the main
     road speed) and the island size. Sight triangles (ISD = 0.278 V tg,
     decision point 4.4 m from the edge) are drawn and reported.
     These are TYPICAL values - check them against the project standard.

  2. Live update (RDLIVE on / off, ON by default)
     Grip-edit, MOVE, ROTATE, STRETCH or PEDIT a road centre line : when the
     command ends, the road, its corridor, markings, widenings, tapers,
     junctions and roundabouts are rebuilt automatically. Moving a main road
     also moves the side roads joined to it. One U undoes the live update.
     RDB / RDER / RDC now REPLAY widenings, tapers, junctions and roundabouts
     instead of dropping them (roads built with v3.5 or rebuilt once with it).

  3. Sidewalks, walkways and drains wrap round junction corners
     The corridor strips now follow the kerb return (concentric curves, sharp
     corners where the radius is smaller than the offset) and are hatched -
     no more black gaps at the corners. The utility corridor of the branch
     joins the main road utility corridor. Same at roundabouts (all items).

  4. Roundabouts (RDRB, and RDJ "Junction type = Roundabout")
     US Federal Highway Administration - Roundabouts: An Informational Guide
       FHWA 2000: Mini Roundabout
       FHWA 2000: Rural Double Lane Roundabout
       FHWA 2000: Rural Double Lane Spiral Marking Roundabout
       FHWA 2000: Rural Single Lane Roundabout
       FHWA 2000: Urban Compact Roundabout
       FHWA 2000: Urban Double Lane Roundabout
       FHWA 2000: Urban Double Lane Spiral Marking Roundabout  (default)
       FHWA 2000: Urban Single Lane Roundabout
       Roundabouts: An Informational Guide 2010 (NCHRP 672) : Mini,
       Single-Lane, Multilane, Multilane Spiral Marking
     Each standard sets the inscribed radius, circulatory width, truck apron,
     entry / exit radii, splitter islands, lanes and speed (all editable).
     Draws : kerb line with entry / exit fillets, circulatory roadway, apron,
     central island (raised or mountable), splitter islands that fill the
     entry flare, pedestrian crossings, yield lines, give-way triangles,
     concentric or spiral lane line, GIVE WAY / ROUNDABOUT AHEAD / KEEP RIGHT
     signs, chevrons, ICD dimension, radii, setting-out and report.
     RDJ : choose Roundabout, pick the standard, type the radius - the branch
     you draw becomes a leg. RDRB : pick a point (or a chainage) on a road and
     draw / select side roads from the centre (left, right or both).
     Traffic keeps right - anticlockwise circulation.

  5. Concrete pavement (RDP button "Pavement..." and RDPV for a built road)
     Flexible (asphalt) or concrete JPCP / JRCP with : earthwork, stone base,
     concrete slab and steel - dowel bars at the transverse joints, tie bars at
     the longitudinal joints, steel mesh for JRCP.
     Plan : joint layout + label.  Cross section (RDX) : layers, dowels, tie
     bars, mesh.  Report (RDR / Excel) : concrete, base and earthwork volumes,
     joint lengths, number and weight of dowels / tie bars, mesh, total steel.
     Quantities are neat (no wastage) - check against the pavement design.

  Everything else is unchanged from v3.4.

NEW COMMANDS
  RDRB   ROADROUNDABOUT     roundabout on a road
  RDPV   ROADPAVEMENT       asphalt / concrete pavement of a road
  RDLIVE ROADLIVE           live update on / off
  RDINSTALL / RDUNINSTALL   permanent add-in on / off
  RDHELP ROADHELP           all commands

NEW LAYERS
  ROAD-ROUNDABOUT, ROAD-RB-ISLAND, ROAD-RB-APRON, ROAD-SIGHT, ROAD-CONC-JOINT,
  ROAD-XSEC-PCC, ROAD-XSEC-EARTH, ROAD-XSEC-STEEL

TESTING NOTE
  The code was checked for syntax, undefined functions, argument counts and
  dialog keys, and the corner / roundabout geometry was checked in a
  simulation. It has not been run inside AutoCAD by the developer of this
  package - try it on a copy of a drawing first and report anything odd.
  Roads built with v3.4 keep working; rebuild them once (RDB) to get the
  v3.5 replay and live update.

TEST REPORT (03-Nov-2026)  -  see RoadPro_v3.5_Test_Report.pdf
  122 checks over every step of the user guide : 121 pass, 1 info, 0 fail.
  Fixed during testing : 6 roundabout functions used two variable names that
  differ only by upper / lower case (R / r, O / o). AutoLISP treats them as
  one variable, so RDRB could stop with "bad argument type" and the kerb
  fillets missed the circle. Renamed and re-tested.
