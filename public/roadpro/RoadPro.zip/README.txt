RoadPro v3.2 - Road Builder for AutoCAD
Developed by https://www.exceltokml.com/
Date: 09-Oct-2026

FILES
  RoadPro.lsp              The AutoCAD plugin (AutoLISP)
  RoadPro_User_Guide.pdf   User guide - 22 pages
  RoadPro_User_Guide.pptx  User guide - editable PowerPoint
  RoadPro_Shortcuts.xlsx   All shortcut keys, ready to print

INSTALL
  1. Copy RoadPro.lsp to a fixed folder, e.g. D:\AutoCAD\Plugins\
  2. In AutoCAD type APPLOAD, select RoadPro.lsp and click Load
  3. To load it every time: APPLOAD > Startup Suite > Contents > Add
  Needs full AutoCAD / Civil 3D / Map 3D 2013 or newer (not AutoCAD LT)

SHORTCUTS
  RDP    ROADPRO       Build a complete road from a centre line
  RDR    ROADREPORT    Report tables + Excel (CSV) file
  RDRAD  ROADRADIUS    Radius, TC / CT and curve data on plan
  RDSEC  ROADSECTIONS  Straight section labels S1, S2 ...
  RDX    ROADXSEC      Cross sections
  RDW    ROADWIDEN     Lane widening with tapers
  RDT    ROADTAPER     Road taper - wider or narrower
  RDJ    ROADJUNCTION  Junction / tie-in, auxiliary lane, island
  RDM    ROADMARK      Road markings - draw or remove
  -      ROADPRORESET  Restore default settings
  U = undo whole road   F2 = summary and file path   Esc = cancel

NOTE
  Sign sizes, warning distances and line markings follow the Oman Highway
  Design Standards 2017, Section 19 (GCC Manual based). For projects in
  Qatar, check against the Qatar Traffic Control Manual (QTCM).
