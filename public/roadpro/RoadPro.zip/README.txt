ROADPRO v3.6.1  -  Road Builder for AutoCAD / Civil 3D          11-Nov-2026
Developed by https://www.exceltokml.com/
=============================================================================

INSTALL - EASIEST: RoadPro Setup (recommended)
  Download RoadPro_Setup.exe from https://www.exceltokml.com/roadpro and run
  it. No administrator rights needed. It installs RoadPro Hub and the AutoCAD
  plugin, replaces any older RoadPro, and keeps RoadPro up to date by itself.

INSTALL - THIS ZIP (plugin only, no automatic updates)
  1. AutoCAD or Civil 3D (2013 or newer, not LT) : type APPLOAD.
  2. Select RoadPro.lsp and press Load, then Close.
  3. RoadPro installs itself : it copies RoadPro.lsp and RP_PAVER.pat to
     %APPDATA%\RoadPro, adds that folder to the support and trusted paths and
     to the APPLOAD Startup Suite of the current profile. From then on it loads
     in every drawing by itself.
     RDINSTALL repeats the setup, RDUNINSTALL removes it, RDHELP lists all
     commands. Set MENUBAR = 1 to see the RoadPro menu.
  Civil 3D users : install once in each profile you use (Metric / Imperial).
  Upgrading from 3.5 : load the new RoadPro.lsp once the same way.

WHAT IS NEW IN v3.6.1  -  AUTOMATIC UPDATES
  - RoadPro Hub checks GitHub Releases for a new RoadPro: when you open
    it, and once a day when Windows starts (you can switch this off).
  - Update in one click: the setup is downloaded, checked (size and
    SHA-256 security code) and installed; the AutoCAD plugin is updated
    too. The previous version is kept and can be restored.
  - "Skip this version" if you do not want a particular update.
  - AutoCAD shows a notice at start-up when an update is waiting:
      ** RoadPro 3.7 is available (you have 3.6.1).  Type RDHUB to update. **
  - New command RDHUB (ROADPROHUB) opens RoadPro Hub: updates, repair,
    user guide, shortcut keys.

=============================================================================
WHAT IS NEW IN v3.6  (fixes from the error report + new features)
  1. Clean tie-in at junctions (RDJ)
     - The side road now starts where the kerb returns end. Its own surface,
       edges, shoulders and barricades no longer run into the main road.
     - ONE mouth surface hatch, joined to the main road hatch : no overlap,
       no black wedges (also on skewed 60 / 120 degree junctions).
     - Shoulder bands of the main road are cut at the mouth; barricades and
       red / white edge lines adjust to the kerb returns.
     - Sidewalk / walkway / drain strips meet the corner pieces exactly,
       also with an auxiliary lane (J1-AUX) and an island.
     - Corner hatch pattern follows the through road and is drawn in pieces
       of about 25 m (no solid black fill on long corners).

  2. Roundabouts on a road (RDRB)
     - Layout : 2-way, 3-way (T) left, 3-way (T) right, 4-way (cross).
     - Side road centre line : draw new, select existing, or AUTOMATIC
       (straight, at 90 degrees, length you type - default 60 m).
     - The main road surface, shoulders, barricades and edge lines are cut
       at the ring - nothing runs into the roundabout any more.
     - Side roads start at the end of the entry / exit fillets.
     - FULL MARKING : edge lines on every approach and round every corner,
       inner ring line, entry arrows, yield lines and give-way triangles,
       lane / spiral markings as the chosen standard.

  3. Edit a curve - barricades follow (RDER, grips, live update)
     After a grip edit the bend is refitted TANGENT at its radius, so the
     barricades, edges and corridor follow cleanly (no crossing units).

  4. Move a centre line - everything follows
     Junction and roundabout side roads keep their start on the moved road
     (RDB and live update), with the same clean mouth.

  5. Cross section (RDX) - professional
     - Drawn only up to the CORRIDOR LIMIT (outer edge of the utility /
       drain / walkway), with a corridor limit line on each side.
     - Dimension row 1 : every component with its name (LANE, SHOULDER,
       BARRIER, SIDEWALK, WALKWAY, DRAIN, UTILITY, VERGE).
       Row 2 : left roadside / carriageway / right roadside.
       Row 3 : corridor width (limit to limit).
       Architectural ticks on all dimensions.
     - OFFSET / FINISHED LEVEL table under the section (levels relative to
       the centre line finished level).
     - Corridor item notes on staggered rows with leaders (no overlap with
       the barrier and sign notes).

  Everything else is unchanged from v3.5.

TESTED
  Full regression of v3.5 plus 34 new drawing checks on the cases of the
  error report - see RoadPro_v3.6_Test_Report.pdf.
