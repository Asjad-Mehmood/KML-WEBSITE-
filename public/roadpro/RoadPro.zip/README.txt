RoadPro v3.4 - Road Builder for AutoCAD
Developed by https://www.exceltokml.com/
Date: 23-Oct-2026

FILES
  RoadPro.lsp                        The AutoCAD plugin (AutoLISP)
  RP_PAVER.pat                       Interlocking paver hatch pattern (RoadPro also writes it itself)
  RoadPro_User_Guide.pdf             Complete user manual - 47 pages, step by step
  RoadPro_User_Guide.pptx            Complete user manual - editable PowerPoint
  RoadPro_Shortcuts.xlsx             All shortcut keys, ready to print
  RoadPro_v3.4_Completion_Report.pdf What was built, design decisions, test results, limitations
  tests\                             Test suite (Python), results.json and evidence images

INSTALL
  1. Copy RoadPro.lsp to a fixed folder, e.g. C:\RoadPro\
  2. In AutoCAD type APPLOAD, select RoadPro.lsp and click Load
  3. To load it every time: APPLOAD > Startup Suite > Contents > Add
  Needs full AutoCAD / Civil 3D / Map 3D (not AutoCAD LT)
  Upgrading from 3.3: replace the old file, your settings and old roads are kept.
  RP_PAVER.pat is written to your roaming Support folder automatically the first
  time a paver hatch is drawn. Copy it there by hand only if that folder is read-only.

SHORTCUTS
  RDP    ROADPRO        Build a complete road from a centre line
  RDR    ROADREPORT     Report tables + Excel (CSV) file
  RDRAD  ROADRADIUS     Radius, TC / CT and curve data on plan
  RDSEC  ROADSECTIONS   Straight section labels S1, S2 ...
  RDX    ROADXSEC       Cross sections
  RDW    ROADWIDEN      Lane widening with tapers
  RDT    ROADTAPER      Road taper - wider or narrower
  RDJ    ROADJUNCTION   Junction / tie-in, corner treatment, aux lane, island
  RDM    ROADMARK       Road markings - draw or remove
  RDL    ROADLINE       Single line of barricades, cones or kerb stone
  RDC    ROADCORRIDOR   NEW - lanes, median, sidewalks, walkways, drains, utilities of a road
  RDU    ROADUPDATE     NEW - redraw the corridor after edits
  RDER   ROADEDITRADIUS NEW - change a curve radius after the road is built
  RDB    ROADREBUILD    NEW - rebuild the road after editing its centre line
  RDLX   ROADLANDXML    NEW - export the centre line as LandXML 1.2 (for Civil 3D)
  RDLXI  ROADLANDXMLIN  NEW - import a LandXML alignment as a polyline
  -      ROADPRORESET   Restore default settings
  U = undo whole command   F2 = summary and file path   Esc = cancel

NEW IN 3.4
  - RDP > "Lanes, median, sidewalks, drains, utilities..." dialog:
      single or dual carriageway; lanes manual (left / right can differ) or
      automatic from design volume (indicative only - not an engineering
      approval); flush or raised median; sidewalks and walkways left / right;
      drains (open, U-channel, pipe) and utility corridors as geometric
      provisions; interlocking paver hatch (RP_PAVER / herringbone / other)
  - Lane lines, direction line and arrows per lane; yellow median edges
  - Cross sections show every component with dimensions
  - Existing polyline is kept (road built on a copy) and checked for short
    segments, sharp bends and self-intersections
  - Civil 3D: select an alignment in RDP (copied as polyline) or exchange
    with LandXML (RDLX / RDLXI). This is not a live Civil 3D link.
  - Fixes: RDW redraws markings on the widened edge; RDL no longer says
    "cancelled" after a successful run

TESTING
  105 automated checks passed in an AutoLISP emulator; v3.3 behaviour
  unchanged. Not yet run in real AutoCAD / Civil 3D - see the Completion
  Report, section 9, for the short checklist to run on your PC.

NOTE
  Sign sizes, warning distances and line markings follow the Oman Highway
  Design Standards 2017, Section 19 (GCC Manual based). For projects in
  Qatar, check against QTCM / QHDM. Lane counts, widths, drains and utility
  corridors must be confirmed by the design engineer.
