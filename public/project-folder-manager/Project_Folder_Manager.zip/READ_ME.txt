PROJECT FOLDER MANAGER  v6.2          Developed by Muhammad Abdullah
-----------------------------------------------------------------
Double-click  Project_Folder_Manager.exe
(keep the .exe and the .hta together in one folder)

First run:  paste your project folder into ROOT PATH, press SET,
            then press INDEX once - after that every search is instant.
Title:      click the title at the top-left to rename it for any project.
Views:      six layouts - VIEW buttons or Alt+1 to Alt+6.
Update:     replace only the .hta file.
New name:   the settings file is now Project_Folder_Manager_config.txt,
            so set the root path once. Old config files can be deleted.
